"""OpenAI Chat Completions Proxy Server"""

import json
import os
from http.server import HTTPServer, BaseHTTPRequestHandler
from openai import OpenAI

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def load_env(filepath: str = None) -> dict[str, str]:
    """Load environment variables from .env file"""
    if filepath is None:
        filepath = os.path.join(SCRIPT_DIR, ".env")
    env = {}
    try:
        with open(filepath, "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, value = line.split("=", 1)
                    env[key.strip()] = value.strip()
    except FileNotFoundError:
        print(f"Warning: {filepath} not found")
    return env


env = load_env()
api_key = env.get("OPENAI_API_KEY")
if not api_key:
    raise RuntimeError("OPENAI_API_KEY not found in .env file")

try:
    client = OpenAI(api_key=api_key)
    print("OpenAI client initialized successfully")
except Exception as e:
    print(f"Failed to initialize OpenAI client: {e}")
    client = None


class ProxyHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path == "/chat/completions":
            self.handle_chat_completions()
        else:
            self.send_error(404, "Not Found")

    def handle_chat_completions(self):
        if client is None:
            self.send_error(500, "OpenAI client not initialized")
            return

        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length)

        try:
            data = json.loads(body)
            model = data.get("model")
            messages = data.get("messages")

            if not model or not messages:
                self.send_error(400, "model and messages are required")
                return

            completion = client.chat.completions.create(
                model=model,
                messages=messages,
            )

            response = completion.to_json()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(response.encode("utf-8"))

        except json.JSONDecodeError:
            self.send_error(400, "Invalid JSON")
        except Exception as e:
            self.send_error(500, str(e))


def main():
    port = 8080
    server = HTTPServer(("", port), ProxyHandler)
    print(f"Server running on port {port}")
    server.serve_forever()


if __name__ == "__main__":
    main()
