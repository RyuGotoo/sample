#!/usr/bin/env python3
"""
関数の依存関係を解析し、生成順序を決定するスクリプト

analysis_result.jsonから関数の依存関係を読み取り、
トポロジカルソートを使用して生成順序を決定し、
CSVファイルとして出力する。
"""

import json
import csv
import sys
import os
from collections import defaultdict, deque
from typing import Dict, List, Set, Tuple, Optional
from pathlib import Path


def load_settings(settings_path: str = "./settings.json") -> Dict:
    """settings.jsonファイルを読み込む"""
    try:
        with open(settings_path, "r", encoding="utf-8") as f:
            settings = json.load(f)

        # 必須フィールドの検証
        required_fields = ["output_dir", "analysis_result_file"]
        for field in required_fields:
            if field not in settings:
                print(
                    f"エラー: settings.jsonに必須フィールド '{field}' が見つかりません",
                    file=sys.stderr,
                )
                sys.exit(1)

        return settings
    except FileNotFoundError:
        print(
            f"エラー: 設定ファイル '{settings_path}' が見つかりません", file=sys.stderr
        )
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"エラー: 設定ファイルのJSON解析に失敗しました: {e}", file=sys.stderr)
        sys.exit(1)


def load_analysis_result(file_path: str) -> List[Dict]:
    """analysis_result.jsonファイルを読み込む"""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"エラー: ファイル '{file_path}' が見つかりません", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"エラー: JSONファイルの解析に失敗しました: {e}", file=sys.stderr)
        sys.exit(1)


def load_target_functions(file_path: str) -> Set[str]:
    """target_functions.csvを読み込み、関数IDのセットを返す"""
    target_func_ids = set()
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if "func_id" in row:
                    target_func_ids.add(row["func_id"])
                else:
                    print(f"警告: CSVに 'func_id' 列が見つかりません", file=sys.stderr)
                    break

        if not target_func_ids:
            print(
                f"警告: target_functions.csvに有効な関数IDが見つかりません",
                file=sys.stderr,
            )
        else:
            print(
                f"target_functions.csvから {len(target_func_ids)} 個の関数を読み込みました"
            )

        return target_func_ids

    except FileNotFoundError:
        print(f"エラー: ファイル '{file_path}' が見つかりません", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"エラー: CSVファイルの読み込みに失敗しました: {e}", file=sys.stderr)
        sys.exit(1)


def expand_dependencies(
    target_func_ids: Set[str], functions: List[Dict]
) -> Tuple[Set[str], Set[str]]:
    """
    target関数から再帰的に依存関係を展開し、必要なすべての関数IDを返す

    Returns:
        - expanded_func_ids: 展開された全関数IDのセット
        - missing_func_ids: analysis_result.jsonに存在しないtarget関数IDのセット
    """
    # 関数ID -> 関数情報の辞書を構築
    func_dict = {}
    for item in functions:
        if item["type"] == "func":
            func_dict[item["id"]] = item

    # 存在しないtarget関数をチェック
    missing_func_ids = target_func_ids - set(func_dict.keys())
    if missing_func_ids:
        print(
            f"警告: target_functions.csvに指定された関数がanalysis_result.jsonに見つかりません ({len(missing_func_ids)}件):"
        )
        for func_id in sorted(missing_func_ids):
            print(f"  - {func_id}")

    expanded_func_ids = set()
    visited = set()

    def dfs(func_id: str):
        if func_id in visited:
            return
        visited.add(func_id)

        if func_id in func_dict:
            expanded_func_ids.add(func_id)
            func_info = func_dict[func_id]

            if "calls" in func_info:
                for called_id in func_info["calls"]:
                    if called_id.startswith("func_"):  # func_で始まるIDのみ
                        dfs(called_id)

    # 各target関数から依存関係を展開（存在する関数のみ）
    for func_id in target_func_ids:
        if func_id in func_dict:
            dfs(func_id)

    return expanded_func_ids, missing_func_ids


def build_dependency_graph(
    functions: List[Dict], target_func_ids: Optional[Set[str]] = None
) -> Tuple[Dict[str, Set[str]], Dict[str, Dict], Set[str]]:
    """
    依存関係グラフを構築する

    Returns:
        - graph: 各関数が呼び出す側の関数のセット（呼び出される側→呼び出す側）
        - func_info: 関数IDから関数情報への辞書
        - all_func_ids: すべての関数IDのセット
    """
    graph = defaultdict(set)
    func_info = {}
    all_func_ids = set()

    # targetモードの場合、依存関係を展開
    is_target_mode = target_func_ids is not None
    if is_target_mode:
        original_target_count = len(target_func_ids)
        expanded_func_ids, missing_func_ids = expand_dependencies(
            target_func_ids, functions
        )
        added_count = len(expanded_func_ids) - (
            original_target_count - len(missing_func_ids)
        )

        print(f"\n依存関係を展開しました:")
        print(f"  - target指定: {original_target_count}個")
        if missing_func_ids:
            print(f"  - 見つからない: {len(missing_func_ids)}個")
        print(f"  - 依存により追加: {added_count}個")
        print(f"  - 合計出力対象: {len(expanded_func_ids)}個\n")

        # 展開された関数IDセットを使用
        target_func_ids = expanded_func_ids

    # 関数情報を収集
    for item in functions:
        if item["type"] == "func":
            func_id = item["id"]

            # targetモードの場合は、展開されたfunc_idsに含まれる関数のみ処理
            if is_target_mode and func_id not in target_func_ids:
                continue

            all_func_ids.add(func_id)
            func_info[func_id] = item

            # この関数が呼び出す関数について、呼び出される側→呼び出す側の関係を追加
            if "calls" in item and item["calls"]:
                has_func_calls = False
                for called_id in item["calls"]:
                    # func_で始まるIDのみを依存関係として扱う（外部関数は除外）
                    if called_id.startswith("func_"):
                        # targetモードでも、展開により含まれる関数は処理対象
                        if is_target_mode and called_id not in target_func_ids:
                            continue  # 展開後もtarget外の関数は無視（通常は発生しない）

                        # called_id（呼ばれる側）→ func_id（呼ぶ側）の関係
                        graph[called_id].add(func_id)
                        has_func_calls = True

                # デバッグ用：外部関数のみを呼ぶ関数を記録
                if not has_func_calls:
                    func_info[func_id]["_ext_only"] = True

    # protoタイプの処理（実装関数と同じ扱い）
    for item in functions:
        if item["type"] == "proto" and "implemented_at" in item:
            impl_id = item["implemented_at"]
            # targetモードの場合、target関数のみに対してproto情報を追加
            if impl_id in func_info:
                # protoの情報を実装関数の情報に含める
                if "protos" not in func_info[impl_id]:
                    func_info[impl_id]["protos"] = []
                func_info[impl_id]["protos"].append(item)

    return graph, func_info, all_func_ids


def topological_sort(
    graph: Dict[str, Set[str]], func_info: Dict[str, Dict], all_nodes: Set[str]
) -> List[str]:
    """
    トポロジカルソートを実行して生成順序を決定する

    Returns:
        ソートされた関数IDのリスト（呼ばれない/callsが空の関数が先）
    """
    # 各ノードの入次数を計算（呼んでいる関数の数 = 依存している関数の数）
    in_degree = defaultdict(int)

    # まず全ノードの入次数を0に初期化
    for node in all_nodes:
        in_degree[node] = 0

    # 各関数について、その関数が呼んでいる関数の数をカウント
    for func_id, info in func_info.items():
        if "calls" in info and info["calls"]:
            # func_で始まる呼び出しをカウント
            func_calls_count = sum(
                1 for c in info["calls"] if c.startswith("func_") and c in all_nodes
            )
            in_degree[func_id] = func_calls_count

    # 入次数が0のノードをキューに追加（他の関数を呼ばない関数）
    queue = deque([node for node in all_nodes if in_degree[node] == 0])
    result = []

    # デバッグ：最初のキューの内容を確認
    initial_queue = sorted([node for node in all_nodes if in_degree[node] == 0])[:10]
    print(f"\n最初のキュー（入次数0）の先頭10個:")
    for node in initial_queue:
        name = (
            func_info[node].get("name", "unknown") if node in func_info else "unknown"
        )
        calls = func_info[node].get("calls", []) if node in func_info else []
        func_calls = [c for c in calls if c.startswith("func_")]
        print(f"  - {node} ({name}) - func_calls: {len(func_calls)}")

    while queue:
        # 安定したソートのために、キューから取り出す前にソート
        current_batch = sorted(list(queue))
        queue.clear()

        for node in current_batch:
            result.append(node)

            # このノードを呼び出している関数（このノードに依存している関数）の入次数を減らす
            if node in graph:
                for dependent_func in graph[node]:
                    if dependent_func in all_nodes:
                        in_degree[dependent_func] -= 1
                        if in_degree[dependent_func] == 0:
                            queue.append(dependent_func)

    # 循環依存のチェック
    if len(result) != len(all_nodes):
        unprocessed = all_nodes - set(result)
        print(
            f"警告: 循環依存が検出されました。以下の関数が処理されませんでした:",
            file=sys.stderr,
        )
        for func_id in unprocessed:
            print(f"  - {func_id}", file=sys.stderr)

    return result


def save_to_csv(
    sorted_functions: List[str], func_info: Dict[str, Dict], output_path: str
):
    """生成順序をCSVファイルに保存する"""
    csv_path = os.path.join(output_path, "generation_order.csv")

    try:
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["order", "id", "name", "type", "file_path"])

            for order, func_id in enumerate(sorted_functions, 1):
                if func_id in func_info:
                    info = func_info[func_id]
                    writer.writerow(
                        [
                            order,
                            func_id,
                            info.get("name", ""),
                            info.get("type", ""),
                            info.get("file_path", ""),
                        ]
                    )

        print(f"生成順序を保存しました: {csv_path}")
        print(f"総関数数: {len(sorted_functions)}")

    except IOError as e:
        print(f"エラー: CSVファイルの書き込みに失敗しました: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    """メイン処理"""
    # ヘルプメッセージの表示
    if len(sys.argv) > 1 and sys.argv[1] in ("-h", "--help"):
        print("使用方法:")
        print("  全関数モード: python3 determine_generation_order.py --all")
        print("  target指定モード: python3 determine_generation_order.py")
        print("")
        print("設定は ./settings.json から読み込まれます")
        print("target指定モードでは {output_dir}/target_functions.csv が必要です")
        sys.exit(0)

    # settings.jsonを読み込む
    settings = load_settings()

    # コマンドライン引数の解析
    is_all_mode = "--all" in sys.argv

    # settings.jsonから設定を取得
    input_file = settings["analysis_result_file"]
    output_dir = settings["output_dir"]

    # target_functions.csvのパスを計算
    target_file = None
    if not is_all_mode:
        target_file_path = Path(output_dir) / "target_functions.csv"
        if target_file_path.exists():
            target_file = str(target_file_path)
            print("target関数指定モードで実行中...")
        else:
            print(
                f"エラー: target関数ファイル '{target_file_path}' が見つかりません",
                file=sys.stderr,
            )
            print(
                "全関数モードで実行する場合は --all フラグを指定してください",
                file=sys.stderr,
            )
            sys.exit(1)
    else:
        print("全関数対象モードで実行中...")

    # 出力ディレクトリの確認
    output_dir_path = Path(output_dir)
    if not output_dir_path.exists():
        print(
            f"エラー: 出力ディレクトリ '{output_dir}' が存在しません", file=sys.stderr
        )
        sys.exit(1)

    if not output_dir_path.is_dir():
        print(f"エラー: '{output_dir}' はディレクトリではありません", file=sys.stderr)
        sys.exit(1)

    # 処理実行
    print(f"analysis_resultを読み込み中: {input_file}")
    functions = load_analysis_result(input_file)

    # target関数の読み込み（targetモードの場合）
    target_func_ids = None
    if target_file:
        target_func_ids = load_target_functions(target_file)

    print("依存関係グラフを構築中...")
    graph, func_info, all_func_ids = build_dependency_graph(functions, target_func_ids)

    print(f"関数数: {len(all_func_ids)}")

    # デバッグ情報を出力
    print("\nデバッグ情報:")
    no_calls_count = 0
    ext_only_count = 0
    for func_id, info in func_info.items():
        if "calls" not in info or not info["calls"]:
            no_calls_count += 1
        elif "_ext_only" in info:
            ext_only_count += 1
    print(f"  - callsが空の関数数: {no_calls_count}")
    print(f"  - 外部関数のみを呼ぶ関数数: {ext_only_count}")
    print(
        f"  - 他のfunc_を呼ぶ関数数: {len(all_func_ids) - no_calls_count - ext_only_count}"
    )

    # 最初の数個のcallsが空の関数を表示
    print("\ncallsが空の関数の例:")
    empty_calls_examples = []
    for func_id, info in func_info.items():
        if "calls" not in info or not info["calls"]:
            empty_calls_examples.append(
                f"  - {func_id} ({info.get('name', 'unknown')})"
            )
            if len(empty_calls_examples) >= 5:
                break
    print("\n".join(empty_calls_examples))

    print("\nトポロジカルソートを実行中...")
    sorted_functions = topological_sort(graph, func_info, all_func_ids)

    print("CSVファイルに保存中...")
    save_to_csv(sorted_functions, func_info, output_dir)

    print("完了しました")


if __name__ == "__main__":
    main()
