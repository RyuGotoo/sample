import json
import csv
from collections import defaultdict
from pathlib import Path


def generate_function_call_csv(funcs, target_files, output_path):
    # --- id → 要素の辞書化 ---
    id_map = {item["id"]: item for item in funcs}
    callers_map = defaultdict(set)

    for item in funcs:
        for call in item.get("calls", []):
            if call.startswith("ext_"):
                continue
            if call in id_map:
                callers_map[call].add(item.get("id"))

    # --- 再帰的にcallsを追う関数 ---
    def collect_calls(func_item, visited):
        if func_item["id"] in visited:
            return
        visited.add(func_item["id"])

        calls = func_item.get("calls", [])
        for call in calls:
            if call.startswith("ext_"):  # 外部関数は無視
                continue
            callee = id_map.get(call)
            if callee:
                collect_calls(callee, visited)

    # --- 対象ファイルの関数を抽出し、callsを追う ---
    collected_ids = set()
    for item in funcs:
        if Path(item.get("file_path")) in target_files and item["type"] == "func":
            collect_calls(item, collected_ids)

    # --- CSV出力データ生成 ---
    rows = []
    for fid in collected_ids:
        func = id_map.get(fid)
        if func:
            callee_ids = [
                call
                for call in func.get("calls", [])
                if not call.startswith("ext_") and call in id_map
            ]
            rows.append(
                [
                    func.get("file_path", ""),
                    func.get("type", ""),
                    func.get("id", ""),
                    func.get("name", ""),
                    len(callers_map.get(func.get("id"), set())),
                    len(callee_ids),
                ]
            )

    # --- CSV出力 ---
    with open(output_path, "w", newline="", encoding="utf-8") as cf:
        writer = csv.writer(cf)
        writer.writerow(
            [
                "file_path",
                "func_type",
                "func_id",
                "func_name",
                "caller_num",
                "callee_num",
            ]
        )
        writer.writerows(rows)

    return collected_ids
