from pathlib import Path
import platform
import json
import logging

from ..util import ensure_path_exists
from src.preprocess import clean_c_source
from src.preprocess import exec_analysis
from src.preprocess import update_funcs
from src.preprocess import targets

logger = logging.getLogger(__name__)


def run(config):
    # ファイル存在確認
    if platform.system() == "Windows":
        analyzer_path = ensure_path_exists("c-analyzer.exe")
    else:
        analyzer_path = ensure_path_exists("c-analyzer")
    c_source_path = ensure_path_exists(config.get("c_source_dir"))
    target_paths = [ensure_path_exists(p) for p in config.get("target_paths")]

    # c_source前処理
    logger.info("c_source前処理開始")
    clean_c_source.remove_non_c_and_h_files(c_source_path)
    clean_c_source.remove_empty_directories(c_source_path)
    clean_c_source.clean_invalid_utf8_in_files(c_source_path)
    logger.info("c_source前処理完了")

    # 解析実行
    logger.info("解析実行開始")
    output_dir = Path(config["output_dir"])
    exec_analysis.exec(
        analyzer_path=analyzer_path,
        c_source_dir=c_source_path,
        output_dir=output_dir,
    )
    logger.info("解析実行完了")

    funcs_tmp_json_path = ensure_path_exists(output_dir / "funcs_tmp.json")
    events_json_path = ensure_path_exists(output_dir / "events.json")
    guis_json_path = ensure_path_exists(output_dir / "guis.json")

    # 解析結果修正
    logger.info("解析結果修正開始")
    update_funcs.run(funcs_json_path=funcs_tmp_json_path)
    funcs_json_path = ensure_path_exists(output_dir / "funcs.json")
    logger.info("解析結果修正完了")

    # target_paths内の .c ファイル一覧取得、保存
    target_c_files = [list(p.rglob("*.c")) for p in target_paths]
    target_c_files = [p for row in target_c_files for p in row]
    with open(output_dir / "target_files.txt", "w", encoding="utf-8") as f:
        f.write("\n".join([str(i) for i in target_c_files]))

    # 関数解析結果取得
    with open(funcs_json_path, "r", encoding="utf-8") as f:
        funcs = json.load(f)

    # target_functions取得、保存
    output_path = output_dir / "target_functions.csv"
    target_functions = targets.generate_function_call_csv(
        funcs=funcs,
        target_files=target_c_files,
        output_path=output_path,
    )
    logger.info(f"target_funcsions.csv 出力完了{output_path}")

    return (funcs_json_path, events_json_path, guis_json_path, output_path)
