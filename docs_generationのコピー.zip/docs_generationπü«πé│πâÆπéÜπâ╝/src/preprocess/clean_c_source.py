from pathlib import Path


def remove_non_c_and_h_files(dir_path: Path):
    """指定ディレクトリ以下を再帰走査し、.c と .h 以外のファイルを削除する"""
    dir_path = Path(dir_path)
    for file in dir_path.rglob("*"):
        if file.is_file() and file.suffix not in {".c", ".h"}:
            file.unlink()


def remove_empty_directories(dir_path: Path):
    """指定ディレクトリ以下を再帰走査し、空ディレクトリを削除する"""
    dir_path = Path(dir_path)
    # 子ディレクトリから処理するため reverse ソート
    for d in sorted(dir_path.rglob("*"), reverse=True):
        if d.is_dir() and not any(d.iterdir()):
            d.rmdir()


def clean_invalid_utf8_in_files(dir_path: Path):
    """ディレクトリを再帰走査し、UTF-8 デコードエラーを起こす文字を削除して上書き保存する"""
    dir_path = Path(dir_path)
    for file in dir_path.rglob("*"):
        if file.is_file():
            # バイナリ読み込み
            raw = file.read_bytes()
            # UTF-8 に変換（不正なバイトは削除）
            text = raw.decode("utf-8", errors="ignore")
            # 上書き保存
            file.write_text(text, encoding="utf-8")
