# from ollama import chat
# def chat_completions(sys_prompt, user_prompt):
#     response = chat(
#         model="qwen3:4b",
#         messages=[
#             {"role": "system", "content": sys_prompt},
#             {"role": "user", "content": user_prompt},
#         ],
#     )
#     return response.message.content


# mock
def chat_completions(sys_prompt, user_prompt):
    return f"""```xml
<function>
  <name>sample_func</name>
  <purpose>sample</purpose>
  <summary>len(sys_prompt): {len(sys_prompt)}, len(user_prompt): {len(user_prompt)}</summary>
  <arguments>
    <arg>
      <name></name>
      <type></type>
      <description></description>
    </arg>
    <!-- 複数のパラメータがある場合は、この構造を繰り返してください -->
  </arguments>
  <return-value>
    <type></type>
    <description></description>
  </return-value>
  <remarks></remarks>
  <process-flow>
    <step></step>
    <!-- 複数のステップがある場合は、この構造を繰り返してください -->
  </process-flow>
  <database-queries>
    <query>
      <description></description>
      <pseudo-sql></pseudo-sql>
    </query>
    <!-- 複数のクエリがある場合は、この構造を繰り返してください -->
  </database-queries>
</function>
```"""
