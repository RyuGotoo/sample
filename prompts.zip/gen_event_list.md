## コード入力
以下にVB6の.frmファイルの内容を貼り付けてください：

```vb
' ここにVB6の.frmファイルの内容を貼り付けてください
```

## Chain of Thought (CoT) 抽出プロセス
以下の手順に従って、段階的に考えながらイベント情報を抽出してください。各ステップで考察を述べ、結果を示してください。

1. ファイル構造の分析:
   - .frmファイルの構造を確認し、コードセクションを特定します。
   - 考察: ファイルは標準的なVB6 .frm構造に従っているか？特殊な構造はあるか？

2. イベントプロシージャの特定:
   - 以下のパターンを探します：
     * `Private Sub/Function [コントロール名]_[イベント名]([パラメータ]) [As 戻り値の型]`
     * `Public Sub/Function [コントロール名]_[イベント名]([パラメータ]) [As 戻り値の型]`
     * `Sub/Function [コントロール名]_[イベント名]([パラメータ]) [As 戻り値の型]`
   - 考察: 見つかったイベントプロシージャの数は予想通りか？特殊なパターンはあるか？

3. 情報抽出:
   各イベントプロシージャについて：
   - コントロール名とイベント名を分離します。
   - パラメータと型情報を抽出します。
   - スコープ、種類（Sub/Function）、戻り値の型（ある場合）を特定します。
   - 考察: 抽出した情報は完全で正確か？特殊なケースはあるか？

4. コントロールとイベントの分類:
   - コントロールを標準、カスタム、ActiveXに分類します。
   - イベントを一般的なものと特殊なものに分類します。
   - 考察: 分類に迷うケースはあるか？特殊なコントロールやイベントの扱いは？

5. XML構造の生成:
   - 抽出した情報を基にXML構造を組み立てます。
   - 考察: 生成されたXMLは全ての情報を正確に表現しているか？

6. 最終確認:
   - 生成されたXMLの完全性と正確性を確認します。
   - 考察: 結果は.frmファイルの内容を完全に反映しているか？改善点はあるか？

## 出力フォーマット
抽出した情報は以下のXML構造で出力してください：

XML出力の例:

```xml
<form-events>
  <event>
    <control-name>Command1</control-name>
    <event-name>Click</event-name>
    <parameters></parameters>
    <function-name>Command1_Click</function-name>
    <scope>Private</scope>
    <type>Sub</type>
    <return-type></return-type>
    <control-type>Standard</control-type>
    <event-type>Common</event-type>
  </event>
  <event>
    <control-name>CustomControl1</control-name>
    <event-name>SpecialAction</event-name>
    <parameters>ByVal actionType As Integer, ByRef result As String</parameters>
    <function-name>CustomControl1_SpecialAction</function-name>
    <scope>Public</scope>
    <type>Function</type>
    <return-type>Boolean</return-type>
    <control-type>Custom</control-type>
    <event-type>Specific</event-type>
  </event>
  <!-- 他のイベントも同様に記述 -->
</form-events>
```

## 出力要素の説明
- control-name: イベントが属するコントロールの名前
- event-name: イベントの名前（例：Click, Load, Change）
- parameters: イベントプロシージャのパラメータ（ある場合）
- function-name: イベントプロシージャの完全な名前
- scope: イベントプロシージャのスコープ（Private, Public, または指定なし）
- type: イベントプロシージャの種類（Sub または Function）
- return-type: 関数の戻り値の型（Functionの場合のみ）
- control-type: コントロールの種類（Standard: 標準VB6コントロール, Custom: カスタムコントロール, ActiveX: ActiveXコントロール）
- event-type: イベントの種類（Common: 一般的なイベント, Specific: コントロール固有のイベント）

## 注意事項
- イベントプロシージャが見つからない場合は、空の`<form-events></form-events>`構造を出力してください。
- すべての特殊文字は適切にエスケープしてください。
- コメントや空行は無視してください。
- 各CoTステップでの考察を示し、特殊なケースや注意点があればそれらについても言及してください。

提供された.frmファイルの内容に基づいて、上記のCoTプロセスに従ってイベント情報を抽出し、指定されたXML形式で出力してください。各ステップでの思考過程と考察も含めてください。