# from ollama import chat
# def chat_completions(sys_prompt, user_prompt):
#     response = chat(
#         model="qwen3:4b",
#         messages=[
#             {"role": "system", "content": sys_prompt},
#             {"role": "user", "content": user_prompt},
#         ],
#     )
#     return response.message.content


# mock - 30%エラー率とランダム遅延付き
import random
import time


def chat_completions(sys_prompt, user_prompt):
    # 1-10秒のランダム遅延
    # time.sleep(random.uniform(1, 2))

    # 50%の確率で誤った形式を返す
    if random.random() < 0.1:
        error_responses = [
            "Error: Connection timeout",  # エラーメッセージ
            '{"error": "Invalid request"}',  # JSON形式
            "<function><name>broken_xml</purpose>",  # 閉じタグ不正
            "",  # 空レスポンス
            "```xml\n<function><name>no_close_tag</function>",  # XMLタグ不正
            "Internal server error occurred",  # エラーテキスト
        ]
        return random.choice(error_responses)

    # 正常なXMLレスポンス（70%の確率）
    return f"""```xml
<function>
  <name>sample_func</name>
  <purpose>sample</purpose>
  <summary>hello world</summary>
  <arguments>
    <arg>
      <name></name>
      <type></type>
      <description></description>
    </arg>
    <!-- 複数のパラメータがある場合は、この構造を繰り返してください -->
  </arguments>
  <return-value>
    <type></type>
    <description></description>
  </return-value>
  <remarks></remarks>
  <process-flow>
    <step></step>
    <!-- 複数のステップがある場合は、この構造を繰り返してください -->
  </process-flow>
  <database-queries>
    <query>
      <description></description>
      <pseudo-sql></pseudo-sql>
    </query>
    <!-- 複数のクエリがある場合は、この構造を繰り返してください -->
  </database-queries>
</function>
```"""
