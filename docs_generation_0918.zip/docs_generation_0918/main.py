import sys
import csv
import json
import shutil
from pathlib import Path


def collect_target_files(targets: list[str], base_path: Path = None) -> list[dict]:
    """
    対象リストから全ての対象ファイルを収集する。

    Args:
        targets: 対象ファイルリストからのパスのリスト
        base_path: ベースディレクトリのパス。Noneの場合は現在のディレクトリを使用。

    Returns:
        list[dict]: 対象ファイル情報のリスト
    """
    if base_path is None:
        base_path = Path.cwd()

    target_files = []

    for target in targets:
        # ターゲットパスがベースディレクトリを既に含んでいる場合の処理
        if str(base_path) != "." and target.startswith(str(base_path) + "/"):
            # ベースディレクトリ部分を削除
            target_relative = target[len(str(base_path)) + 1 :]
            target_path = base_path / target_relative
        else:
            target_path = base_path / target

        if target_path.is_file():
            # 単一ファイル
            if target_path.suffix == ".c":
                target_files.append({"file_path": target})  # 元のパスをそのまま使用
        elif target_path.is_dir():
            # ディレクトリ - 全ての.cファイルを再帰的に収集
            for c_file in target_path.rglob("*.c"):
                # 相対パスを計算
                if str(base_path) != ".":
                    relative_path = str(base_path / c_file.relative_to(base_path))
                else:
                    relative_path = str(c_file.relative_to(base_path))
                target_files.append({"file_path": relative_path})
        # 存在しないファイル/ディレクトリは無視（リストに追加しない）

    return target_files


def collect_all_functions(
    file_list: list[dict[str, str]], analysis_data: dict = None
) -> list[dict[str, str]]:
    """
    解析済みデータから全ての関数情報を収集する。

    Args:
        file_list: 対象ファイル情報のリスト
        analysis_data: analysis_result_sample_files.jsonから読み込んだデータ

    Returns:
        list[dict]: 発見した全関数のリスト
    """
    all_functions = []

    if analysis_data:
        # JSONデータから関数情報を取得
        for file_info in file_list:
            file_path = file_info["file_path"]
            if file_path in analysis_data:
                functions = analysis_data[file_path]
                # type=funcのみフィルタリング
                func_only = [f for f in functions if f.get("func_type") == "func"]
                all_functions.extend(func_only)

    return all_functions


def collect_all_functions_with_calls(
    all_functions: list[dict], analysis_data_json: list[dict]
) -> list[dict]:
    """
    関数とその呼び出し先関数を含む全関数リストを作成する（再帰的に依存を追跡）。

    Args:
        all_functions: 元の関数リスト
        analysis_data_json: analysis_result.jsonから読み込んだ生データ

    Returns:
        list[dict]: 呼び出し先関数も含む全関数リスト
    """
    # 処理済み関数IDのセット（重複と無限ループ回避）
    processed_func_ids = set()
    all_functions_with_calls = []

    # まず元の関数リストを追加
    for func in all_functions:
        func_id = func.get("func_id")
        if func_id not in processed_func_ids:
            all_functions_with_calls.append(func)
            processed_func_ids.add(func_id)

    # 処理するキューを作成（初期値は元の関数リスト）
    queue = list(all_functions)
    added_count = 0

    # キューが空になるまで処理
    while queue:
        func = queue.pop(0)
        func_id = func.get("func_id")

        # analysis_data_jsonから対応する関数情報を検索
        for item in analysis_data_json:
            if item.get("id") == func_id and "calls" in item:
                # 呼び出し先関数を追加
                for call_name in item["calls"]:
                    # func_で始まる呼び出しのみ処理（内部関数呼び出し）
                    if call_name.startswith("func_"):
                        # 呼び出し先関数のIDとして扱う
                        for call_item in analysis_data_json:
                            if (
                                call_item.get("id") == call_name
                                and call_item.get("type") == "func"
                            ):
                                # まだ処理していない関数の場合のみ追加
                                if call_name not in processed_func_ids:
                                    call_func = {
                                        "func_id": call_item["id"],
                                        "func_type": call_item["type"],
                                        "func_name": call_item["name"],
                                        "file_path": call_item["file_path"],
                                    }
                                    all_functions_with_calls.append(call_func)
                                    processed_func_ids.add(call_name)
                                    # キューに追加して、この関数の呼び出し先も処理する
                                    queue.append(call_func)
                                    added_count += 1
                                break
                break

    print(f"呼び出し先関数として {added_count} 個を追加（再帰的に依存を追跡）")
    return all_functions_with_calls


def main():
    # 設定ファイルのパスを決定
    config_path = Path("./config.json")

    # 設定ファイルを読み込む
    with open(config_path, "r", encoding="utf-8") as f:
        config = json.load(f)

    # 設定値を変数に割り当て
    base_dir = Path(config["c_source_dir"])
    analysis_file = Path(config["analysis_result_file"])
    targets_file = Path(config["target_paths_file"])
    output_base_dir = Path(config["output_dir"])

    # 出力ディレクトリ作成
    # config.jsonのoutput_dirを使用
    output_dir = output_base_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"出力ディレクトリを作成しました: {output_dir}")

    # target_paths.txtの読み込みとコピー
    print(f"{targets_file.name}を処理中...")
    lines = targets_file.read_text(encoding="utf-8").splitlines()
    targets = [line.strip() for line in lines if line.strip()]
    shutil.copy2(targets_file, output_dir / targets_file.name)
    print(f"{len(targets)} 個のターゲットファイルを発見")

    # analysis_result.jsonをコピー
    print(f"{analysis_file.name}をコピー中...")
    shutil.copy2(analysis_file, output_dir / analysis_file.name)

    # config.jsonをコピー
    print(f"{config_path.name}をコピー中...")
    shutil.copy2(config_path, output_dir / config_path.name)

    # 対象ファイルの収集
    print("対象ファイルを収集中...")
    target_files = collect_target_files(targets, base_dir)

    # Write target_files.csv
    target_files_csv = output_dir / "target_files.csv"
    with open(target_files_csv, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=["file_path"])
        writer.writeheader()
        writer.writerows(target_files)
    print(f"{target_files_csv} を生成 ({len(target_files)} ファイル)")

    # 解析済みデータを読み込み
    print("解析済みデータを読み込み中...")

    with open(analysis_file, "r", encoding="utf-8") as f:
        analysis_data_json = json.load(f)

    analysis_data = {}
    # 関数ID -> 内部callee一覧、callee -> caller集合 のマップを構築
    func_calls_map: dict[str, list[str]] = {}
    func_callers_map: dict[str, set[str]] = {}
    for item in analysis_data_json:
        file_path = item["file_path"]
        if file_path not in analysis_data:
            analysis_data[file_path] = []

        analysis_data[file_path].append(
            {
                "func_id": item["id"],
                "func_type": item["type"],
                "func_name": item["name"],
                "file_path": file_path,
            }
        )

        # funcの呼び出し関係を収集（内部関数のみ）
        if item.get("type") == "func":
            calls = [c for c in item.get("calls", []) if isinstance(c, str) and c.startswith("func_")]
            func_calls_map[item["id"]] = calls
            for callee in calls:
                func_callers_map.setdefault(callee, set()).add(item["id"]) 

    print(f"解析済みデータを読み込みました ({len(analysis_data)} ファイル)")

    # 全対象ファイルから関数を抽出
    print("関数を抽出中...")
    all_functions = collect_all_functions(target_files, analysis_data)

    # Write target_functions.csv
    target_functions_csv = output_dir / "target_functions.csv"

    with open(target_functions_csv, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(
            csvfile,
            fieldnames=["file_path", "func_type", "func_id", "func_name"],
        )
        writer.writeheader()
        writer.writerows(all_functions)

    print(f"{target_functions_csv} を生成 ({len(all_functions)} 関数)")

    # target_functions_all.csvの生成（呼び出し先関数も含む）
    print("呼び出し先関数を含む全関数リストを生成中...")
    all_functions_with_calls = collect_all_functions_with_calls(
        all_functions, analysis_data_json
    )

    # Write target_functions_all.csv
    target_functions_all_csv = output_dir / "target_functions_all.csv"
    # caller_num / callee_num を付与
    for f in all_functions_with_calls:
        fid = f.get("func_id")
        f["callee_num"] = len(func_calls_map.get(fid, []))
        f["caller_num"] = len(func_callers_map.get(fid, set()))

    with open(target_functions_all_csv, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(
            csvfile,
            fieldnames=[
                "file_path",
                "func_type",
                "func_id",
                "func_name",
                "caller_num",
                "callee_num",
            ],
        )
        writer.writeheader()
        writer.writerows(all_functions_with_calls)

    print(f"{target_functions_all_csv} を生成 ({len(all_functions_with_calls)} 関数)")


if __name__ == "__main__":
    main()
