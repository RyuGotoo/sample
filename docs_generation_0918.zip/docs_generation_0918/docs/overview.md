# 概要

Cソースコードから生成AIを用いて関数ドキュメントを生成するプロジェクト

# 実行方法

config.jsonを更新
1. config.jsonの内容を確認・更新

ソースコード前処理
1. read時にencoding errorが起きる箇所を削除
   1. python remove_invalid_characters.py dir_path

ソースコード解析
1. c-analyzer を用いて analysis_result.json 取得
2. analysis_result.json を更新
   1. python fix_analysis_result.py analysis_result.json
   2. 古い方を analysis_result_bak.json とし、新しい方を analysis_result.json とする

生成準備
1. outputディレクトリ作成、生成対象の関数リストを取得
   1. python main.py
2. 生成順序を規定（CSV出力）
   1. python determine_generation_order.py
      - generation_order_all.csv（全関数・入力順、先頭にorder列）
      - generation_order_with_caller.csv（caller_num>0のみ・入力順、先頭にorder列）

生成
1. python generate_docs.py
   - 入力: `generation_order_with_caller.csv`（caller_num>0のみ）
   - 外部関数情報: 付与しない（`{external_function_info}` は空）
   - 日本語チェック: `<summary>` の日本語率（ひらがな/カタカナ/漢字の比率）が `language_threshold` 未満なら再試行（履歴は持たず再生成）。
2. python generate_docs.py --with-deps
   - 入力: `generation_order_all.csv`（全関数）
   - 外部関数情報: 付与する（既生成の依存関数情報を `{external_function_info}` に挿入）
   - 追加検証: 依存関数名が `<process-flow>` に少なくとも1回は含まれるかを確認。不足があれば前回XMLを引用し不足指示を付けてリトライ（`max_retries`/`retry_delay_seconds` 準拠）。
   - 日本語チェック: `<summary>` の日本語率がしきい値未満なら再試行（履歴は持たず再生成）。

xmlをmarkdown化
1. 未実装

# 各Pythonファイルの役割

## remove_invalid_characters.py
 - 目的: 指定ディレクトリ配下の全ての「.c」ファイルがUTF-8で読み込めるか事前チェックし、問題があれば自動修正する。
 - 主な処理:
   - UTF-8での読み込み可否を検査し、`--fix`（デフォルト有効）で不正バイトを除去して上書き保存。
   - 成功/修正/失敗のサマリを標準出力に表示。
 - 想定入出力: 引数にディレクトリパスを受け取り、ファイル自体をクリーンアップ。

## fix_analysis_result.py
 - 目的: `analysis_result.json` の不足情報（特に type=proto における `implemented_at` 欠落）を補完する。
 - 主な処理:
   - 同一 `file_path`・`name` の type=func レコードを探索し、`implemented_at` を追記。
   - 補完後の JSON を `<元名>_fixed.json` として保存し、詳細の CSV（実装有無一覧）とログファイルも出力。
 - 想定入出力: 入力に `analysis_result.json`、出力に `analysis_result_fixed.json` と `<stem>_implementation_summary.csv`。

## main.py
 - 目的: 生成対象の C ファイルと関数一覧を作成し、出力ディレクトリに前提データを整える。
 - 主な処理:
   - `config.json` を読み込み、`c_source_dir`・`analysis_result_file`・`target_paths_file`・`output_dir` を参照。
   - 対象 `.c` ファイルを収集し `target_files.csv` を出力。
 - `analysis_result.json` を元に対象ファイル内の type=func のみを抽出し `target_functions.csv` を出力。
  - 呼び出し関係（`calls` の func_）を再帰追跡して依存関数を追加し、`target_functions_all.csv` を出力。
    - 追加列: `caller_num`（当該関数を呼ぶ内部関数数）, `callee_num`（当該関数が呼ぶ内部関数数）。
   - `config.json`、`analysis_result.json`、`target_paths.txt` を `output_dir` にコピー。
 - 想定入出力: 入力に `config.json` と `target_paths.txt`、出力に各種 CSV（files/functions/functions_all）。

## determine_generation_order.py
 - 目的: `target_functions_all.csv` から生成順序用の2つのCSVを作成する（無ソート、入力順を維持）。
 - 主な処理:
   - `config.json` を読み込み `output_dir` を取得。
   - `output_dir/target_functions_all.csv` を読み込み、2ファイルを出力。
     - `generation_order_all.csv`: 全行をそのまま出力し、先頭に `order` 列（1始まりの連番）を追加。
     - `generation_order_with_caller.csv`: `caller_num>0` の行のみ抽出し、同様に `order` 列を付与。
   - 列構成は元CSVを踏襲（`file_path, func_type, func_id, func_name, caller_num, callee_num`）+ `order` を先頭に追加。
 - 想定入出力: 入力に `target_functions_all.csv`、出力に `generation_order_all.csv` と `generation_order_with_caller.csv`。

## generate_docs.py
 - 目的: 生成順序CSVに従って、LLMで各関数の XML ドキュメントを生成・保存する。
 - 主な処理:
   - `config.json` を読み込み、`output_dir`・`analysis_result_file`・プロンプトテンプレート等を参照。ワーカー数（`num_workers`）で並列実行可。
   - 入力CSVをモードで切替:
     - デフォルト: `generation_order_with_caller.csv`（caller>0 のみ）。外部関数情報は付与しない。
     - `--with-deps`: `generation_order_all.csv`（全関数）。外部関数情報を付与（既生成の依存関数の要約埋め込み）。さらに、`<process-flow>` に依存関数名が含まれていない場合は不足指示を付けて再試行（前回XMLを引用）。
   - 言語検証: `<summary>` の日本語率（ひらがな/カタカナ/漢字比）が `language_threshold` 未満なら例外として再試行（履歴は持たない）。
   - `analysis_result.json` の `line_start`/`line_end` で関数ソースを抽出し、プロンプト生成→LLM応答からXML抽出・検証。
   - `doc.xml` と `user_prompt.md` を保存し、`generated_docs.csv` に追記。失敗時はリトライ（`max_retries` と `retry_delay_seconds`）。
 - 想定入出力: 入力に `generation_order_with_caller.csv` または `generation_order_all.csv` と `analysis_result.json`、出力に関数別ディレクトリの `doc.xml`/`user_prompt.md` と `generated_docs.csv`。

### 設定項目（抜粋）
- `language_check_enabled`: `<summary>` の日本語率チェックを有効化（既定: true）。
- `language_threshold`: 日本語率のしきい値（既定: 0.35）。

### ログ出力
- 形式: `[YYYY-MM-DD HH:MM:SS] [LEVEL] [logger:lineno] [w=worker_id f=func_id o=order] メッセージ`。
- 例: 依存不足や日本語率不足時は WARNING、再試行や最終失敗は WARNING/ERROR で記録。

# 用語: caller / callee
- caller: 対象関数を呼び出している「内部関数」（`func_`で始まるIDを持つ関数）。`analysis_result.json` の各 `func` レコードの `calls` に対象の `func_id` が含まれている関数を指す。
- callee: 対象関数が呼び出している「内部関数」。`analysis_result.json` の対象関数レコードの `calls` に列挙された `func_` で始まるIDを指す。
- 集計対象: `caller_num` はユニークな呼び元関数の件数。`callee_num` は `calls` に列挙された内部関数IDの件数（`ext_*` は除外）。いずれも `analysis_result.json` 全体を基準に集計する。
