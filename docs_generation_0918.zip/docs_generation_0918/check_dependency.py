#!/usr/bin/env python3
"""
依存関係のトポロジカルソートと循環参照検出

analysis_result.jsonのidとcallsを使って、
関数間の依存関係をトポロジカルソートし、
循環参照があるかどうかをチェックする
"""

import json
from collections import defaultdict, deque
from typing import Dict, List, Set, Tuple


def load_analysis_result(file_path: str) -> List[Dict]:
    """analysis_result.jsonを読み込む"""
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def build_dependency_graph(data: List[Dict]) -> Tuple[Dict[str, List[str]], Dict[str, Dict]]:
    """
    依存関係グラフを構築
    
    Returns:
        graph: {node_id: [依存先のnode_id, ...]}
        node_info: {node_id: node情報}
    """
    graph = defaultdict(list)
    node_info = {}
    
    # 全ノードを登録
    for item in data:
        node_id = item['id']
        node_info[node_id] = {
            'name': item.get('name', 'unknown'),
            'type': item.get('type', 'unknown'),
            'file_path': item.get('file_path', 'unknown'),
            'line_start': item.get('line_start', 0)
        }
        
        # 依存関係を追加（このノードが呼び出すノード）
        if 'calls' in item and item['calls']:
            for called_id in item['calls']:
                # calls配列には関数IDまたは外部関数名が入っている
                # func_で始まるものだけを依存関係として扱う
                if isinstance(called_id, str) and called_id.startswith('func_'):
                    graph[node_id].append(called_id)
    
    return dict(graph), node_info


def detect_cycles_dfs(graph: Dict[str, List[str]]) -> List[List[str]]:
    """
    DFSを使って循環参照を検出
    
    Returns:
        循環参照のリスト（各循環は関数IDのリスト）
    """
    WHITE = 0  # 未訪問
    GRAY = 1   # 訪問中（現在のパス上にある）
    BLACK = 2  # 訪問済み
    
    color = defaultdict(lambda: WHITE)
    parent = {}
    cycles = []
    
    def find_cycle_path(start: str, end: str) -> List[str]:
        """循環経路を復元"""
        path = [end]
        current = start
        while current != end:
            path.append(current)
            if current not in parent:
                break
            current = parent[current]
        path.reverse()
        return path
    
    def dfs(node: str) -> None:
        """深さ優先探索で循環を検出"""
        if color[node] == BLACK:
            return
        
        color[node] = GRAY
        
        for neighbor in graph.get(node, []):
            if color[neighbor] == GRAY:
                # 循環を発見
                cycle = find_cycle_path(neighbor, node)
                cycles.append(cycle)
            elif color[neighbor] == WHITE:
                parent[neighbor] = node
                dfs(neighbor)
        
        color[node] = BLACK
    
    # 全ノードから探索開始
    for node in graph:
        if color[node] == WHITE:
            dfs(node)
    
    return cycles


def topological_sort_kahn(graph: Dict[str, List[str]], all_nodes: Set[str]) -> Tuple[List[str], bool]:
    """
    Kahnのアルゴリズムでトポロジカルソート
    
    Returns:
        sorted_nodes: トポロジカルソート結果
        has_cycle: 循環があるかどうか
    """
    # 入次数を計算
    in_degree = defaultdict(int)
    
    # 全ノードを初期化
    for node in all_nodes:
        in_degree[node] = 0
    
    # 入次数をカウント
    for node in graph:
        for neighbor in graph[node]:
            if neighbor in all_nodes:  # 存在するノードのみカウント
                in_degree[neighbor] += 1
    
    # 入次数0のノードをキューに追加
    queue = deque([node for node in all_nodes if in_degree[node] == 0])
    sorted_nodes = []
    
    while queue:
        node = queue.popleft()
        sorted_nodes.append(node)
        
        # 隣接ノードの入次数を減らす
        for neighbor in graph.get(node, []):
            if neighbor in all_nodes:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)
    
    # 全ノードが処理されたか確認
    has_cycle = len(sorted_nodes) != len(all_nodes)
    
    return sorted_nodes, has_cycle


def print_results(node_info: Dict, sorted_nodes: List[str], cycles: List[List[str]], graph: Dict[str, List[str]]):
    """結果を見やすく表示"""
    print("=" * 80)
    print("依存関係解析結果")
    print("=" * 80)
    
    # 循環参照の検出結果
    print("\n【循環参照の検出】")
    if cycles:
        print(f"⚠️  {len(cycles)}個の循環参照が見つかりました:")
        for i, cycle in enumerate(cycles, 1):
            print(f"\n  循環 {i}:")
            for j, node_id in enumerate(cycle):
                info = node_info.get(node_id, {})
                arrow = " → " if j < len(cycle) - 1 else " → (循環)"
                print(f"    {info.get('name', node_id)} ({node_id}){arrow}")
    else:
        print("✅ 循環参照はありません")
    
    # トポロジカルソート結果
    print("\n【トポロジカルソート結果】")
    if sorted_nodes:
        print(f"ソート済みノード数: {len(sorted_nodes)}")
        print("\n依存順序（依存されない → 依存される）:")
        
        # レベルごとに分類
        level_nodes = []
        processed = set()
        remaining = set(sorted_nodes)
        
        while remaining:
            # 現在のレベルで処理可能なノード（依存先が全て処理済み）
            current_level = []
            for node in remaining:
                dependencies = graph.get(node, [])
                if all(dep in processed or dep not in remaining for dep in dependencies):
                    current_level.append(node)
            
            if not current_level:
                break
            
            level_nodes.append(current_level)
            for node in current_level:
                processed.add(node)
                remaining.remove(node)
        
        for level, nodes in enumerate(level_nodes):
            print(f"\n  レベル {level + 1}:")
            for node_id in nodes[:10]:  # 最初の10個のみ表示
                info = node_info.get(node_id, {})
                deps = graph.get(node_id, [])
                deps_str = f" → 依存: {len(deps)}個" if deps else ""
                print(f"    - {info.get('name', node_id)} ({info.get('type', 'unknown')}){deps_str}")
            if len(nodes) > 10:
                print(f"    ... 他 {len(nodes) - 10} 個のノード")
    
    # 統計情報
    print("\n【統計情報】")
    print(f"総ノード数: {len(node_info)}")
    print(f"依存関係を持つノード数: {len(graph)}")
    total_edges = sum(len(deps) for deps in graph.values())
    print(f"総依存関係数: {total_edges}")
    
    # 最も依存されているノード
    dependency_count = defaultdict(int)
    for deps in graph.values():
        for dep in deps:
            if dep in node_info:
                dependency_count[dep] += 1
    
    if dependency_count:
        most_depended = sorted(dependency_count.items(), key=lambda x: x[1], reverse=True)[:5]
        print("\n最も依存されているノード（上位5個）:")
        for node_id, count in most_depended:
            info = node_info.get(node_id, {})
            print(f"  - {info.get('name', node_id)}: {count}回依存される")


def main():
    """メイン処理"""
    file_path = "analysis_result.json"
    
    try:
        # データ読み込み
        print(f"ファイル読み込み中: {file_path}")
        data = load_analysis_result(file_path)
        print(f"✅ {len(data)}個のエントリを読み込みました")
        
        # 依存関係グラフを構築
        graph, node_info = build_dependency_graph(data)
        all_nodes = set(node_info.keys())
        
        # 循環参照を検出
        cycles = detect_cycles_dfs(graph)
        
        # トポロジカルソート
        sorted_nodes, has_cycle_kahn = topological_sort_kahn(graph, all_nodes)
        
        # 結果を表示
        print_results(node_info, sorted_nodes, cycles, graph)
        
    except FileNotFoundError:
        print(f"❌ エラー: {file_path} が見つかりません")
    except json.JSONDecodeError as e:
        print(f"❌ JSONパースエラー: {e}")
    except Exception as e:
        print(f"❌ エラーが発生しました: {e}")


if __name__ == "__main__":
    main()