import csv
import json
from pathlib import Path


def load_config(config_path: Path) -> dict:
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


def read_target_functions_all(csv_path: Path) -> tuple[list[dict], list[str]]:
    """target_functions_all.csv を読み込み、行データと列名を返す"""
    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
        fieldnames = reader.fieldnames or []
    return rows, fieldnames


def to_int(value: str, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def write_with_order(rows: list[dict], fieldnames: list[str], out_path: Path) -> None:
    """先頭に order 列を追加して書き出す（元の順序を維持）"""
    order_fieldnames = ["order"] + fieldnames
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=order_fieldnames)
        writer.writeheader()
        for idx, row in enumerate(rows, start=1):
            out_row = {"order": idx}
            out_row.update(row)
            writer.writerow(out_row)


def main():
    print("設定を読み込み中...")
    config_path = Path("./config.json")
    config = load_config(config_path)

    output_dir = Path(config["output_dir"])  # config.json を採用
    target_all_csv = output_dir / "target_functions_all.csv"

    if not target_all_csv.exists():
        raise FileNotFoundError(f"入力が見つかりません: {target_all_csv}")

    print("target_functions_all.csv を読み込み中...")
    rows, fieldnames = read_target_functions_all(target_all_csv)
    print(f"{len(rows)} 行を読み込みました")

    # 出力先パス
    out_all = output_dir / "generation_order_all.csv"
    out_with_caller = output_dir / "generation_order_with_caller.csv"

    # そのまま（無ソート）+ order 付与
    print(f"全件を書き出し: {out_all}")
    write_with_order(rows, fieldnames, out_all)

    # caller_num>0 のみフィルタ（安全のため int 変換）
    print("caller_num>0 の行をフィルタ中...")
    with_caller_rows = [r for r in rows if to_int(r.get("caller_num", "0")) > 0]
    print(f"{len(with_caller_rows)} 行が対象です")

    print(f"callerありを書き出し: {out_with_caller}")
    write_with_order(with_caller_rows, fieldnames, out_with_caller)

    print("完了しました")


if __name__ == "__main__":
    main()
