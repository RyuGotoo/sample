#!/usr/bin/env python3
"""
analysis_result.jsonの不足情報を修正するツール

使用方法:
    python3 fix_analysis_result.py <analysis_result.json>

説明:
    type=protoのレコードでimplemented_atフィールドが欠落しているものを検出し、
    対応するtype=funcレコードを探して補完する。
    修正されたファイルは元ファイルと同じディレクトリにanalysis_result_fixed.jsonとして保存される。
"""

import json
import sys
import csv
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple


def setup_logger(input_path: Path) -> Tuple[logging.Logger, Path]:
    """ロガーの設定とログファイルパスの生成"""
    # タイムスタンプ付きログファイル名を生成
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_filename = f"fix_analysis_result_{timestamp}.log"
    log_path = input_path.parent / log_filename

    # ロガーの設定
    logger = logging.getLogger("fix_analysis_result")
    logger.setLevel(logging.INFO)

    # 既存のハンドラーをクリア
    logger.handlers.clear()

    # ファイルハンドラーの設定
    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setLevel(logging.INFO)

    # コンソールハンドラーの設定
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)

    # フォーマッターの設定
    formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    # ハンドラーを追加
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger, log_path


def parse_arguments(logger: logging.Logger) -> Tuple[Path, Path]:
    """コマンドライン引数をパースし、入出力パスを決定"""
    # 引数の確認
    if len(sys.argv) != 2:
        logger.error("引数が不正です")
        logger.error("使用方法: python3 fix_analysis_result.py <analysis_result.json>")
        sys.exit(1)

    # 入力ファイルパス
    input_path = Path(sys.argv[1])

    # 入力ファイルの存在確認
    if not input_path.exists():
        logger.error(f"入力ファイルが見つかりません: {input_path}")
        sys.exit(1)

    if not input_path.is_file():
        logger.error(f"入力パスがファイルではありません: {input_path}")
        sys.exit(1)

    # 出力ファイルパスを生成（同じディレクトリに_fixedサフィックス付き）
    output_path = input_path.parent / f"{input_path.stem}_fixed{input_path.suffix}"

    return input_path, output_path


def load_json_data(file_path: Path, logger: logging.Logger) -> List[Dict[str, Any]]:
    """JSONファイルの読み込みとパース"""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, list):
            raise ValueError("JSONデータはリストである必要があります")

        logger.info(f"JSONファイルを読み込みました: {len(data)}件のレコード")
        return data

    except json.JSONDecodeError as e:
        logger.error(f"JSONパースエラー: {e}")
        sys.exit(1)
    except Exception as e:
        logger.error(f"ファイル読み込みエラー: {e}")
        sys.exit(1)


def find_implementation(
    records: List[Dict[str, Any]], proto_record: Dict[str, Any]
) -> Optional[str]:
    """
    type=protoレコードに対応するtype=funcレコードを検索

    Args:
        records: 全レコードのリスト
        proto_record: 実装を探すprotoレコード

    Returns:
        見つかった場合はfuncレコードのID、見つからない場合はNone
    """
    target_file_path = proto_record.get("file_path")
    target_name = proto_record.get("name")

    if not target_file_path or not target_name:
        return None

    # 同一file_path、同一nameのtype=funcレコードを検索
    for record in records:
        if (
            record.get("type") == "func"
            and record.get("file_path") == target_file_path
            and record.get("name") == target_name
        ):
            return record["id"]

    return None


def fix_proto_records(
    records: List[Dict[str, Any]],
    logger: logging.Logger,
) -> Tuple[List[Dict[str, Any]], Dict[str, int], List[Dict[str, Any]]]:
    """
    type=protoレコードのimplemented_atフィールドを補完

    Returns:
        修正済みレコードのリスト、統計情報、CSV用詳細データ
    """
    stats = {
        "total_proto": 0,
        "already_has_implemented_at": 0,
        "no_implementation_warning": 0,
        "fixed": 0,
        "error": 0,
    }

    # レコードをコピー（元データを変更しないため）
    fixed_records = []
    # CSV用詳細データ
    csv_data = []

    for record in records:
        # レコードをディープコピー
        fixed_record = record.copy()

        if record.get("type") == "proto":
            stats["total_proto"] += 1

            # CSV用レコードの基本情報
            csv_record = {
                "proto_id": record.get("id", ""),
                "file_path": record.get("file_path", ""),
                "name": record.get("name", ""),
                "status": "",
                "implemented_at": "",
                "notes": "",
            }

            # すでにimplemented_atが存在する場合
            if "implemented_at" in record:
                stats["already_has_implemented_at"] += 1
                csv_record["status"] = "ALREADY_SET"
                csv_record["implemented_at"] = record["implemented_at"]

            # implemented_atを補完する必要がある場合
            else:
                implementation_id = find_implementation(records, record)

                if implementation_id:
                    fixed_record["implemented_at"] = implementation_id
                    stats["fixed"] += 1
                    csv_record["status"] = "FOUND"
                    csv_record["implemented_at"] = implementation_id
                    logger.info(
                        f"implemented_atを追加: {record['id']} -> {implementation_id}"
                    )
                else:
                    stats["error"] += 1
                    csv_record["status"] = "NOT_FOUND"
                    csv_record["notes"] = "実装が見つかりません"
                    logger.warning(
                        f"実装が見つかりません: {record['id']} (file: {record.get('file_path')}, name: {record.get('name')})"
                    )
                    # エラーとして記録するが、処理は継続

            csv_data.append(csv_record)

        fixed_records.append(fixed_record)

    return fixed_records, stats, csv_data


def save_result(
    data: List[Dict[str, Any]], output_path: Path, logger: logging.Logger
) -> None:
    """修正済みデータをJSONファイルとして保存"""
    try:
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        logger.info(f"結果を保存しました: {output_path}")
    except Exception as e:
        logger.error(f"ファイル保存エラー: {e}")
        sys.exit(1)


def save_csv_summary(
    csv_data: List[Dict[str, Any]], csv_path: Path, logger: logging.Logger
) -> None:
    """実装の有無一覧をCSVファイルとして保存"""
    try:
        with open(csv_path, "w", encoding="utf-8-sig", newline="") as f:
            if csv_data:
                fieldnames = [
                    "proto_id",
                    "file_path",
                    "name",
                    "status",
                    "implemented_at",
                    "notes",
                ]
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(csv_data)
        logger.info(f"CSV結果を保存しました: {csv_path}")
    except Exception as e:
        logger.error(f"CSV保存エラー: {e}")


def print_summary(stats: Dict[str, int], logger: logging.Logger) -> None:
    """処理結果のサマリーを表示"""
    logger.info("\n=== 処理結果サマリー ===")
    logger.info(f"総proto数: {stats['total_proto']}")
    logger.info(f"既にimplemented_atあり: {stats['already_has_implemented_at']}")
    logger.info(f"実装なし（警告あり）: {stats['no_implementation_warning']}")
    logger.info(f"修正済み: {stats['fixed']}")
    logger.info(f"エラー（実装が見つからない）: {stats['error']}")
    logger.info("========================\n")


def main():
    """メイン処理"""
    # 最初に引数を取得（ロガー設定前）
    if len(sys.argv) != 2:
        print("エラー: 引数が不正です")
        print("使用方法: python3 fix_analysis_result.py <analysis_result.json>")
        sys.exit(1)

    input_path = Path(sys.argv[1])

    # ロガーの設定
    logger, log_path = setup_logger(input_path)
    logger.info(f"ログファイル: {log_path}")

    # コマンドライン引数をパース
    input_path, output_path = parse_arguments(logger)

    logger.info(f"入力ファイル: {input_path}")
    logger.info(f"出力ファイル: {output_path}")
    logger.info("処理を開始します...")

    # データ読み込み
    records = load_json_data(input_path, logger)

    # implemented_at補完処理
    fixed_records, stats, csv_data = fix_proto_records(records, logger)

    # 結果保存
    save_result(fixed_records, output_path, logger)

    # CSV結果保存
    csv_path = input_path.parent / f"{input_path.stem}_implementation_summary.csv"
    save_csv_summary(csv_data, csv_path, logger)

    # サマリー表示
    print_summary(stats, logger)

    # エラーがある場合は警告
    if stats["error"] > 0:
        logger.warning(
            f"\n注意: {stats['error']}件のレコードで実装が見つかりませんでした。"
        )

    logger.info("処理が完了しました。")
    logger.info(f"ログファイルが保存されました: {log_path}")


if __name__ == "__main__":
    main()
