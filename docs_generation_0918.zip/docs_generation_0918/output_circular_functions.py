import csv
import json
from pathlib import Path
from collections import defaultdict


def tarjan_scc(graph: dict) -> list[list[str]]:
    """
    Tarjanのアルゴリズムで強連結成分（SCC）を検出する。

    Args:
        graph: 隣接リスト形式のグラフ（func_id -> [呼び出し先func_idのリスト]）

    Returns:
        list[list[str]]: 強連結成分のリスト（各要素は関数IDのリスト）
    """
    index_counter = [0]
    stack = []
    lowlinks = {}
    indices = {}
    on_stack = {}
    sccs = []

    def strongconnect(node):
        # nodeにindexを設定
        indices[node] = index_counter[0]
        lowlinks[node] = index_counter[0]
        index_counter[0] += 1
        stack.append(node)
        on_stack[node] = True

        # nodeから到達可能な全てのノードを確認
        for neighbor in graph.get(node, []):
            if neighbor not in indices:
                # まだ訪問していない場合は再帰的に処理
                strongconnect(neighbor)
                lowlinks[node] = min(lowlinks[node], lowlinks[neighbor])
            elif on_stack.get(neighbor, False):
                # スタック上にある場合は循環を検出
                lowlinks[node] = min(lowlinks[node], indices[neighbor])

        # nodeがrootノードの場合、SCCを出力
        if lowlinks[node] == indices[node]:
            scc = []
            while True:
                w = stack.pop()
                on_stack[w] = False
                scc.append(w)
                if w == node:
                    break
            sccs.append(scc)

    # 全てのノードに対して実行
    all_nodes = set(graph.keys())
    for neighbor_list in graph.values():
        all_nodes.update(neighbor_list)

    for node in all_nodes:
        if node not in indices:
            strongconnect(node)

    return sccs


def identify_circular_functions(sccs: list[list[str]]) -> set[str]:
    """
    強連結成分から循環に関与する関数IDセットを特定する。

    Args:
        sccs: 強連結成分のリスト

    Returns:
        set[str]: 循環に関与する関数IDのセット
    """
    circular_func_ids = set()
    for scc in sccs:
        # 2個以上の要素を持つSCCは循環グループ
        if len(scc) > 1:
            circular_func_ids.update(scc)
    return circular_func_ids


def build_call_graph(functions: list[dict], analysis_data: list[dict]) -> dict:
    """
    関数の呼び出し関係グラフを構築する（SCC検出用）。

    Args:
        functions: 関数情報のリスト
        analysis_data: 解析データ

    Returns:
        dict: 呼び出しグラフ（func_id -> [呼び出し先func_idのリスト]）
    """
    func_ids = {func["func_id"] for func in functions}
    call_graph = defaultdict(list)

    # analysis_dataから呼び出し関係を構築
    for item in analysis_data:
        if item.get("type") == "func" and item.get("id") in func_ids:
            func_id = item["id"]
            calls = item.get("calls", [])

            for call_name in calls:
                # func_で始まる呼び出し（内部関数呼び出し）のみ処理
                if call_name.startswith("func_") and call_name in func_ids:
                    # func_id が call_name を呼び出している
                    call_graph[func_id].append(call_name)

    return dict(call_graph)


def count_func_dependencies(func_id: str, analysis_data: list[dict]) -> int:
    """
    指定された関数のfunc_呼び出し数をカウントする。

    Args:
        func_id: 対象関数のID
        analysis_data: 解析データ

    Returns:
        int: func_で始まる呼び出し数
    """
    for item in analysis_data:
        if item.get("type") == "func" and item.get("id") == func_id:
            calls = item.get("calls", [])
            # func_で始まる呼び出しのみカウント
            func_calls = [call for call in calls if call.startswith("func_")]
            return len(func_calls)
    return 0


def output_circular_functions_csv(circular_functions: list[dict], output_path: Path):
    """
    循環参照関数をCSVで出力する。

    Args:
        circular_functions: 循環参照関数のリスト
        output_path: 出力ファイルパス
    """
    fieldnames = ["func_id", "func_name", "file_path", "deps_num"]

    with open(output_path, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for func in circular_functions:
            output_row = {
                "func_id": func["func_id"],
                "func_name": func["func_name"],
                "file_path": func["file_path"],
                "deps_num": func["deps_num"],
            }
            writer.writerow(output_row)


def main():
    """
    メイン処理：循環参照のある関数を検出してCSVで出力する。
    """
    print("設定を読み込み中...")
    settings_path = Path("./settings.json")
    with open(settings_path, "r", encoding="utf-8") as f:
        settings = json.load(f)

    output_dir = Path(settings["output_dir"])
    analysis_file = Path(settings["analysis_result_file"])

    # ファイルパス設定
    target_functions_all_csv = output_dir / "target_functions_all.csv"
    circular_functions_csv = output_dir / "circular_functions.csv"

    print("関数リストを読み込み中...")
    functions = []
    with open(target_functions_all_csv, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            functions.append(row)
    print(f"{len(functions)} 個の関数を読み込みました")

    print("解析データを読み込み中...")
    with open(analysis_file, "r", encoding="utf-8") as f:
        analysis_data = json.load(f)
    print("解析データを読み込みました")

    print("呼び出し関係グラフを構築中...")
    call_graph = build_call_graph(functions, analysis_data)
    print("呼び出し関係グラフを構築しました")

    print("強連結成分を検出中...")
    sccs = tarjan_scc(call_graph)
    circular_func_ids = identify_circular_functions(sccs)
    print(f"循環参照関数を検出しました: {len(circular_func_ids)} 個")

    print("循環参照関数の詳細情報を収集中...")
    circular_functions = []

    for func in functions:
        func_id = func["func_id"]
        if func_id in circular_func_ids:
            # 依存数を計算
            deps_count = count_func_dependencies(func_id, analysis_data)

            circular_func = {
                "func_id": func_id,
                "func_name": func["func_name"],
                "file_path": func["file_path"],
                "deps_num": deps_count,
            }
            circular_functions.append(circular_func)

    print(f"循環参照関数をCSVで出力中: {circular_functions_csv}")
    output_circular_functions_csv(circular_functions, circular_functions_csv)

    # 統計情報を表示
    if circular_functions:
        deps_counts = [func["deps_num"] for func in circular_functions]
        print(f"循環参照関数の依存数統計:")
        print(f"  最小: {min(deps_counts)}")
        print(f"  最大: {max(deps_counts)}")
        print(f"  平均: {sum(deps_counts) / len(deps_counts):.2f}")

    print("完了しました")


if __name__ == "__main__":
    main()
