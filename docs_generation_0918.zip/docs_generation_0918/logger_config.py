#!/usr/bin/env python3
"""
ログ設定モジュール

統一されたロガー設定を提供し、ファイルハンドラーとコンソールハンドラーを設定する。
ログローテーション機能も含む。
"""

import logging
import logging.handlers
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional


class ContextFormatter(logging.Formatter):
    """不足する拡張コンテキスト（worker_id/func_id/func_order）をデフォルト補完するフォーマッター"""

    def format(self, record: logging.LogRecord) -> str:
        # 追加フィールドが未設定でも KeyError にならないように補完
        if not hasattr(record, "worker_id"):
            record.worker_id = "-"
        if not hasattr(record, "func_id"):
            record.func_id = "-"
        if not hasattr(record, "func_order"):
            record.func_order = "-"
        return super().format(record)


def setup_logger(
    name: str,
    output_dir: Path,
    level: str = "INFO",
    console_output: bool = True,
    file_output: bool = True,
    max_bytes: int = 10 * 1024 * 1024,  # 10MB
    backup_count: int = 5,
) -> logging.Logger:
    """ロガーを設定する

    Args:
        name: ロガー名
        output_dir: ログファイルの出力ディレクトリ
        level: ログレベル (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        console_output: コンソール出力の有効/無効
        file_output: ファイル出力の有効/無効
        max_bytes: ログファイルの最大サイズ（バイト）
        backup_count: バックアップファイルの数

    Returns:
        設定済みのロガー
    """
    # ロガーを取得
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, level.upper()))

    # 既存のハンドラーをクリア
    logger.handlers.clear()

    # フォーマッターを作成
    formatter = ContextFormatter(
        "[%(asctime)s] [%(levelname)s] [%(name)s:%(lineno)d] "
        "[w=%(worker_id)s f=%(func_id)s o=%(func_order)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # コンソールハンドラーを追加
    if console_output:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        console_handler.setLevel(getattr(logging, level.upper()))
        logger.addHandler(console_handler)

    # ファイルハンドラーを追加
    if file_output:
        # ログディレクトリを作成
        log_dir = output_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)

        # タイムスタンプ付きのログファイル名
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        # 通常ログ用のファイルハンドラー
        log_file = log_dir / f"generate_docs_{timestamp}.log"
        file_handler = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding="utf-8",
        )
        file_handler.setFormatter(formatter)
        file_handler.setLevel(getattr(logging, level.upper()))
        logger.addHandler(file_handler)

        # エラーログ用のファイルハンドラー
        error_log_file = log_dir / f"errors_{timestamp}.log"
        error_handler = logging.handlers.RotatingFileHandler(
            error_log_file,
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding="utf-8",
        )
        error_handler.setFormatter(formatter)
        error_handler.setLevel(logging.ERROR)
        logger.addHandler(error_handler)

    return logger


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """既存のロガーを取得する

    Args:
        name: ロガー名（Noneの場合はルートロガー）

    Returns:
        ロガーインスタンス
    """
    return logging.getLogger(name)
