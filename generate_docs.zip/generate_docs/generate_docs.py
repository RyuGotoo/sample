import json
import csv
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Set, Dict
from enum import Enum
from datetime import datetime
from llm import chat_completions


@dataclass
class FunctionInfo:
    """関数情報を管理するデータクラス"""
    id: str
    name: str
    file_path: str
    line_start: int
    line_end: int
    signature: str
    source_code: Optional[str] = None
    calls: List[str] = None
    
    def __post_init__(self):
        if self.calls is None:
            self.calls = []


def load_analysis_result(json_path: str = "analysis_result.json") -> dict:
    """analysis_result.jsonを読み込む"""
    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"エラー: {json_path} が見つかりません")
        return {}
    except json.JSONDecodeError as e:
        print(f"エラー: {json_path} のJSON形式が不正です: {e}")
        return {}
    except Exception as e:
        print(f"エラー: {json_path} の読み込みに失敗: {e}")
        return {}


def extract_function_info(analysis_data: dict, target_files: List[str]) -> List[FunctionInfo]:
    """対象ファイルから関数情報を抽出（*.cファイルのfunc型のみ）"""
    functions = []
    
    if not analysis_data:
        print("警告: analysis_result.jsonが空またはロードできませんでした")
        return functions
    
    # target_filesを正規化（絶対パス化）
    target_files_normalized = [str(Path(f).resolve()) for f in target_files]
    
    for item in analysis_data:
        # func型のみを対象（protoは除外）
        if item.get('type') != 'func':
            continue
            
        file_path = item.get('file_path', '')
        # .cファイルのみを対象（.hファイルは除外）
        if not file_path.endswith('.c'):
            continue
            
        # ファイルパスを正規化して比較
        file_path_normalized = str(Path(file_path).resolve())
        
        # 対象ファイルに含まれる関数のみを抽出
        if file_path_normalized in target_files_normalized:
            func_info = FunctionInfo(
                id=item.get('id', ''),
                name=item.get('name', ''),
                file_path=file_path,
                line_start=item.get('line_start', 0),
                line_end=item.get('line_end', 0),
                signature=item.get('signature', ''),
                calls=item.get('calls', [])
            )
            functions.append(func_info)
    
    return functions


def extract_source_code(file_path: str, line_start: int, line_end: int) -> str:
    """指定行数範囲のソースコードを抽出"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        # 行番号は1ベース、リストは0ベースなので調整
        start_idx = max(0, line_start - 1)
        end_idx = min(len(lines), line_end)
        
        if start_idx >= len(lines):
            return f"# エラー: 行番号 {line_start} がファイルの範囲を超えています"
        
        return ''.join(lines[start_idx:end_idx])
        
    except FileNotFoundError:
        return f"# エラー: ファイル '{file_path}' が見つかりません"
    except Exception as e:
        return f"# エラー: ソースコード抽出に失敗: {e}"


def resolve_proto_to_func(proto_item: dict, analysis_data: dict) -> Optional[dict]:
    """
    proto型をfunc型に解決する
    1. implemented_atがあればそのfunc_idを使用
    2. なければ同じfile_path + name + type=funcを検索
    """
    # 1. implemented_atフィールドをチェック
    if 'implemented_at' in proto_item:
        func_id = proto_item['implemented_at']
        # func_idでanalysis_dataから検索
        for item in analysis_data:
            if item.get('id') == func_id and item.get('type') == 'func':
                return item
        print(f"警告: implemented_at '{func_id}' が見つかりません: {proto_item.get('name')}")
    
    # 2. file_path + name + type=funcで検索
    proto_file_path = proto_item.get('file_path', '')
    proto_name = proto_item.get('name', '')
    
    for item in analysis_data:
        if (item.get('type') == 'func' and 
            item.get('name') == proto_name and 
            item.get('file_path') == proto_file_path):
            return item
    
    # 見つからない場合
    print(f"警告: proto '{proto_name}' に対応するfunc実装が見つかりません: {proto_file_path}")
    return None


class DependencyGraph:
    """関数間の依存関係を管理するグラフクラス"""
    
    def __init__(self):
        self.nodes: Dict[str, FunctionInfo] = {}  # function_id -> FunctionInfo
        self.edges: Dict[str, Set[str]] = {}  # function_id -> set of dependent function_ids
        self.reverse_edges: Dict[str, Set[str]] = {}  # function_id -> set of functions that depend on this
    
    def add_function(self, func_info: FunctionInfo) -> None:
        """関数をグラフに追加"""
        self.nodes[func_info.id] = func_info
        if func_info.id not in self.edges:
            self.edges[func_info.id] = set()
            self.reverse_edges[func_info.id] = set()
    
    def add_dependency(self, from_func_id: str, to_func_id: str) -> None:
        """依存関係を追加 (from_func depends on to_func)"""
        if from_func_id in self.edges and to_func_id in self.nodes:
            self.edges[from_func_id].add(to_func_id)
            self.reverse_edges[to_func_id].add(from_func_id)
    
    def get_dependencies(self, func_id: str) -> Set[str]:
        """指定関数が依存している関数のIDセットを取得"""
        return self.edges.get(func_id, set())
    
    def get_dependents(self, func_id: str) -> Set[str]:
        """指定関数に依存している関数のIDセットを取得"""
        return self.reverse_edges.get(func_id, set())
    
    def get_all_function_ids(self) -> Set[str]:
        """全関数IDを取得"""
        return set(self.nodes.keys())
    
    def get_function_info(self, func_id: str) -> Optional[FunctionInfo]:
        """関数情報を取得"""
        return self.nodes.get(func_id)


def build_dependency_graph(functions: List[FunctionInfo], analysis_data: dict) -> DependencyGraph:
    """FunctionInfoリストから依存関係グラフを構築（proto型を対応するfunc型に解決）"""
    graph = DependencyGraph()
    
    # 全関数をグラフに追加 
    for func in functions:
        graph.add_function(func)
    
    # 関数IDのマッピングを作成（名前 -> ID）
    name_to_id = {func.name: func.id for func in functions}
    
    # proto_id -> func_idのマッピングを作成
    proto_to_func = {}
    for item in analysis_data:
        if item.get('type') == 'proto':
            resolved_func = resolve_proto_to_func(item, analysis_data)
            if resolved_func:
                proto_to_func[item.get('id')] = resolved_func.get('id')
    
    # 依存関係を構築
    for func in functions:
        for call_name in func.calls:
            # 外部関数（ext_で始まる）は除外
            if call_name.startswith('ext_'):
                continue
            
            called_func_id = None
            
            # func_で始まる場合は直接ID
            if call_name.startswith('func_'):
                called_func_id = call_name
            # proto_で始まる場合はprotoをfuncに解決
            elif call_name.startswith('proto_'):
                called_func_id = proto_to_func.get(call_name)
            # その他は名前からIDを探索
            else:
                called_func_id = name_to_id.get(call_name)
            
            if called_func_id and called_func_id in graph.nodes:
                graph.add_dependency(func.id, called_func_id)
    
    return graph


def detect_circular_dependencies(graph: DependencyGraph) -> List[List[str]]:
    """循環依存を検出してパスを返す"""
    WHITE, GRAY, BLACK = 0, 1, 2
    colors = {func_id: WHITE for func_id in graph.get_all_function_ids()}
    cycles = []
    current_path = []
    
    def dfs(func_id: str) -> bool:
        """深度優先探索で循環を検出"""
        if colors[func_id] == GRAY:  # 循環発見
            # 循環パスを抽出
            cycle_start = current_path.index(func_id)
            cycle = current_path[cycle_start:] + [func_id]
            cycles.append(cycle)
            return True
        
        if colors[func_id] == BLACK:  # 既に処理済み
            return False
        
        colors[func_id] = GRAY
        current_path.append(func_id)
        
        # 依存関数を調査
        for dep_func_id in graph.get_dependencies(func_id):
            if dfs(dep_func_id):
                break  # 循環発見時は探索を停止
        
        current_path.pop()
        colors[func_id] = BLACK
        return False
    
    # 全ノードから探索開始
    for func_id in graph.get_all_function_ids():
        if colors[func_id] == WHITE:
            dfs(func_id)
    
    return cycles


def get_dependency_order(graph: DependencyGraph) -> List[str]:
    """トポロジカルソートで依存順序を決定（依存される関数を先に生成）"""
    in_degree = {func_id: 0 for func_id in graph.get_all_function_ids()}
    
    # 各ノードの入次数を計算（依存する関数から依存される関数への方向）
    for func_id in graph.get_all_function_ids():
        # func_idが依存している関数たちに対して、func_idから依存先への入次数を設定
        for dep_func_id in graph.get_dependencies(func_id):
            in_degree[func_id] += 1  # func_idが依存しているので、func_idの入次数を増やす
    
    # 入次数が0のノード（誰にも依存していない関数）から開始
    queue = [func_id for func_id, degree in in_degree.items() if degree == 0]
    result = []
    
    while queue:
        current = queue.pop(0)
        result.append(current)
        
        # currentに依存している関数たちの入次数を減らす
        for dependent_func_id in graph.get_dependents(current):
            in_degree[dependent_func_id] -= 1
            if in_degree[dependent_func_id] == 0:
                queue.append(dependent_func_id)
    
    # 全ノードが処理されていない場合は循環依存が存在
    if len(result) != len(graph.get_all_function_ids()):
        print("警告: 循環依存により完全なトポロジカルソートができませんでした")
        # 残りのノードも追加
        remaining = graph.get_all_function_ids() - set(result)
        result.extend(remaining)
    
    return result


class GenerationStatus(Enum):
    """ドキュメント生成状況"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"  # 既に生成済みでスキップ


@dataclass
class GenerationTask:
    """個別の生成タスク"""
    function_id: str
    function_name: str
    file_path: str
    output_dir: str  # docs/配下の出力ディレクトリパス
    status: GenerationStatus = GenerationStatus.PENDING
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    error_message: Optional[str] = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now().isoformat()
        if self.updated_at is None:
            self.updated_at = self.created_at


class GenerationPlan:
    """ドキュメント生成計画を管理するクラス"""
    
    def __init__(self, plan_file: str = "generation_plan.json"):
        self.plan_file = plan_file
        self.tasks: Dict[str, GenerationTask] = {}
        self.creation_time: str = datetime.now().isoformat()
        self.last_updated: str = self.creation_time
    
    def add_task(self, task: GenerationTask) -> None:
        """タスクを追加"""
        self.tasks[task.function_id] = task
        self.last_updated = datetime.now().isoformat()
    
    def get_task(self, function_id: str) -> Optional[GenerationTask]:
        """タスクを取得"""
        return self.tasks.get(function_id)
    
    def update_task_status(self, function_id: str, status: GenerationStatus, error_message: Optional[str] = None) -> None:
        """タスクの状況を更新"""
        if function_id in self.tasks:
            self.tasks[function_id].status = status
            self.tasks[function_id].updated_at = datetime.now().isoformat()
            if error_message:
                self.tasks[function_id].error_message = error_message
            self.last_updated = datetime.now().isoformat()
    
    def get_tasks_by_status(self, status: GenerationStatus) -> List[GenerationTask]:
        """指定状況のタスク一覧を取得"""
        return [task for task in self.tasks.values() if task.status == status]
    
    def get_statistics(self) -> Dict[str, int]:
        """生成統計を取得"""
        stats = {}
        for status in GenerationStatus:
            stats[status.value] = len(self.get_tasks_by_status(status))
        return stats
    
    def save(self) -> None:
        """計画をJSONファイルに保存"""
        data = {
            "creation_time": self.creation_time,
            "last_updated": self.last_updated,
            "tasks": {}
        }
        
        for func_id, task in self.tasks.items():
            data["tasks"][func_id] = {
                "function_id": task.function_id,
                "function_name": task.function_name,
                "file_path": task.file_path,
                "output_dir": task.output_dir,
                "status": task.status.value,
                "created_at": task.created_at,
                "updated_at": task.updated_at,
                "error_message": task.error_message
            }
        
        try:
            with open(self.plan_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"エラー: 生成計画の保存に失敗: {e}")
    
    def load(self) -> bool:
        """計画をJSONファイルから読み込み"""
        try:
            with open(self.plan_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            self.creation_time = data.get("creation_time", datetime.now().isoformat())
            self.last_updated = data.get("last_updated", self.creation_time)
            
            for func_id, task_data in data.get("tasks", {}).items():
                task = GenerationTask(
                    function_id=task_data["function_id"],
                    function_name=task_data["function_name"],
                    file_path=task_data["file_path"],
                    output_dir=task_data["output_dir"],
                    status=GenerationStatus(task_data["status"]),
                    created_at=task_data.get("created_at"),
                    updated_at=task_data.get("updated_at"),
                    error_message=task_data.get("error_message")
                )
                self.tasks[func_id] = task
            
            return True
        except FileNotFoundError:
            return False
        except Exception as e:
            print(f"エラー: 生成計画の読み込みに失敗: {e}")
            return False


def check_existing_docs(func_info: FunctionInfo, base_output_dir: str = "generated_docs") -> bool:
    """既存のドキュメントが存在するかチェック"""
    # 出力ディレクトリパスを構築
    original_path = Path(func_info.file_path)
    
    # generated_docs/配下のパスを構築
    docs_dir = Path(base_output_dir) / original_path / func_info.name
    generated_doc_path = docs_dir / "generated_doc.xml"
    
    return generated_doc_path.exists()


def create_output_dir_path(func_info: FunctionInfo, base_output_dir: str = "generated_docs") -> str:
    """出力ディレクトリパスを作成"""
    original_path = Path(func_info.file_path)
    docs_dir = Path(base_output_dir) / original_path / func_info.name
    return str(docs_dir)


def create_generation_plan(functions: List[FunctionInfo], dependency_order: List[str]) -> GenerationPlan:
    """依存順序に基づく生成計画を作成"""
    plan = GenerationPlan()
    
    # 新しい生成計画を作成（メモリ上のみ）
    print("新しい生成計画をメモリ上に作成します")
    
    # 関数情報をIDでインデックス化
    func_by_id = {func.id: func for func in functions}
    
    # 依存順序に従ってタスクを作成/更新
    for func_id in dependency_order:
        if func_id not in func_by_id:
            continue
        
        func_info = func_by_id[func_id]
        output_dir = create_output_dir_path(func_info)
        
        # 新しいタスクを作成（毎回初期化）
        status = GenerationStatus.PENDING
        print(f"  タスク {func_info.name}: 新規タスク -> PENDING")
        
        task = GenerationTask(
            function_id=func_id,
            function_name=func_info.name,
            file_path=func_info.file_path,
            output_dir=output_dir,
            status=status
        )
        plan.add_task(task)
    
    # 計画をメモリ上で管理（ファイル出力は行わない）
    return plan


def save_generation_progress(plan: GenerationPlan) -> None:
    """生成進捗を保存（メモリ上のみ、ファイル出力は行わない）"""
    # CSVで進捗管理するため、ファイル出力は行わない
    pass


def collect_dependency_info(func_info: FunctionInfo, dependency_graph: DependencyGraph, base_output_dir: str = "generated_docs") -> str:
    """依存関数の生成済みドキュメント情報を収集"""
    dependencies = dependency_graph.get_dependencies(func_info.id)
    
    if not dependencies:
        return "この関数は他の関数に依存していません。"
    
    dependency_docs = []
    
    for dep_func_id in dependencies:
        dep_func_info = dependency_graph.get_function_info(dep_func_id)
        if not dep_func_info:
            continue
        
        # 依存関数のドキュメントパスを構築
        dep_output_dir = create_output_dir_path(dep_func_info, base_output_dir)
        dep_doc_path = Path(dep_output_dir) / "generated_doc.xml"
        
        if dep_doc_path.exists():
            try:
                with open(dep_doc_path, 'r', encoding='utf-8') as f:
                    doc_content = f.read()
                dependency_docs.append(f"## 依存関数: {dep_func_info.name}\n\n{doc_content}\n")
            except Exception as e:
                dependency_docs.append(f"## 依存関数: {dep_func_info.name}\n\n生成済みドキュメントの読み込みに失敗: {e}\n")
        else:
            dependency_docs.append(f"## 依存関数: {dep_func_info.name}\n\nまだドキュメントが生成されていません。\n")
    
    if dependency_docs:
        return "\n".join(dependency_docs)
    else:
        return "依存関数のドキュメントがまだ生成されていません。"


def generate_prompts(func_info: FunctionInfo, dependency_graph: DependencyGraph, base_output_dir: str = "generated_docs") -> tuple[str, str]:
    """指定関数のプロンプトを生成"""
    
    # sys_prompt.mdを読み込み
    try:
        with open("prompts/sys_prompt.md", 'r', encoding='utf-8') as f:
            sys_prompt = f.read()
    except FileNotFoundError:
        sys_prompt = "システムプロンプトファイル (prompts/sys_prompt.md) が見つかりません。"
    except Exception as e:
        sys_prompt = f"システムプロンプトの読み込みに失敗: {e}"
    
    # user_prompt.mdを読み込み
    try:
        with open("prompts/user_prompt.md", 'r', encoding='utf-8') as f:
            user_prompt_template = f.read()
    except FileNotFoundError:
        user_prompt_template = "ユーザープロンプトファイル (prompts/user_prompt.md) が見つかりません。"
    except Exception as e:
        user_prompt_template = f"ユーザープロンプトの読み込みに失敗: {e}"
    
    # 依存関数情報を収集
    external_function_info = collect_dependency_info(func_info, dependency_graph, base_output_dir)
    
    # プレースホルダを置換
    user_prompt = user_prompt_template.replace("{c_source}", func_info.source_code or "ソースコードが取得できませんでした。")
    user_prompt = user_prompt.replace("{external_function_info}", external_function_info)
    
    return sys_prompt, user_prompt


def save_prompt_files(func_info: FunctionInfo, sys_prompt: str, user_prompt: str) -> None:
    """生成したプロンプトをファイルに保存"""
    output_dir = Path(create_output_dir_path(func_info))
    
    # 出力ディレクトリを作成
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # sys_prompt.mdを保存
    sys_prompt_path = output_dir / "sys_prompt.md"
    try:
        with open(sys_prompt_path, 'w', encoding='utf-8') as f:
            f.write(sys_prompt)
    except Exception as e:
        print(f"エラー: sys_prompt.mdの保存に失敗: {e}")
    
    # user_prompt.mdを保存
    user_prompt_path = output_dir / "user_prompt.md"
    try:
        with open(user_prompt_path, 'w', encoding='utf-8') as f:
            f.write(user_prompt)
    except Exception as e:
        print(f"エラー: user_prompt.mdの保存に失敗: {e}")


def save_generated_document(func_info: FunctionInfo, xml_content: str) -> None:
    """生成されたXMLドキュメントを保存"""
    output_dir = Path(create_output_dir_path(func_info))
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # generated_doc.xmlを保存
    doc_path = output_dir / "generated_doc.xml"
    try:
        with open(doc_path, 'w', encoding='utf-8') as f:
            f.write(xml_content)
        print(f"✅ ドキュメント保存完了: {doc_path}")
    except Exception as e:
        print(f"❌ ドキュメント保存失敗: {e}")
        raise


def generate_documentation(func_info: FunctionInfo, dependency_graph: DependencyGraph, base_output_dir: str = "generated_docs") -> str:
    """指定関数のドキュメントを生成"""
    
    # プロンプトを生成
    sys_prompt, user_prompt = generate_prompts(func_info, dependency_graph, base_output_dir)
    
    try:
        # LLMを呼び出してドキュメント生成
        print(f"  LLM呼び出し開始: {func_info.name}")
        result = chat_completions(sys_prompt, user_prompt)
        
        # 現在のllm.pyは実際にはモックなので、結果をチェック
        if result.startswith("len(sys_prompt):"):
            # モック結果の場合、サンプルXMLを生成
            sample_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<function>
  <name>{func_info.name}</name>
  <purpose>この関数の目的は現在解析中です（LLMモック使用中）</purpose>
  <summary>関数 {func_info.name} の基本的な動作について。</summary>
  <arguments>
    <arg>
      <name>引数情報</name>
      <type>未解析</type>
      <description>LLMによる解析が必要です</description>
    </arg>
  </arguments>
  <return-value>
    <type>未解析</type>
    <description>LLMによる解析が必要です</description>
  </return-value>
  <remarks>現在LLMモックを使用中のため、サンプルXMLを出力しています。実際のLLM実装時に正確なドキュメントが生成されます。</remarks>
  <process-flow>
    <step>1. 関数の処理開始</step>
    <step>2. 処理内容の解析（要LLM実装）</step>
    <step>3. 関数の処理終了</step>
  </process-flow>
  <database-queries>
    <!-- データベースアクセスがある場合に記載 -->
  </database-queries>
</function>"""
            print(f"  ⚠️  LLMモック検出: サンプルXMLを生成")
            return sample_xml
        else:
            # 実際のLLM結果
            print(f"  ✅ LLM呼び出し完了")
            return result
            
    except Exception as e:
        print(f"  ❌ LLM呼び出し失敗: {e}")
        raise


def process_generation_tasks(generation_plan: GenerationPlan, functions: List[FunctionInfo], 
                           dependency_graph: DependencyGraph, dependency_order: List[str], base_output_dir: str = "generated_docs") -> None:
    """生成計画に基づいてタスクを処理"""
    
    # 関数情報をIDでインデックス化
    func_by_id = {func.id: func for func in functions}
    
    # 実行対象タスクを決定
    pending_tasks = generation_plan.get_tasks_by_status(GenerationStatus.PENDING)
    
    print(f"全タスク実行: {len(pending_tasks)}個のタスクを処理")
    
    if not pending_tasks:
        print("実行対象のタスクがありません")
        return
    
    # 依存順序に従ってタスクを処理
    processed_count = 0
    failed_count = 0
    
    for task in pending_tasks:
        func_info = func_by_id.get(task.function_id)
        if not func_info:
            print(f"❌ 関数情報が見つかりません: {task.function_id}")
            continue
        
        print(f"\n[{processed_count + 1}/{len(pending_tasks)}] 処理中: {func_info.name}")
        print(f"  ファイル: {func_info.file_path}")
        print(f"  出力先: {task.output_dir}")
        
        try:
            # タスクを IN_PROGRESS に更新
            generation_plan.update_task_status(task.function_id, GenerationStatus.IN_PROGRESS)
            
            # ドキュメント生成
            xml_content = generate_documentation(func_info, dependency_graph, base_output_dir)
            
            # ドキュメント保存
            save_generated_document(func_info, xml_content)
            
            # タスクを COMPLETED に更新
            generation_plan.update_task_status(task.function_id, GenerationStatus.COMPLETED)
            processed_count += 1
            
            print(f"  ✅ 完了: {func_info.name}")
            
        except Exception as e:
            # タスクを FAILED に更新
            generation_plan.update_task_status(task.function_id, GenerationStatus.FAILED, str(e))
            failed_count += 1
            
            print(f"  ❌ 失敗: {func_info.name} - {e}")
            
        # 進捗をメモリ上で管理（CSV出力のみ）
    
    print(f"\n=== 処理完了 ===")
    print(f"成功: {processed_count}個")
    print(f"失敗: {failed_count}個")
    print(f"合計: {processed_count + failed_count}個")
    
    # 最終統計
    stats = generation_plan.get_statistics()
    print(f"\n=== 全体統計 ===")
    print(f"PENDING:     {stats['pending']:2d} 個")
    print(f"IN_PROGRESS: {stats['in_progress']:2d} 個")
    print(f"COMPLETED:   {stats['completed']:2d} 個")
    print(f"FAILED:      {stats['failed']:2d} 個")
    print(f"SKIPPED:     {stats['skipped']:2d} 個")


def extract_all_items_info(analysis_data: dict, target_files: List[str]) -> List[dict]:
    """
    対象ファイルから全項目情報を抽出（func型、proto型、ヘッダファイル含む）
    CSV出力用
    """
    all_items = []
    
    if not analysis_data:
        return all_items
    
    # target_filesを正規化（絶対パス化）
    target_files_normalized = [str(Path(f).resolve()) for f in target_files]
    
    for item in analysis_data:
        file_path = item.get('file_path', '')
        file_path_normalized = str(Path(file_path).resolve())
        
        # 対象ファイルに含まれるもののみを抽出
        if file_path_normalized in target_files_normalized:
            all_items.append(item)
    
    return all_items


def generate_csv_summary(all_items: List[dict], functions: List[FunctionInfo], 
                        dependency_order: List[str], output_file: str, generation_plan: Optional['GenerationPlan'] = None) -> None:
    """
    処理順序と進捗状況をまとめたCSVを生成
    """
    # 生成順序のマッピングを作成（func型のみ）
    func_order_map = {}
    order = 1
    for func_id in dependency_order:
        func_order_map[func_id] = order
        order += 1
    
    # 関数IDからFunctionInfoへのマッピング
    func_info_map = {func.id: func for func in functions}
    
    # CSVデータを作成
    csv_data = []
    
    for item in all_items:
        item_type = item.get('type', '')
        item_id = item.get('id', '')
        file_path = item.get('file_path', '')
        
        # generation_statusを決定
        if item_type == 'proto':
            generation_status = 'skip (type=protoのため)'
            doc_generation_order = ''
        elif file_path.endswith('.h'):
            generation_status = 'skip (ヘッダファイルのため)'
            doc_generation_order = ''
        elif item_type == 'func' and file_path.endswith('.c'):
            # 実際の生成状況をGenerationPlanから取得
            if generation_plan and item_id in generation_plan.tasks:
                task = generation_plan.tasks[item_id]
                generation_status = task.status.value
            else:
                # GenerationPlanが無い場合はpendingをデフォルトとする
                generation_status = 'pending'
            doc_generation_order = func_order_map.get(item_id, '')
        else:
            generation_status = 'skip (対象外)'
            doc_generation_order = ''
        
        csv_row = {
            'doc_generation_order': doc_generation_order,
            'file_path': file_path,
            'func_id': item_id,
            'func_type': item_type,
            'func_name': item.get('name', ''),
            'generation_status': generation_status
        }
        csv_data.append(csv_row)
    
    # CSVファイルに書き込み
    try:
        with open(output_file, 'w', encoding='utf-8', newline='') as f:
            fieldnames = ['doc_generation_order', 'file_path', 'func_id', 'func_type', 'func_name', 'generation_status']
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(csv_data)
        print(f"CSVサマリーを保存しました: {output_file}")
    except Exception as e:
        print(f"エラー: CSVサマリーの保存に失敗: {e}")
        raise


def save_error_report(error_message: str, output_dir: str) -> None:
    """エラーレポートをmarkdown形式で保存"""
    error_file = Path(output_dir) / "error_report.md"
    
    try:
        with open(error_file, 'w', encoding='utf-8') as f:
            f.write(f"# エラーレポート\n\n")
            f.write(f"**発生時刻**: {datetime.now().isoformat()}\n\n")
            f.write(f"## エラー内容\n\n")
            f.write(f"```\n{error_message}\n```\n\n")
            f.write(f"## 解決方法\n\n")
            f.write(f"1. エラーメッセージを確認して原因を特定してください\n")
            f.write(f"2. analysis_result.jsonやtargets.txtの内容を確認してください\n")
            f.write(f"3. ファイルパスや関数名の整合性を確認してください\n")
        print(f"エラーレポートを保存しました: {error_file}")
    except Exception as e:
        print(f"エラーレポートの保存に失敗: {e}")
