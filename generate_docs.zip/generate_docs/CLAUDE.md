# C言語関数ドキュメント自動生成システム

## プロジェクト概要

このシステムは、C言語プロジェクトの関数に対して、依存関係を考慮した高品質なXMLドキュメントを自動生成するツールです。

### 主要機能

- **関数自動抽出**: 指定されたファイル/ディレクトリから関数情報を自動抽出
- **依存関係解析**: 関数間の呼び出し関係を解析し、適切な生成順序を決定
- **プロト型解決**: プロトタイプ宣言を対応する実装に自動マッピング
- **タイムスタンプ管理**: 実行ごとに独立したタイムスタンプ付きディレクトリで結果管理
- **CSV進捗追跡**: 処理状況をCSV形式で管理・追跡
- **Resume機能**: 途中停止から未完了関数のみを自動再実行
- **エラーハンドリング**: 詳細なエラーレポートをMarkdown形式で出力

### 出力構造

```
output_YYYYMMDD_HHMM/
├── targets.txt                      # 入力ファイルのコピー
├── doc_generation_summary.csv       # 処理進捗状況の一覧
├── generated_docs/                   # 生成されたドキュメント（階層構造維持）
│   └── [元のファイルパス]/
│       └── [関数名]/
│           ├── sys_prompt.md         # システムプロンプト
│           ├── user_prompt.md        # ユーザープロンプト
│           └── generated_doc.xml     # 生成されたXMLドキュメント
└── error_report.md                   # エラー発生時のレポート（エラー時のみ）
```

## ファイル構成

### メインスクリプト

#### `main.py`
- **役割**: システムのメインエントリーポイント
- **機能**: 
  - コマンドライン引数処理（argparse）
  - 新規作成・Resume両モード対応
  - タイムスタンプ付き出力ディレクトリ作成
  - targets.txtの読み込みとコピー
  - Resume用CSV解析・未完了関数抽出
  - 各処理ステップの実行制御
  - 統計情報の表示
- **実行**: 
  - 新規作成: `python3 main.py targets.txt`
  - Resume: `python3 main.py --resume output_yyyymmdd_hhmm`

#### `generate_docs.py`
- **役割**: システムの中核機能を提供
- **主要クラス・関数**:
  - `FunctionInfo`: 関数情報管理データクラス
  - `DependencyGraph`: 依存関係グラフ管理
  - `GenerationPlan`: ドキュメント生成計画管理
  - `load_analysis_result()`: analysis_result.json読み込み
  - `extract_function_info()`: 関数情報抽出（*.cファイルのfunc型のみ）
  - `build_dependency_graph()`: 依存関係グラフ構築
  - `resolve_proto_to_func()`: プロト型から実装への解決
  - `generate_prompts()`: LLM用プロンプト生成
  - `generate_csv_summary()`: CSV進捗レポート生成
  - `save_error_report()`: エラーレポート出力

#### `llm.py`
- **役割**: LLM（大規模言語モデル）との連携
- **現在の状態**: モック実装（開発・テスト用）
- **実装予定**: Ollamaやその他のLLMとの実際の連携
- **関数**: `chat_completions(sys_prompt, user_prompt)` - LLM呼び出し

### 設定・データファイル

#### `analysis_result.json`
- **役割**: 関数解析結果データの保存
- **内容**: 各関数のID、名前、ファイルパス、シグネチャ、呼び出し関係等
- **形式**: JSON配列形式で関数情報を格納

#### `targets.txt`
- **役割**: 処理対象ファイル・ディレクトリの指定
- **形式**: 1行につき1つのパス（ファイルまたはディレクトリ）
- **コメント**: `#`で始まる行はコメントとして無視

#### `prompts/`
- **sys_prompt.md**: LLM用システムプロンプトテンプレート
- **user_prompt.md**: LLM用ユーザープロンプトテンプレート（プレースホルダ含む）

## 使用方法

### 基本的な実行手順

#### 新規作成モード

1. **前準備**
   ```bash
   # analysis_result.jsonが存在することを確認
   ls analysis_result.json
   
   # targets.txtに対象パスを記載
   echo "path/to/your/c/files" > targets.txt
   ```

2. **実行**
   ```bash
   python3 main.py targets.txt
   ```

3. **結果確認**
   ```bash
   # 最新の出力ディレクトリを確認
   ls -la output_*
   
   # CSV進捗状況を確認
   cat output_YYYYMMDD_HHMM/doc_generation_summary.csv
   ```

#### Resume モード（途中から再実行）

生成AIのレートリミットやバグで途中停止した場合の復旧方法：

1. **Resume実行**
   ```bash
   # 既存の出力ディレクトリから再開
   python3 main.py --resume output_20240801_1430
   ```

2. **自動処理される内容**
   - 既存CSVから未完了関数（pending/failed）を自動検出
   - 依存関係順序を保持した再実行
   - 完了済み関数（completed）はスキップ
   - CSVステータスを実際の進捗に合わせて更新

3. **Resume対象判定**
   - ✅ **再実行対象**: `pending`、`failed` ステータスの関数
   - ❌ **スキップ対象**: `completed`、`skip` ステータスの関数

#### Resume機能の使用例

```bash
# 例1: 新規実行（100個の関数を処理予定）
$ python3 main.py targets.txt
# → output_20240801_1430/ に50個完了後、何らかの理由で中断

# 例2: Resume実行（残り50個を自動処理）
$ python3 main.py --resume output_20240801_1430
=== Resume モード ===
Resume directory: output_20240801_1430
✅ Resume directory validation passed
✅ Loaded CSV data: 150 entries
✅ Found resume targets: 50 functions
# → 残り50個が依存関係順で自動実行される

# 例3: 完了後の確認
$ cat output_20240801_1430/doc_generation_summary.csv | grep -E "(pending|failed)" | wc -l
0  # すべて完了
```

### CSV進捗管理

生成される`doc_generation_summary.csv`には以下の情報が含まれます：

| フィールド | 説明 |
|-----------|------|
| `doc_generation_order` | ドキュメント生成順序（依存関係に基づく） |
| `file_path` | ソースファイルパス |
| `func_id` | 関数の一意識別子 |
| `func_type` | 関数タイプ（func/proto） |
| `func_name` | 関数名 |
| `generation_status` | 生成状況（pending/in_progress/completed/failed/skip等） |

### 生成対象の絞り込み

システムは以下の条件でドキュメント生成対象を自動選別します：

- ✅ **生成対象**: `*.c`ファイルの`func`型関数
- ❌ **除外対象**: 
  - `proto`型（プロトタイプ宣言）
  - `*.h`ファイル（ヘッダファイル）
  - 外部関数（`ext_`プレフィックス）

## システム構成

### 処理フロー

```
1. ファイル探索
   ↓
2. 関数抽出（*.cのfunc型のみ）
   ↓
3. 依存関係解析（proto型解決含む）
   ↓  
4. 生成計画作成（トポロジカルソート）
   ↓
5. プロンプト生成
   ↓
6. LLM呼び出し・ドキュメント生成
   ↓
7. 結果出力・CSV更新
```

### 依存関係解析の仕組み

1. **呼び出し関係の抽出**: `analysis_result.json`の`calls`フィールドから関数間の呼び出し関係を取得
2. **プロト型解決**: `proto_*`IDを対応する`func_*`IDに解決
   - `implemented_at`フィールド優先
   - 同名・同ファイルでの`func`型検索をフォールバック
3. **依存グラフ構築**: 双方向の依存関係グラフを構築
4. **循環依存検出**: 深度優先探索で循環依存を検出・報告
5. **トポロジカルソート**: 依存関係に基づいた適切な生成順序を決定

### エラーハンドリング

エラー発生時は以下の対応を自動実行：

1. **詳細なエラーメッセージ出力**: コンソールに即座に表示
2. **error_report.md生成**: 出力ディレクトリにMarkdown形式でエラーレポート保存
3. **処理の安全停止**: データ破損を防ぐための適切な終了処理

## 開発・カスタマイズ

### LLM実装の置き換え

現在の`llm.py`はモック実装です。実際のLLMを使用する場合：

```python
# llm.py の chat_completions 関数を実装
def chat_completions(sys_prompt, user_prompt):
    # Ollama等の実際のLLM呼び出し処理
    # 例: ollama.chat(model="qwen3:4b", messages=[...])
    pass
```

### プロンプトのカスタマイズ

`prompts/`ディレクトリ内のファイルを編集：

- **sys_prompt.md**: システムレベルの指示（出力形式、制約等）
- **user_prompt.md**: 関数固有の情報（以下のプレースホルダを使用）
  - `{c_source}`: 関数のソースコード
  - `{external_function_info}`: 依存関数の情報

### 新機能の追加

主要な機能追加ポイント：

1. **generate_docs.py**: 新しい解析機能の追加
2. **main.py**: 処理フローの変更
3. **CSV出力**: 新しい統計情報の追加

## トラブルシューティング

### よくある問題

1. **analysis_result.jsonが見つからない**
   - ファイルの存在確認
   - JSON形式の妥当性確認

2. **targets.txtのパスが無効**
   - 絶対パス・相対パスの確認
   - ファイル・ディレクトリの存在確認

3. **生成されたドキュメントが空**
   - `llm.py`の実装状況確認
   - プロンプトファイルの存在確認

4. **Resume機能のエラー**
   - Resume対象ディレクトリの存在確認
   - `doc_generation_summary.csv`の存在・形式確認
   - `generated_docs/`ディレクトリの存在確認

### ログ・デバッグ情報

システムは詳細な実行ログを出力します：

- 各処理ステップの進捗状況
- 関数抽出結果の統計
- 依存関係解析結果
- 生成計画の詳細
- エラー発生箇所の特定

## 技術仕様

- **言語**: Python 3.x
- **主要ライブラリ**: 
  - `pathlib`: パス操作
  - `json`: データ形式
  - `csv`: 進捗管理
  - `datetime`: タイムスタンプ
  - `argparse`: コマンドライン引数処理
- **入力形式**: JSON（解析結果）、テキスト（対象指定）
- **出力形式**: XML（ドキュメント）、CSV（進捗）、Markdown（エラー）
- **外部依存**: LLM（Ollama等、実装時に追加）