import sys
import shutil
import argparse
import csv
from pathlib import Path
from datetime import datetime
from generate_docs import (
    load_analysis_result, extract_function_info, extract_all_items_info, extract_source_code, 
    build_dependency_graph, detect_circular_dependencies, get_dependency_order, 
    create_generation_plan, GenerationStatus, generate_prompts, save_prompt_files, 
    process_generation_tasks, generate_csv_summary, save_error_report, create_output_dir_path
)


def load_targets(targets_file):
    """targets.txtからパス一覧を読み込む"""
    targets = []
    try:
        with open(targets_file, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):  # 空行とコメント行をスキップ
                    targets.append(line)
        return targets
    except FileNotFoundError:
        print(f"エラー: {targets_file} が見つかりません")
        sys.exit(1)
    except Exception as e:
        print(f"エラー: {targets_file} の読み込みに失敗: {e}")
        sys.exit(1)


def find_c_files(path):
    """指定されたパスからCファイルを探索"""
    c_files = []
    path = Path(path)
    
    if not path.exists():
        print(f"警告: パス '{path}' が存在しません")
        return c_files
    
    if path.is_file():
        # ファイルの場合、拡張子をチェック
        if path.suffix in ['.c', '.h']:
            c_files.append(str(path))
    elif path.is_dir():
        # ディレクトリの場合、再帰的に探索
        for file_path in path.rglob('*'):
            if file_path.is_file() and file_path.suffix in ['.c', '.h']:
                c_files.append(str(file_path))
    
    return c_files


def validate_resume_directory(resume_dir):
    """resume対象ディレクトリの検証"""
    resume_path = Path(resume_dir)
    
    # ディレクトリの存在確認
    if not resume_path.exists():
        raise FileNotFoundError(f"Resume directory not found: {resume_dir}")
    
    if not resume_path.is_dir():
        raise NotADirectoryError(f"Specified path is not a directory: {resume_dir}")
    
    # 必要なファイルの存在確認
    csv_path = resume_path / "doc_generation_summary.csv"
    if not csv_path.exists():
        raise FileNotFoundError(f"CSV file not found: {csv_path}")
    
    # generated_docsディレクトリの存在確認
    generated_docs_path = resume_path / "generated_docs"
    if not generated_docs_path.exists():
        raise FileNotFoundError(f"Generated docs directory not found: {generated_docs_path}")
    
    return csv_path, generated_docs_path


def load_resume_data(csv_path):
    """既存CSVを読み込み、resume対象の関数情報を取得"""
    try:
        with open(csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            csv_data = list(reader)
        
        if not csv_data:
            raise ValueError(f"CSV file is empty: {csv_path}")
        
        return csv_data
        
    except csv.Error as e:
        raise ValueError(f"Invalid CSV format: {csv_path} - {e}")
    except Exception as e:
        raise Exception(f"Failed to load CSV: {csv_path} - {e}")


def extract_resume_targets(csv_data):
    """pending/failed状態の関数を抽出してresume対象を決定"""
    resume_targets = []
    
    for row in csv_data:
        func_type = row.get('func_type', '')
        generation_status = row.get('generation_status', '')
        
        # func型かつpending/failedのもののみが対象
        if func_type == 'func' and generation_status in ['pending', 'failed']:
            resume_targets.append(row)
    
    return resume_targets


def main():
    # コマンドライン引数処理
    parser = argparse.ArgumentParser(description='C言語関数ドキュメント自動生成システム')
    
    # 新規作成モードまたはresumeモードの選択
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('targets_file', nargs='?', help='対象ファイル一覧 (targets.txt)')
    group.add_argument('--resume', metavar='OUTPUT_DIR', help='Resume from existing output directory')
    
    args = parser.parse_args()
    
    # モード判定
    is_resume_mode = args.resume is not None
    
    if is_resume_mode:
        # Resume モード
        resume_dir = args.resume
        print(f"=== Resume モード ===")
        print(f"Resume directory: {resume_dir}")
        
        try:
            # Resume ディレクトリの検証
            csv_path, generated_docs_dir = validate_resume_directory(resume_dir)
            print(f"✅ Resume directory validation passed")
            
            # 既存CSVデータを読み込み
            csv_data = load_resume_data(csv_path)
            print(f"✅ Loaded CSV data: {len(csv_data)} entries")
            
            # Resume対象の関数を抽出
            resume_targets = extract_resume_targets(csv_data)
            print(f"✅ Found resume targets: {len(resume_targets)} functions")
            
            if not resume_targets:
                print("✅ All functions are already completed or skipped. Nothing to resume.")
                return
            
            # Resume対象の関数IDを取得
            resume_func_ids = [target['func_id'] for target in resume_targets]
            print(f"Resume targets: {', '.join(resume_func_ids)}")
            
            # 出力ディレクトリは既存のものを使用
            output_base_dir = resume_dir
            
        except Exception as e:
            print(f"❌ Resume mode error: {e}")
            sys.exit(1)
    else:
        # 新規作成モード
        if not args.targets_file:
            print("使用法: python3 main.py targets.txt または python3 main.py --resume output_yyyymmdd_hhmm")
            sys.exit(1)
        
        targets_file = args.targets_file
        print(f"=== 新規作成モード ===")
        print(f"Targets file: {targets_file}")
        
        # タイムスタンプ付き出力ディレクトリを作成
        timestamp = datetime.now().strftime("%Y%m%d_%H%M")
        output_base_dir = f"output_{timestamp}"
        generated_docs_dir = Path(output_base_dir) / "generated_docs"
    
    # 新規作成モードのみの処理
    if not is_resume_mode:
        try:
            # 出力ディレクトリを作成
            Path(output_base_dir).mkdir(exist_ok=True)
            generated_docs_dir.mkdir(parents=True, exist_ok=True)
            
            # targets.txtをコピー
            targets_copy_path = Path(output_base_dir) / "targets.txt"
            shutil.copy2(targets_file, targets_copy_path)
            print(f"targets.txtをコピーしました: {targets_copy_path}")
            
        except Exception as e:
            error_msg = f"出力ディレクトリの作成またはtargets.txtのコピーに失敗: {e}"
            print(f"エラー: {error_msg}")
            save_error_report(error_msg, output_base_dir)
            sys.exit(1)
    
    print(f"出力ディレクトリ: {output_base_dir}")
    
    # モードに応じてファイル探索方法を決定
    if is_resume_mode:
        # Resume モード: CSVから対象ファイルを抽出
        print(f"=== Resume対象ファイル抽出 ===")
        all_c_files = list(set([row['file_path'] for row in csv_data]))
        print(f"対象ファイル数: {len(all_c_files)}")
        for file_path in all_c_files:
            print(f"  {file_path}")
    else:
        # 新規作成モード: targets.txtからパス一覧を読み込み
        print(f"targets.txt を読み込み中: {targets_file}")
        targets = load_targets(targets_file)
        print(f"対象パス数: {len(targets)}")
        
        # 各パスからCファイルを探索
        all_c_files = []
        for target in targets:
            print(f"\n処理中: {target}")
            c_files = find_c_files(target)
            print(f"  見つかったファイル数: {len(c_files)}")
            all_c_files.extend(c_files)
    
    # ステップ2: 関数抽出処理
    print(f"\n=== ステップ2: 関数抽出 ===")
    
    # analysis_result.jsonを読み込み
    analysis_data = load_analysis_result()
    if not analysis_data:
        print("analysis_result.jsonの読み込みに失敗しました。処理を終了します。")
        return
    
    if is_resume_mode:
        # Resume モード: resume対象の関数のみを抽出
        print("Resume モード: 未完了関数のみを抽出")
        
        # resume対象の関数IDを取得
        resume_func_ids = [target['func_id'] for target in resume_targets]
        
        # analysis_dataから該当する関数情報を再構築
        functions = []
        for item in analysis_data:
            if item.get('type') == 'func' and item.get('id') in resume_func_ids:
                from generate_docs import FunctionInfo
                func_info = FunctionInfo(
                    id=item.get('id', ''),
                    name=item.get('name', ''),
                    file_path=item.get('file_path', ''),
                    line_start=item.get('line_start', 0),
                    line_end=item.get('line_end', 0),
                    signature=item.get('signature', ''),
                    calls=item.get('calls', [])
                )
                functions.append(func_info)
        
        print(f"Resume対象関数数: {len(functions)}")
    else:
        # 新規作成モード: 対象ファイルから関数情報を抽出
        functions = extract_function_info(analysis_data, all_c_files)
        print(f"抽出された関数数: {len(functions)}")
    
    # 各関数のソースコードを抽出
    print("\n関数一覧:")
    for func in functions:
        print(f"  [{func.id}] {func.name} in {func.file_path}:{func.line_start}-{func.line_end}")
        print(f"    シグネチャ: {func.signature}")
        
        # ソースコードを抽出
        source_code = extract_source_code(func.file_path, func.line_start, func.line_end)
        func.source_code = source_code
        
        # ソースコードの最初の数行を表示（長すぎる場合は省略）
        lines = source_code.split('\n')
        preview_lines = lines[:3]  # 最初の3行のみ
        for line in preview_lines:
            if line.strip():  # 空行でない場合のみ表示
                print(f"    {line}")
        if len(lines) > 3:
            print(f"    ... (他 {len(lines) - 3} 行)")
        print()
    
    # 結果サマリー
    print(f"\n=== 結果サマリー ===")
    print(f"総Cファイル数: {len(all_c_files)}")
    print(f"総関数数: {len(functions)}")
    
    # ファイル別関数数
    file_func_count = {}
    for func in functions:
        file_func_count[func.file_path] = file_func_count.get(func.file_path, 0) + 1
    
    print("\nファイル別関数数:")
    for file_path, count in sorted(file_func_count.items()):
        print(f"  {file_path}: {count}個")
    
    # ステップ3: 依存関係解析処理
    print(f"\n=== ステップ3: 依存関係解析 ===")
    
    # 依存関係グラフを構築
    dependency_graph = build_dependency_graph(functions, analysis_data)
    print(f"依存関係グラフを構築しました")
    
    # 循環依存を検出
    cycles = detect_circular_dependencies(dependency_graph)
    if cycles:
        print(f"\n⚠️  循環依存が検出されました: {len(cycles)}個")
        for i, cycle in enumerate(cycles, 1):
            print(f"  循環{i}: ", end="")
            cycle_names = []
            for func_id in cycle:
                func_info = dependency_graph.get_function_info(func_id)
                if func_info:
                    cycle_names.append(func_info.name)
                else:
                    cycle_names.append(func_id)
            print(" -> ".join(cycle_names))
    else:
        print("✅ 循環依存は検出されませんでした")
    
    # 依存順序を決定
    dependency_order = get_dependency_order(dependency_graph)
    print(f"\n依存順序（ドキュメント生成順序）:")
    
    # 依存関係の統計情報
    total_dependencies = 0
    isolated_functions = 0  # 依存関係がない関数
    
    for i, func_id in enumerate(dependency_order, 1):
        func_info = dependency_graph.get_function_info(func_id)
        if not func_info:
            continue
            
        dependencies = dependency_graph.get_dependencies(func_id)
        dependents = dependency_graph.get_dependents(func_id)
        
        total_dependencies += len(dependencies)
        if len(dependencies) == 0 and len(dependents) == 0:
            isolated_functions += 1
        
        print(f"  {i:2d}. {func_info.name} [{func_id}]")
        print(f"      ファイル: {func_info.file_path}")
        
        if dependencies:
            dep_names = []
            for dep_id in dependencies:
                dep_info = dependency_graph.get_function_info(dep_id)
                if dep_info:
                    dep_names.append(dep_info.name)
                else:
                    dep_names.append(dep_id)
            print(f"      依存: {', '.join(dep_names)}")
        
        if dependents:
            dependent_names = []
            for dep_id in dependents:
                dep_info = dependency_graph.get_function_info(dep_id)
                if dep_info:
                    dependent_names.append(dep_info.name)
                else:
                    dependent_names.append(dep_id)
            print(f"      依存元: {', '.join(dependent_names)}")
        print()
    
    # 依存関係の統計
    print(f"=== 依存関係統計 ===")
    print(f"総依存関係数: {total_dependencies}")
    print(f"独立関数数: {isolated_functions}")
    print(f"依存関係を持つ関数数: {len(functions) - isolated_functions}")
    if len(functions) > 0:
        print(f"依存関係密度: {total_dependencies / len(functions):.2f} (平均依存数/関数)")
    
    # ステップ4: 生成計画管理処理
    print(f"\n=== ステップ4: 生成計画管理 ===")
    
    # 生成計画を作成（新しい出力パスで）
    # 関数の出力パスを一時的に更新
    for func in functions:
        func.output_dir = create_output_dir_path(func, str(generated_docs_dir))
    
    generation_plan = create_generation_plan(functions, dependency_order)
    
    # 統計情報を表示
    stats = generation_plan.get_statistics()
    print(f"\n生成計画統計:")
    print(f"  PENDING:     {stats['pending']:2d} 個 (生成待ち)")
    print(f"  IN_PROGRESS: {stats['in_progress']:2d} 個 (生成中)")
    print(f"  COMPLETED:   {stats['completed']:2d} 個 (完了済み)")
    print(f"  FAILED:      {stats['failed']:2d} 個 (失敗)")
    print(f"  SKIPPED:     {stats['skipped']:2d} 個 (スキップ)")
    print(f"  合計:        {len(generation_plan.tasks):2d} 個")
    
    # 実行予定のタスク一覧表示
    pending_tasks = generation_plan.get_tasks_by_status(GenerationStatus.PENDING)
    if pending_tasks:
        print(f"\n実行予定のタスク ({len(pending_tasks)}個):")
        for i, task in enumerate(pending_tasks, 1):
            print(f"  {i:2d}. {task.function_name} [{task.function_id}]")
            print(f"      ファイル: {task.file_path}")
            print(f"      出力先: {task.output_dir}")
            print()
    
    # 完了済みタスク一覧表示
    completed_tasks = generation_plan.get_tasks_by_status(GenerationStatus.COMPLETED)
    if completed_tasks:
        print(f"完了済みタスク ({len(completed_tasks)}個):")
        for task in completed_tasks:
            print(f"  ✅ {task.function_name} - {task.updated_at}")
    
    # 失敗タスク一覧表示
    failed_tasks = generation_plan.get_tasks_by_status(GenerationStatus.FAILED)
    if failed_tasks:
        print(f"\n失敗タスク ({len(failed_tasks)}個):")
        for task in failed_tasks:
            print(f"  ❌ {task.function_name} - {task.error_message}")
    
    # スキップタスク一覧表示（簡潔に）
    skipped_tasks = generation_plan.get_tasks_by_status(GenerationStatus.SKIPPED)
    if skipped_tasks:
        print(f"\nスキップタスク ({len(skipped_tasks)}個): 既存ドキュメントが存在")
        skipped_names = [task.function_name for task in skipped_tasks]
        print(f"  {', '.join(skipped_names)}")
    
    print(f"\n生成計画をメモリ上に作成しました（CSV形式で管理）")
    print(f"計画作成時刻: {generation_plan.creation_time}")
    
    # 次のステップへの案内
    if pending_tasks:
        print(f"\n次は、ステップ5（プロンプト生成）とステップ6（ドキュメント生成）を実装して")
        print(f"実際のドキュメント生成を開始できます。")
    else:
        print(f"\n全てのドキュメントが既に生成済みまたはスキップされています。")
    
    # ステップ5: プロンプト生成機能
    print(f"\n=== ステップ5: プロンプト生成機能 ===")
    
    if not pending_tasks:
        print("プロンプト生成する関数がありません。")
        return
    
    # 全項目情報を抽出（CSV用）
    all_items = extract_all_items_info(analysis_data, all_c_files)
    print(f"CSV用全項目数: {len(all_items)}")
    
    # CSVサマリーを生成
    csv_output_path = Path(output_base_dir) / "doc_generation_summary.csv"
    try:
        generate_csv_summary(all_items, functions, dependency_order, str(csv_output_path), generation_plan)
    except Exception as e:
        error_msg = f"CSVサマリーの生成に失敗: {e}"
        print(f"エラー: {error_msg}")
        save_error_report(error_msg, output_base_dir)
        sys.exit(1)
    
    # 関数情報をIDでインデックス化
    func_by_id = {func.id: func for func in functions}
    
    # ステップ6: ドキュメント生成・出力機能
    print(f"\n=== ステップ6: ドキュメント生成・出力機能 ===")
    
    print(f"🚀 本格実行: 全{len(pending_tasks)}個の関数でドキュメント生成を実行")
    
    print(f"現在のLLM設定: llm.py (モック実装)")
    print(f"  ※ 実際のLLM実装時は、ollama等の実際のLLMが呼び出されます")
    print(f"  ※ 結果は {output_base_dir}/ ディレクトリに保存されます")
    
    # ドキュメント生成タスクを実行（新しい出力パスで）
    try:
        # 関数の出力パスを新しいベースディレクトリに更新
        for func in functions:
            func.output_dir = create_output_dir_path(func, str(generated_docs_dir))
        
        # ドキュメント生成処理を実行
        processed_count = 0
        failed_count = 0
        
        pending_tasks = generation_plan.get_tasks_by_status(GenerationStatus.PENDING)
        pending_task_by_id = {task.function_id: task for task in pending_tasks}
        
        print(f"全タスク実行: {len(pending_tasks)}個のタスクを処理（依存順序に従って実行）")
        
        # 依存順序に従ってタスクを処理
        for func_id in dependency_order:
            task = pending_task_by_id.get(func_id)
            if not task:
                continue  # このIDは処理対象外
                
            func_info = func_by_id.get(task.function_id)
            if not func_info:
                print(f"❌ 関数情報が見つかりません: {task.function_id}")
                continue
            
            # 新しい出力パスを設定
            updated_output_dir = create_output_dir_path(func_info, str(generated_docs_dir))
            
            print(f"\n[{processed_count + 1}/{len(pending_tasks)}] 処理中: {func_info.name}")
            print(f"  ファイル: {func_info.file_path}")
            print(f"  出力先: {updated_output_dir}")
            
            try:
                # プロンプト生成（依存関数の情報を含む）
                print(f"  プロンプト生成中...")
                sys_prompt, user_prompt = generate_prompts(func_info, dependency_graph, str(generated_docs_dir))
                
                # プロンプトファイルを保存
                output_dir = Path(updated_output_dir)
                output_dir.mkdir(parents=True, exist_ok=True)
                
                # sys_prompt.mdを保存
                sys_prompt_path = output_dir / "sys_prompt.md"
                with open(sys_prompt_path, 'w', encoding='utf-8') as f:
                    f.write(sys_prompt)
                
                # user_prompt.mdを保存
                user_prompt_path = output_dir / "user_prompt.md"
                with open(user_prompt_path, 'w', encoding='utf-8') as f:
                    f.write(user_prompt)
                
                print(f"  プロンプト生成完了 (依存関数: {len(dependency_graph.get_dependencies(func_info.id))}個)")
                
                # LLMを呼び出してドキュメント生成
                print(f"  LLM呼び出し開始: {func_info.name}")
                from llm import chat_completions
                result = chat_completions(sys_prompt, user_prompt)
                
                # モック結果の場合はサンプルXMLを生成
                if result.startswith("len(sys_prompt):"):
                    sample_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<function>
  <name>{func_info.name}</name>
  <purpose>この関数の目的は現在解析中です（LLMモック使用中）</purpose>
  <summary>関数 {func_info.name} の基本的な動作について。</summary>
  <arguments>
    <arg>
      <name>引数情報</name>
      <type>未解析</type>
      <description>LLMによる解析が必要です</description>
    </arg>
  </arguments>
  <return-value>
    <type>未解析</type>
    <description>LLMによる解析が必要です</description>
  </return-value>
  <remarks>現在LLMモックを使用中のため、サンプルXMLを出力しています。実際のLLM実装時に正確なドキュメントが生成されます。</remarks>
  <process-flow>
    <step>1. 関数の処理開始</step>
    <step>2. 処理内容の解析（要LLM実装）</step>
    <step>3. 関数の処理終了</step>
  </process-flow>
  <database-queries>
    <!-- データベースアクセスがある場合に記載 -->
  </database-queries>
</function>"""
                    print(f"  ⚠️  LLMモック検出: サンプルXMLを生成")
                    xml_content = sample_xml
                else:
                    # 実際のLLM結果
                    print(f"  ✅ LLM呼び出し完了")
                    xml_content = result
                
                # ドキュメントを保存
                output_dir = Path(updated_output_dir)
                output_dir.mkdir(parents=True, exist_ok=True)
                
                doc_path = output_dir / "generated_doc.xml"
                with open(doc_path, 'w', encoding='utf-8') as f:
                    f.write(xml_content)
                
                # 生成計画のステータスを更新
                generation_plan.update_task_status(task.function_id, GenerationStatus.COMPLETED)
                
                print(f"  ✅ 完了: {func_info.name}")
                processed_count += 1
                
            except Exception as e:
                error_msg = f"ドキュメント生成失敗: {func_info.name} - {e}"
                print(f"  ❌ {error_msg}")
                
                # 生成計画のステータスを更新
                generation_plan.update_task_status(task.function_id, GenerationStatus.FAILED, error_msg)
                
                save_error_report(error_msg, output_base_dir)
                failed_count += 1
                # エラー時は処理を中止
                sys.exit(1)
        
        print(f"\n=== 処理完了 ===")
        print(f"成功: {processed_count}個")
        print(f"失敗: {failed_count}個")
        print(f"合計: {processed_count + failed_count}個")
        
        # 最終的なCSVファイルを生成（ステータス更新済み）
        csv_path = Path(output_base_dir) / "doc_generation_summary.csv"
        all_items = extract_all_items_info(analysis_data, all_c_files)
        generate_csv_summary(all_items, functions, dependency_order, str(csv_path), generation_plan)
        print(f"📊 最終CSVレポート更新: {csv_path}")
        
        # 生成結果の確認
        print(f"\n=== 生成結果確認 ===")
        
        if processed_count > 0:
            print(f"✅ 成功したドキュメント生成:")
            # 生成されたファイルを確認
            for func in functions:
                updated_output_dir = create_output_dir_path(func, str(generated_docs_dir))
                generated_doc = Path(updated_output_dir) / "generated_doc.xml"
                if generated_doc.exists():
                    file_size = generated_doc.stat().st_size
                    print(f"  📄 {func.name}: {generated_doc} ({file_size:,} bytes)")
        
        if failed_count > 0:
            print(f"\n❌ 失敗したドキュメント生成: {failed_count}個")
        
        # システム完成の案内
        if processed_count > 0:
            print(f"\n🎉 ドキュメント生成システム完成！")
            print(f"")
            print(f"完成した出力構造:")
            print(f"  {output_base_dir}/")
            print(f"  ├── targets.txt (入力ファイルのコピー)")
            print(f"  ├── doc_generation_summary.csv (処理順序と進捗状況)")
            print(f"  └── generated_docs/ (階層構造でXMLドキュメント)")
            print(f"")
            print(f"実際の利用時:")
            print(f"  1. llm.py を実際のLLM実装に置き換え")
            print(f"  2. targets.txt に対象ファイル/ディレクトリを記載")
            print(f"  3. python3 main.py targets.txt で実行")
            print(f"  4. output_YYYYMMDD_HHMM/ ディレクトリに結果が保存されます")
        
    except Exception as e:
        error_msg = f"ドキュメント生成処理でエラーが発生: {e}"
        print(f"❌ {error_msg}")
        save_error_report(error_msg, output_base_dir)
        sys.exit(1)


if __name__ == "__main__":
    main()