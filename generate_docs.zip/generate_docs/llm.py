def chat_completions(sys_prompt, user_prompt):
    return f"len(sys_prompt): {len(sys_prompt)}, len(user_prompt): {len(user_prompt)}"
    # response = chat(
    #     model="qwen3:4b",
    #     # model="qwen3:8b",
    #     messages=[
    #         {"role": "system", "content": sys_prompt},
    #         {"role": "user", "content": user_prompt},
    #     ],
    # )
    # return response.message.content
