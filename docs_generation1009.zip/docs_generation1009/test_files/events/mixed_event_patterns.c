// 複数のイベント取得パターンを混在させたテスト
#include <X11/Xlib.h>
#include <stdio.h>

void handle_button(XButtonEvent *event) {
    printf("Button at (%d, %d)\n", event->x, event->y);
}

void handle_key(XKeyEvent *event) {
    printf("Key: %d\n", event->keycode);
}

void process_with_check_event(Display *display, Window window) {
    XEvent event;
    
    // XCheckTypedWindowEvent パターン
    if (XCheckTypedWindowEvent(display, window, ButtonPress, &event)) {
        handle_button(&event.xbutton);
    }
    
    // XCheckMaskEvent パターン  
    if (XCheckMaskEvent(display, KeyPressMask, &event)) {
        handle_key(&event.xkey);
    }
}

void traditional_event_loop(Display *display) {
    XEvent event;
    
    while (XPending(display)) {
        XNextEvent(display, &event);
        
        switch (event.type) {
            case ButtonPress:
                handle_button(&event.xbutton);
                break;
            case KeyPress:
                handle_key(&event.xkey);
                break;
        }
    }
}

void window_specific_events(Display *display, Window window) {
    XEvent event;
    
    // XWindowEvent パターン
    XWindowEvent(display, window, ButtonPressMask | KeyPressMask, &event);
    
    if (event.type == ButtonPress) {
        handle_button(&event.xbutton);
    } else if (event.type == KeyPress) {
        handle_key(&event.xkey);
    }
}

int main() {
    Display *display;
    Window window;
    
    display = XOpenDisplay(NULL);
    window = XCreateSimpleWindow(display, DefaultRootWindow(display),
                                0, 0, 400, 300, 1, 0, 0);
    
    // 様々なパターンを使用
    traditional_event_loop(display);
    process_with_check_event(display, window);
    window_specific_events(display, window);
    
    XCloseDisplay(display);
    return 0;
}
