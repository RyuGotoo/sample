// XSelectInputが別ファイルにあるケースのシミュレーション
#include <X11/Xlib.h>
#include <stdio.h>

// 別の場所でXSelectInputが呼ばれているとする
// （実際にはこのファイルには含まれない）

void handle_mouse_move(XMotionEvent *motion) {
    printf("Mouse at (%d, %d)\n", motion->x, motion->y);
}

void handle_click(XButtonEvent *button) {
    printf("Click at (%d, %d)\n", button->x, button->y);
}

void process_events(Display *display) {
    XEvent event;
    
    // XNextEvent以外のイベント取得方法も使用
    if (XPending(display) > 0) {
        XNextEvent(display, &event);
        
        switch (event.type) {
            case MotionNotify:
                handle_mouse_move(&event.xmotion);
                break;
                
            case ButtonPress:
                handle_click(&event.xbutton);
                break;
                
            case KeyPress:
                printf("Key pressed\n");
                break;
        }
    }
}

// 別のイベント取得パターン
void check_specific_events(Display *display, Window window) {
    XEvent event;
    
    // 特定のイベントタイプだけをチェック
    if (XCheckTypedWindowEvent(display, window, ButtonPress, &event)) {
        handle_click(&event.xbutton);
    }
    
    // マスク指定でイベントチェック
    if (XCheckMaskEvent(display, PointerMotionMask, &event)) {
        handle_mouse_move(&event.xmotion);
    }
}
