#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// グローバル変数
Display *display;
Window main_window, child_window;
GC gc;

void draw_rectangle(int x, int y, int width, int height) {
    XDrawRectangle(display, main_window, gc, x, y, width, height);
}

void draw_text(const char *text, int x, int y) {
    XDrawString(display, main_window, gc, x, y, text, strlen(text));
}

void handle_button_events(XButtonEvent *button_event) {
    switch (button_event->button) {
        case Button1:
            printf("Left button pressed at (%d, %d)\n", 
                   button_event->x, button_event->y);
            draw_rectangle(button_event->x - 10, button_event->y - 10, 20, 20);
            break;
            
        case Button2:
            printf("Middle button pressed\n");
            break;
            
        case Button3:
            printf("Right button pressed\n");
            draw_text("Right click!", button_event->x, button_event->y);
            break;
    }
}

void handle_motion_events(XMotionEvent *motion_event) {
    if (motion_event->state & Button1Mask) {
        printf("Dragging with left button at (%d, %d)\n", 
               motion_event->x, motion_event->y);
    }
}

void handle_keyboard_events(XKeyEvent *key_event) {
    char buffer[10];
    KeySym keysym;
    int count;
    
    count = XLookupString(key_event, buffer, sizeof(buffer), &keysym, NULL);
    
    if (count > 0) {
        printf("Key pressed: %c (code: %d)\n", buffer[0], key_event->keycode);
        
        // 特定のキーに対する処理
        switch (buffer[0]) {
            case 'q':
            case 'Q':
                printf("Quit key pressed\n");
                exit(0);
                break;
                
            case 'r':
            case 'R':
                printf("Refresh requested\n");
                XClearWindow(display, main_window);
                break;
        }
    }
}

void handle_window_events(XEvent *event) {
    switch (event->type) {
        case ConfigureNotify:
            printf("Window resized to %dx%d\n", 
                   event->xconfigure.width, event->xconfigure.height);
            break;
            
        case MapNotify:
            printf("Window mapped\n");
            break;
            
        case UnmapNotify:
            printf("Window unmapped\n");
            break;
            
        case DestroyNotify:
            printf("Window destroyed\n");
            exit(0);
            break;
    }
}

void setup_window() {
    int screen = DefaultScreen(display);
    
    main_window = XCreateSimpleWindow(display, 
                                     DefaultRootWindow(display),
                                     100, 100, 600, 400, 2,
                                     BlackPixel(display, screen),
                                     WhitePixel(display, screen));
    
    child_window = XCreateSimpleWindow(display, main_window,
                                      50, 50, 200, 100, 1,
                                      BlackPixel(display, screen),
                                      WhitePixel(display, screen));
    
    // メインウィンドウのイベントマスク
    XSelectInput(display, main_window, 
                ButtonPressMask | ButtonReleaseMask | 
                PointerMotionMask | KeyPressMask | KeyReleaseMask |
                ExposureMask | StructureNotifyMask);
    
    // 子ウィンドウのイベントマスク
    XSelectInput(display, child_window,
                ButtonPressMask | ExposureMask);
    
    gc = XCreateGC(display, main_window, 0, NULL);
    
    XMapWindow(display, main_window);
    XMapWindow(display, child_window);
}

int main() {
    XEvent event;
    
    display = XOpenDisplay(NULL);
    if (display == NULL) {
        fprintf(stderr, "Cannot open display\n");
        exit(1);
    }
    
    setup_window();
    
    printf("XWindow event handling demo started\n");
    printf("Press 'q' to quit, 'r' to refresh\n");
    
    // メインイベントループ
    while (1) {
        XNextEvent(display, &event);
        
        printf("Event received: type=%d, window=0x%lx\n", 
               event.type, event.xany.window);
        
        switch (event.type) {
            case ButtonPress:
                handle_button_events(&event.xbutton);
                break;
                
            case ButtonRelease:
                printf("Button released\n");
                break;
                
            case MotionNotify:
                handle_motion_events(&event.xmotion);
                break;
                
            case KeyPress:
                handle_keyboard_events(&event.xkey);
                break;
                
            case KeyRelease:
                printf("Key released\n");
                break;
                
            case Expose:
                printf("Expose event for window 0x%lx\n", event.xexpose.window);
                if (event.xexpose.window == main_window) {
                    draw_text("Main Window", 10, 30);
                } else if (event.xexpose.window == child_window) {
                    draw_text("Child", 10, 20);
                }
                break;
                
            case ConfigureNotify:
            case MapNotify:
            case UnmapNotify:
            case DestroyNotify:
                handle_window_events(&event);
                break;
                
            case ClientMessage:
                printf("Client message received\n");
                break;
                
            default:
                printf("Unhandled event type: %d\n", event.type);
                break;
        }
    }
    
    XFreeGC(display, gc);
    XCloseDisplay(display);
    return 0;
}