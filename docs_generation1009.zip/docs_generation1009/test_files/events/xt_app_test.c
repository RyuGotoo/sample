// Xt (X Toolkit Intrinsics) アプリケーションのテスト
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <stdio.h>

void button_callback(Widget w, XtPointer client_data, XtPointer call_data) {
    printf("Button pressed!\n");
}

void key_handler(Widget w, XEvent *event, String *params, Cardinal *num_params) {
    if (event->type == KeyPress) {
        printf("Key pressed: %d\n", event->xkey.keycode);
    }
}

int main(int argc, char **argv) {
    XtAppContext app_context;
    Widget toplevel, button;
    XEvent event;
    
    toplevel = XtVaAppInitialize(&app_context, "XtTest", NULL, 0,
                                &argc, argv, NULL, NULL);
    
    button = XtCreateManagedWidget("button", commandWidgetClass, toplevel, NULL, 0);
    XtAddCallback(button, XtNcallback, button_callback, NULL);
    
    XtRealizeWidget(toplevel);
    
    // Xt イベントループのパターン
    while (1) {
        XtAppNextEvent(app_context, &event);
        XtDispatchEvent(&event);
    }
    
    return 0;
}
