#include <X11/Xlib.h>
#include <stdio.h>
#include <stdlib.h>

void handle_button_press(XEvent *event) {
    printf("Button pressed at (%d, %d)\n", 
           event->xbutton.x, event->xbutton.y);
}

void handle_key_press(XEvent *event) {
    printf("Key pressed: %d\n", event->xkey.keycode);
}

void handle_expose() {
    printf("Window needs to be redrawn\n");
}

int main() {
    Display *display;
    Window window;
    XEvent event;
    
    display = XOpenDisplay(NULL);
    if (display == NULL) {
        fprintf(stderr, "Cannot open display\n");
        exit(1);
    }
    
    window = XCreateSimpleWindow(display, DefaultRootWindow(display),
                                10, 10, 400, 300, 1, 0, 0);
    
    // イベントマスクを設定
    XSelectInput(display, window, ButtonPressMask | KeyPressMask | ExposureMask);
    
    XMapWindow(display, window);
    
    // イベントループ
    while (1) {
        XNextEvent(display, &event);
        
        switch (event.type) {
            case ButtonPress:
                handle_button_press(&event);
                break;
                
            case KeyPress:
                handle_key_press(&event);
                break;
                
            case Expose:
                handle_expose();
                break;
                
            default:
                printf("Unknown event: %d\n", event.type);
                break;
        }
    }
    
    XCloseDisplay(display);
    return 0;
}