// 拡張コールバックパターンのテスト
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>
#include <Xm/Protocols.h>
#include <stdio.h>

// XtAddEventHandler用のイベントハンドラ
void button_event_handler(Widget w, XtPointer client_data, XEvent *event, Boolean *continue_to_dispatch) {
    if (event->type == ButtonPress) {
        printf("Button pressed in widget!\n");
    }
}

// Motifプロトコルコールバック
void protocol_callback(Widget w, XtPointer client_data, XtPointer call_data) {
    printf("Protocol callback triggered!\n");
}

// XSelectInput用のハンドラ（直接的ではないが関連）
void handle_x_events(Display *dpy, Window win) {
    XEvent event;
    while (XPending(dpy)) {
        XNextEvent(dpy, &event);
        switch (event.type) {
            case ButtonPress:
                printf("Direct X11 button press\n");
                break;
            case KeyPress:
                printf("Direct X11 key press\n");
                break;
        }
    }
}

int main(int argc, char **argv) {
    XtAppContext app_context;
    Widget toplevel, button;
    Display *display;
    Window window;
    Atom wm_delete_window;

    toplevel = XtVaAppInitialize(&app_context, "ExtendedTest", NULL, 0,
                                &argc, argv, NULL, NULL);

    display = XtDisplay(toplevel);
    window = XtWindow(toplevel);

    button = XtCreateManagedWidget("button", commandWidgetClass, toplevel, NULL, 0);

    // XtAddEventHandler - イベントマスクでイベントハンドラを登録
    XtAddEventHandler(button, ButtonPressMask | KeyPressMask, False,
                      button_event_handler, NULL);

    // XtAddRawEventHandler - 生イベントハンドラ
    XtAddRawEventHandler(toplevel, StructureNotifyMask, False,
                         button_event_handler, NULL);

    // Motifプロトコルコールバック
    wm_delete_window = XmInternAtom(display, "WM_DELETE_WINDOW", False);
    XmAddProtocolCallback(toplevel, XM_WM_PROTOCOL_ATOM(display),
                          wm_delete_window, protocol_callback, NULL);

    // X11のXSelectInput - イベントマスク設定
    XSelectInput(display, window, ButtonPressMask | KeyPressMask | ExposureMask);

    XtRealizeWidget(toplevel);

    // Xtメインループ
    XtAppMainLoop(app_context);

    return 0;
}