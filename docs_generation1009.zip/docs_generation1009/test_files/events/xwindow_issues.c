// このファイルは意図的に問題のあるXWindowコードのサンプルです
// イベント解析の問題検出機能をテストするために使用します

#include <stdio.h>
// 注意: X11/Xlib.h をincludeしていない！

// 未定義の型を使用（コンパイルエラーになるが、解析テスト用）
extern Display *display;
extern Window window;

void unused_handler() {
    printf("This handler is never called\n");
}

void handle_button() {
    printf("Button event handled\n");
}

void problematic_switch(XEvent *event) {
    switch (event->type) {
        case ButtonPress:
            printf("Button pressed\n");
            handle_button();
            // 注意: breakがない（フォールスルー）
            
        case KeyPress:
            printf("Key pressed (or fell through from button)\n");
            break;
            
        case MotionNotify:
            printf("Mouse moved\n");
            // 注意: このイベントは登録されていない
            break;
            
        case Expose:
            printf("Expose event\n");
            break;
            
        // defaultケースがない
    }
}

int main() {
    XEvent event;
    
    // 注意: ButtonPressMaskとKeyPressMaskのみ登録
    // しかし、MotionNotifyも処理しようとしている
    XSelectInput(display, window, ButtonPressMask | KeyPressMask);
    
    // 注意: ExposureMaskを登録していないが、Exposeイベントを処理している
    
    while (1) {
        XNextEvent(display, &event);
        
        problematic_switch(&event);
        
        // unused_handler() は呼ばれることがない
    }
    
    return 0;
}