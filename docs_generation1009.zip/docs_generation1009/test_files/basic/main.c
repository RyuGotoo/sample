#include <stdio.h>
#include "math.h"

int main(void) {
    int result = add(10, 5);
    printf("Result: %d\n", result);
    return 0;
}