#ifndef MATH_H
#define MATH_H

int add(int a, int b);

#endif // MATH_H