#include <stdio.h>
// 意図的にmath.hをincludeしていません

int main(void) {
    int result = add(10, 5);  // エラー: addが見えない
    printf("Result: %d\n", result);
    return 0;
}