#define API_DECL __attribute__((visibility("default")))

/* マクロ付き宣言：implemented_at を補完できることを確認する */
API_DECL int macro_proto(int x);

/* 実装のないプロトタイプ：補完されないことを確認する */
int orphan_proto(int y);

int macro_proto(int x) {
    return x * 3;
}
