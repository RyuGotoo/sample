#include <stdio.h>
#include "math.h"

int process_data(int x) {
    if (x > 10) {
        int result = add(x, 5);  // User-defined function call
        printf("Large: %d\n", result);
        return result;
    } else {
        printf("Small: %d\n", x);
        return x;
    }
}

int complex_flow(int a, int b) {
    if (a > 0) {
        for (int i = 0; i < a; i++) {
            int sum = add(i, b);
            printf("Sum %d: %d\n", i, sum);
            if (sum > 20) {
                printf("Breaking at %d\n", sum);
                break;
            }
        }
    }
    return a + b;
}