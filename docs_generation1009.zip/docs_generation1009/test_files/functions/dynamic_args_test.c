// 動的引数のテスト（元の質問のケース）
#include <X11/Xlib.h>
#include <stdio.h>

Display* getDisplay() {
    static Display *display = NULL;
    if (!display) {
        display = XOpenDisplay(NULL);
    }
    return display;
}

Window getWindow() {
    static Window window = 0;
    if (!window) {
        window = XCreateSimpleWindow(getDisplay(), DefaultRootWindow(getDisplay()),
                                   10, 10, 400, 300, 1, 0, 0);
    }
    return window;
}

void handle_events() {
    XEvent event;
    
    // 動的な引数を使用したXNextEvent
    XNextEvent(getDisplay(), &event);
    
    switch (event.type) {
        case ButtonPress:
            printf("Dynamic args: Button pressed\n");
            break;
        case KeyPress:
            printf("Dynamic args: Key pressed\n");
            break;
        case Expose:
            printf("Dynamic args: Expose event\n");
            break;
    }
}

int main() {
    // イベントマスクも動的に設定
    long events = ButtonPressMask | KeyPressMask | ExposureMask;
    XSelectInput(getDisplay(), getWindow(), events);
    
    XMapWindow(getDisplay(), getWindow());
    
    while (1) {
        handle_events();
    }
    
    return 0;
}
