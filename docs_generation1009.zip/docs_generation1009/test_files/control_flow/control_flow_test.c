#include <stdio.h>

int test_if_else(int x) {
    if (x > 0) {
        printf("Positive\n");
        return 1;
    } else if (x < 0) {
        printf("Negative\n");
        return -1;
    } else {
        printf("Zero\n");
        return 0;
    }
}

int test_while_loop(int n) {
    int i = 0;
    while (i < n) {
        printf("Loop: %d\n", i);
        i++;
    }
    return i;
}

int test_for_loop(int max) {
    int sum = 0;
    for (int i = 0; i < max; i++) {
        sum += i;
        if (sum > 100) {
            break;
        }
    }
    return sum;
}

int test_switch(int value) {
    switch (value) {
        case 1:
            printf("One\n");
            break;
        case 2:
            printf("Two\n");
            break;
        case 3:
            printf("Three\n");
            break;
        default:
            printf("Other\n");
            break;
    }
    return value;
}

int test_nested_control(int a, int b) {
    if (a > 0) {
        if (b > 0) {
            for (int i = 0; i < a; i++) {
                printf("Nested loop: %d\n", i);
                if (i == b) {
                    break;
                }
            }
        } else {
            while (b < 0) {
                b++;
                printf("Negative b: %d\n", b);
            }
        }
    } else {
        switch (a) {
            case -1:
                printf("Negative one\n");
                break;
            case -2:
                printf("Negative two\n");
                break;
            default:
                printf("Other negative\n");
                break;
        }
    }
    return a + b;
}

int test_do_while(int limit) {
    int count = 0;
    do {
        printf("Count: %d\n", count);
        count++;
    } while (count < limit);
    return count;
}