#include <stdio.h>

void outside_before() {
    // 分岐外の関数 - 最初
}

void inside_if() {
    // 分岐内の関数
}

void inside_else() {
    // 分岐内の関数
}

void outside_after() {
    // 分岐外の関数 - 最後
}

int test_function(int x) {
    outside_before();  // 分岐外の呼び出し（最初）
    
    if (x > 0) {
        inside_if();   // 分岐内の呼び出し
        printf("Positive\n");
    } else {
        inside_else(); // 分岐内の呼び出し
        printf("Non-positive\n");
    }
    
    outside_after();   // 分岐外の呼び出し（最後）
    return x;
}