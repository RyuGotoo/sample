#include <X11/Xlib.h>

int main() {
    Display *display;
    XEvent event;
    
    display = XOpenDisplay(NULL);
    
    while (1) {
        XNextEvent(display, &event);
        
        switch (event.type) {
            case ButtonPress:
                printf("Button pressed\n");
                break;
        }
    }
    
    return 0;
}
