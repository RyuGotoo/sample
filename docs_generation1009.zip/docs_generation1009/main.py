import json
import csv
import logging
from pathlib import Path

from src.util import ensure_path_exists, copy_to_dir
from src.core.logger import setup_logger
from src import preprocess
from src import func_docs_gen
from src.xml2md import xml2md


# from src import clean_c_source
# from src import exec_analysis
# from src import update_funcs
# from src import targets


def main():
    # config.json 取得
    config_path = "config.json"
    config_path = ensure_path_exists(config_path)
    with config_path.open(encoding="utf-8") as f:
        config = json.load(f)

    setup_logger(config["output_dir"])
    logger = logging.getLogger(__name__)
    logger.info("処理開始")

    # 出力ディレクトリ作成
    output_dir = Path(config["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    logger.info(f"出力先ディレクトリ作成完了: {str(output_dir)}")

    # configファイルコピー
    copy_to_dir(config_path, output_dir)

    # 前処理実施
    logger.info("===前処理開始===")
    funcs_json_path, events_json_path, guis_json_path, target_functions_path = (
        preprocess.run(config)
    )
    logger.info("===前処理完了===")

    logger.info("===関数ドキュメント生成開始===")
    func_docs_gen.run(
        config=config,
        funcs_json_path=funcs_json_path,
        target_functions_path=target_functions_path,
    )
    logger.info("===関数ドキュメント生成完了===")

    logger.info("===関数ドキュメントXML化開始===")
    try:
        xml2md.main(output_dir)
    except Exception:
        logger.exception("関数ドキュメントXML化でエラーが発生しました")
        raise
    logger.info("===関数ドキュメントXML化完了===")


if __name__ == "__main__":
    main()
