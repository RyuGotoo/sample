import logging
import shutil
from pathlib import Path

logger = logging.getLogger(__name__)


def ensure_path_exists(path: str) -> Path:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"指定されたパスが存在しません: {p}")
    logger.info(f"ファイルの存在を確認: {p}")
    return p


def copy_to_dir(src_path: Path, dest_dir: Path) -> Path:
    ensure_path_exists(src_path)
    ensure_path_exists(dest_dir)

    # コピー先ファイルパスを構築
    dest_path = dest_dir / src_path.name

    # ファイルをコピー
    shutil.copy2(src_path, dest_path)

    return dest_path
