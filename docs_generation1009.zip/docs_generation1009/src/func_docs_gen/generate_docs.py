#!/usr/bin/env python3
"""
C言語関数ドキュメント生成スクリプト

モードに応じて generation_order_no_caller.csv または generation_order_all.csv を入力に、
関数ごとに LLM を用いた XML ドキュメントを生成する。依存待機ロジックは廃止。
"""

import csv
import json
import re
import traceback
import xml.etree.ElementTree as ET
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from src.llm import chat_completions_mock, chat_AzureOpenAI
import logging

logger = logging.getLogger(__name__)


def load_config(config_file: str) -> Dict:
    """config.json を読み込む"""
    try:
        with open(config_file, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        raise Exception(f"設定ファイル {config_file} が見つかりません")
    except json.JSONDecodeError as e:
        raise Exception(
            f"設定ファイル {config_file} のJSONフォーマットが正しくありません: {e}"
        )


def load_file(file_path: str) -> str:
    """ファイルの内容を読み込む"""
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()


def load_analysis_result(analysis_file: str) -> Dict[str, Dict]:
    """analysis_result.jsonを読み込んで関数IDをキーとする辞書を返す"""
    try:
        with open(analysis_file, "r", encoding="utf-8") as f:
            analysis_data = json.load(f)

        analysis_dict = {}
        for item in analysis_data:
            if item.get("type") == "func":
                analysis_dict[item["id"]] = item

        return analysis_dict
    except FileNotFoundError:
        raise Exception(f"解析結果ファイル {analysis_file} が見つかりません")
    except json.JSONDecodeError as e:
        raise Exception(
            f"解析結果ファイル {analysis_file} のJSONフォーマットが正しくありません: {e}"
        )


def load_generation_order(csv_file: str) -> List[Dict[str, str]]:
    """generation_order_* CSV を読み込み、処理用構造に変換する"""
    functions = []
    with open(csv_file, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            functions.append(
                {
                    "order": int(row.get("order") or 0),
                    "id": row["func_id"],
                    "name": row["func_name"],
                    "type": "func",
                    "file_path": row["file_path"],
                    # 互換: 旧コードが参照していたキーはダミー値で維持
                    "deps_num": int(row.get("callee_num", 0)),
                }
            )
    return functions


def extract_process_flow_text(xml_content: str) -> str:
    """XML文字列から <process-flow> 内のテキストを抽出する"""
    try:
        root = ET.fromstring(xml_content)
        pf = root.find("process-flow")
        if pf is None:
            return ""
        return " ".join(pf.itertext())
    except Exception:
        return ""


def get_internal_dependency_names(
    func_id: str, analysis_result: Dict[str, Dict]
) -> List[str]:
    """analysis_result から内部依存関数（func_）の『関数名』一覧を取得する"""
    info = analysis_result.get(func_id)
    if not info:
        return []
    calls = info.get("calls", [])
    internal_ids = [c for c in calls if isinstance(c, str) and c.startswith("func_")]
    names: List[str] = []
    for dep_id in internal_ids:
        dep = analysis_result.get(dep_id)
        if dep and isinstance(dep.get("name"), str):
            names.append(dep["name"])
    return names


def get_function_doc_from_xml(
    func_id: str, output_dir: Path
) -> Optional[Dict[str, str]]:
    """既存の generated_docs.csv から関数ドキュメント情報を取得"""
    csv_path = output_dir / "generated_docs.csv"
    if not csv_path.exists():
        return None

    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row["func_id"] == func_id:
                return {
                    "name": row.get("name", ""),
                    "purpose": row.get("purpose", ""),
                    "summary": row.get("summary", ""),
                }
    return None


def load_generated_docs_csv(output_dir: Path) -> Dict[str, Dict[str, str]]:
    csv_path = output_dir / "generated_docs.csv"
    docs_dict = {}
    if csv_path.exists():
        with open(csv_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                docs_dict[row["func_id"]] = row
    return docs_dict


def save_to_generated_docs_csv(
    func_id: str,
    name: str,
    purpose: str,
    summary: str,
    doc_path: str,
    status: str,
    output_dir: Path,
):
    csv_path = output_dir / "generated_docs.csv"
    fieldnames = ["func_id", "name", "purpose", "summary", "path", "status"]
    file_exists = csv_path.exists()

    with open(csv_path, "a", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()
        writer.writerow(
            {
                "func_id": func_id,
                "name": name,
                "purpose": purpose,
                "summary": summary,
                "path": doc_path,
                "status": status,
            }
        )


def check_function_exists(func_id: str, output_dir: Path) -> bool:
    csv_path = output_dir / "generated_docs.csv"
    if not csv_path.exists():
        return False
    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row["func_id"] == func_id:
                return True
    return False


def extract_function_from_c_file(file_path: str, line_start: int, line_end: int) -> str:
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except UnicodeDecodeError:
        try:
            with open(file_path, "r", encoding="shift_jis") as f:
                lines = f.readlines()
        except Exception as e:
            raise Exception(
                f"ファイル {file_path} を読み込めません (UTF-8/Shift_JIS両方で失敗): {e}"
            )

    start_idx = line_start - 1
    end_idx = line_end
    if start_idx < 0 or end_idx > len(lines):
        raise Exception(
            f"指定された行範囲 {line_start}-{line_end} がファイル範囲外です"
        )
    return "".join(lines[start_idx:end_idx]).strip()


def get_function_calls_from_analysis(analysis_info: Dict) -> List[str]:
    return analysis_info.get("calls", [])


def get_external_function_info_with_count(
    analysis_info: Dict, output_dir: Path
) -> tuple[str, int, int]:
    function_calls = get_function_calls_from_analysis(analysis_info)
    external_info_parts = []
    internal_func_calls = [call for call in function_calls if call.startswith("func_")]
    total_internal_funcs = len(internal_func_calls)
    successfully_retrieved = 0

    for func_call_id in internal_func_calls:
        doc_info = get_function_doc_from_xml(func_call_id, output_dir)
        if doc_info:
            func_name = doc_info.get("name", func_call_id)
            info_text = f"**{func_name}**:\n"
            info_text += f"  目的: {doc_info.get('purpose', '<不明>')}\n"
            info_text += f"  概要: {doc_info.get('summary', '<不明>')}"
            external_info_parts.append(info_text)
            successfully_retrieved += 1

    info_text = "\n\n".join(external_info_parts) if external_info_parts else ""
    return info_text, successfully_retrieved, total_internal_funcs


def get_external_function_info(analysis_info: Dict, output_dir: Path) -> str:
    info_text, _, _ = get_external_function_info_with_count(analysis_info, output_dir)
    return info_text


def create_user_prompt(
    template: str, c_source: str, external_function_info: str
) -> str:
    if external_function_info.strip():
        external_function_section = f"## 外部関数情報:\n\n{external_function_info}"
    else:
        external_function_section = ""
    return template.format(
        c_source=c_source, external_function_info=external_function_section
    )


def parse_xml_from_response(response: str) -> Optional[str]:
    xml_pattern = r"```xml\s*(.*?)\s*```"
    match = re.search(xml_pattern, response, re.DOTALL)
    if match:
        return match.group(1).strip()
    else:
        xml_start = response.find("<function>")
        xml_end = response.find("</function>")
        if xml_start != -1 and xml_end != -1:
            return response[xml_start : xml_end + len("</function>")].strip()
    return None


def validate_and_parse_xml(xml_content: str) -> Dict[str, str]:
    try:
        root = ET.fromstring(xml_content)
        extracted_info = {
            "name": root.find("name").text if root.find("name") is not None else "",
            "purpose": (
                root.find("purpose").text if root.find("purpose") is not None else ""
            ),
            "summary": (
                root.find("summary").text if root.find("summary") is not None else ""
            ),
        }
        return extracted_info
    except ET.ParseError as e:
        raise Exception(f"XMLパースエラー: {e}")


def compute_japanese_ratio(text: str) -> float:
    """summaryに対する日本語（ひらがな・カタカナ・漢字）比率を算出"""
    if text is None:
        return 0.0
    jp_count = 0
    total = 0
    for ch in text:
        if ch.isspace():
            continue
        total += 1
        code = ord(ch)
        if (
            0x3040 <= code <= 0x309F  # ひらがな
            or 0x30A0 <= code <= 0x30FF  # カタカナ
            or 0x4E00 <= code <= 0x9FFF  # CJK統合漢字
            or 0xFF66 <= code <= 0xFF9D  # 半角カナ
        ):
            jp_count += 1
    if total == 0:
        return 0.0
    return jp_count / total


def save_error_log(error_info: Dict, output_dir: Path):
    log_file = output_dir / "error.log"
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"""
================================================================================
時刻: {timestamp}
関数名: {error_info.get('function_name', 'N/A')}
ファイルパス: {error_info.get('file_path', 'N/A')}
エラー: {error_info.get('error_message', 'N/A')}
試行回数: {error_info.get('attempt', 'N/A')}/{error_info.get('max_retries', 'N/A')}
詳細:
{error_info.get('traceback', 'N/A')}
================================================================================
"""
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(log_entry)


def save_function_documents(
    func_info: Dict[str, str],
    xml_content: str,
    user_prompt: str,
    extracted_info: Dict[str, str],
    output_dir: Path,
    worker_id: Optional[int] = None,
):
    """関数ドキュメントを適切なディレクトリ構造で保存し、CSVにも記録する"""
    original_path = Path(func_info["file_path"])
    relative_dir = str(original_path.parent)
    file_stem = original_path.stem

    function_dir = output_dir / relative_dir / file_stem / func_info["name"]
    function_dir.mkdir(parents=True, exist_ok=True)

    user_prompt_filepath = function_dir / "user_prompt.md"
    with open(user_prompt_filepath, "w", encoding="utf-8") as f:
        f.write(user_prompt)

    xml_filepath = function_dir / "doc.xml"
    with open(xml_filepath, "w", encoding="utf-8") as f:
        f.write(xml_content)

    func_id_filepath = function_dir / func_info["id"]
    func_id_filepath.touch()

    save_to_generated_docs_csv(
        func_id=func_info["id"],
        name=extracted_info.get("name", func_info["name"]),
        purpose=extracted_info.get("purpose", ""),
        summary=extracted_info.get("summary", ""),
        doc_path=str(xml_filepath),
        status="completed",
        output_dir=output_dir,
    )

    worker_prefix = f"[Worker {worker_id+1}] " if worker_id is not None else ""
    extra_ctx = {
        "worker_id": (worker_id + 1) if worker_id is not None else "-",
        "func_id": func_info.get("id", "-"),
        "func_order": func_info.get("order", "-"),
    }
    logger.debug(
        f"{worker_prefix}ドキュメント保存完了: {func_info['name']} ({func_info['file_path']}) - {function_dir}",
        extra=extra_ctx,
    )
    logger.debug(
        f"{worker_prefix}  - user_prompt.md: {len(user_prompt)} 文字",
        extra=extra_ctx,
    )
    logger.debug(
        f"{worker_prefix}  - doc.xml: {len(xml_content)} 文字",
        extra=extra_ctx,
    )
    logger.debug(
        f"{worker_prefix}  - {func_info['id']}: 関数IDファイル",
        extra=extra_ctx,
    )


def process_function_with_retry(
    func_info: Dict[str, str],
    config: Dict,
    output_dir: Path,
    analysis_result: Dict[str, Dict],
    worker_id: Optional[int] = None,
    include_external_info: bool = False,
) -> bool:
    """リトライ機能付きで関数を処理する"""
    max_retries = config.get("max_retries", 3)

    prev_xml_for_feedback: Optional[str] = None
    missing_names_for_feedback: List[str] = []

    for attempt in range(max_retries):
        try:
            func_id = func_info["id"]
            if func_id not in analysis_result:
                raise Exception(f"関数ID {func_id} がanalysis_resultに見つかりません")

            analysis_info = analysis_result[func_id]
            line_start = analysis_info["line_start"]
            line_end = analysis_info["line_end"]

            c_source = extract_function_from_c_file(
                func_info["file_path"], line_start, line_end
            )
            log_extra = {
                "worker_id": worker_id + 1 if worker_id is not None else "-",
                "func_id": func_info.get("id", "-"),
                "func_order": func_info.get("order", "-"),
            }
            logger.debug(
                f"[Worker {worker_id+1}] 関数ソースコード抽出完了: {func_info['name']} ({func_info['file_path']}) - {len(c_source)} 文字",
                extra=log_extra,
            )

            if include_external_info:
                external_function_info, retrieved_count, total_count = (
                    get_external_function_info_with_count(analysis_info, output_dir)
                )
                logger.debug(
                    f"[Worker {worker_id+1}] 依存情報取得: {retrieved_count}/{total_count} for {func_info['name']} ({func_info['file_path']})",
                    extra=log_extra,
                )
            else:
                external_function_info = ""

            user_prompt_template = load_file(config["func_user_prompt_template_file"])
            sys_prompt = load_file(config["func_sys_prompt_file"])

            user_prompt = create_user_prompt(
                user_prompt_template, c_source, external_function_info
            )

            # --with-deps 時に、前回不足した関数名がある場合は前回XMLと不足指示を追記
            if (
                include_external_info
                and prev_xml_for_feedback
                and missing_names_for_feedback
            ):
                feedback = (
                    "\n\n前回の回答(XML):\n```xml\n"
                    + prev_xml_for_feedback
                    + "\n```\n"
                    + "process-flow に次の関数に関する記述が含まれていません: "
                    + ", ".join(missing_names_for_feedback)
                    + "。これらを含めて process-flow を更新したXMLを再生成してください。"
                )
                user_prompt = user_prompt + feedback
            logger.debug(
                f"[Worker {worker_id+1}] プロンプト作成完了: {func_info['name']} ({func_info['file_path']}) - {len(user_prompt)} 文字",
                extra=log_extra,
            )

            # response = chat_completions_mock(sys_prompt, user_prompt)
            response = chat_AzureOpenAI(sys_prompt, user_prompt)
            logger.debug(
                f"[Worker {worker_id+1}] LLM応答取得完了: {func_info['name']} ({func_info['file_path']}) - {len(response)} 文字",
                extra=log_extra,
            )

            xml_content = parse_xml_from_response(response)
            if xml_content is None:
                raise Exception("レスポンスからXMLを抽出できませんでした")

            extracted_info = validate_and_parse_xml(xml_content)

            # 言語チェック（summary の日本語率）: 履歴は持たずに単純リトライ
            if config.get("language_check_enabled", True):
                threshold = float(config.get("language_threshold", 0.35))
                summary_text = extracted_info.get("summary", "")
                jp_ratio = compute_japanese_ratio(summary_text)
                if jp_ratio < threshold:
                    logger.warning(
                        f"summaryの日本語率が閾値未満: len={len(summary_text)} jp_ratio={jp_ratio:.2f} threshold={threshold}",
                        extra=log_extra,
                    )
                    raise Exception("言語不備: summary が日本語ではありません")

            # --with-deps の場合、process-flow に依存関数名が含まれているかを検証
            if include_external_info:
                dep_names = get_internal_dependency_names(func_id, analysis_result)
                if dep_names:
                    pf_text = extract_process_flow_text(xml_content)
                    missing = [n for n in dep_names if n and n not in pf_text]
                    if missing:
                        logger.warning(
                            "process-flow に依存関数の記述が不足: "
                            + ", ".join(missing),
                            extra=log_extra,
                        )
                        # 次の試行に向けて前回XMLと不足名を保持し、例外としてリトライへ
                        prev_xml_for_feedback = xml_content
                        missing_names_for_feedback = missing
                        raise Exception("内容不備: process-flow に未記載の依存関数あり")

            save_function_documents(
                func_info,
                xml_content,
                user_prompt,
                extracted_info,
                output_dir,
                worker_id,
            )

            return True

        except Exception as e:
            error_info = {
                "function_name": func_info["name"],
                "file_path": func_info["file_path"],
                "error_message": str(e),
                "attempt": attempt + 1,
                "max_retries": max_retries,
                "traceback": traceback.format_exc(),
            }
            save_error_log(error_info, output_dir)

            logger.error(
                f"[Worker {worker_id+1}] 試行 {attempt + 1}/{max_retries} 失敗: {func_info['name']} ({func_info['id']}) ({func_info['file_path']}) - {e}",
                extra=log_extra,
            )

            if attempt < max_retries - 1:
                retry_delay = config.get("retry_delay_seconds", 1)
                logger.warning(
                    f"[Worker {worker_id+1}] {retry_delay}秒後にリトライします: {func_info['name']} ({func_info['id']}) ({func_info['file_path']})",
                    extra=log_extra,
                )
                time.sleep(retry_delay)
            else:
                logger.error(
                    f"  最大リトライ回数に達しました。関数 {func_info['name']} ({func_info['id']}) の処理をスキップします。",
                    extra=log_extra,
                )
                raise

    return False


def worker_process(
    worker_id: int,
    num_workers: int,
    functions_list: List[Dict[str, str]],
    config: Dict,
    output_dir: Path,
    analysis_result: Dict[str, Dict],
    include_external_info: bool,
):
    """各ワーカーが担当する関数を処理する（依存待機なし）"""
    processed = set()
    total_functions = len(functions_list)

    for func_info in functions_list:
        order = int(func_info.get("order", 0))
        if num_workers > 0 and order % num_workers != worker_id:
            continue

        func_id = func_info["id"]
        if func_id in processed:
            continue

        current_time = datetime.now().strftime("%H:%M:%S")
        progress = f"[{order}/{total_functions}]" if order else f"[?/{total_functions}]"
        log_extra = {
            "worker_id": worker_id + 1,
            "func_id": func_id,
            "func_order": order,
        }
        logger.info(
            f"{progress} [Worker {worker_id+1}/{num_workers}] {func_info['name']} ({func_info['id']}) を処理中... ({current_time})",
            extra=log_extra,
        )

        start_time = time.time()
        try:
            success = process_function_with_retry(
                func_info,
                config,
                output_dir,
                analysis_result,
                worker_id,
                include_external_info,
            )
            if success:
                elapsed_time = time.time() - start_time
                logger.info(
                    f"✓ [Worker {worker_id+1}] {func_info['name']} ({func_info['id']}) の処理が完了しました ({elapsed_time:.1f}秒)",
                    extra=log_extra,
                )
                processed.add(func_id)
            else:
                logger.error(
                    f"✗ {func_info['name']} ({func_info['id']}) の処理に失敗しました",
                    extra=log_extra,
                )
        except Exception as e:
            error_info = {
                "function_name": func_info["name"],
                "file_path": func_info["file_path"],
                "error_message": f"全試行失敗: {str(e)}",
                "attempt": "FINAL",
                "max_retries": config.get("max_retries", 3),
                "traceback": traceback.format_exc(),
            }
            save_error_log(error_info, output_dir)
            logger.error(
                f"✗ [Worker {worker_id+1}] {func_info['name']} ({func_info['id']}) の処理でエラーが発生しました: {e}",
                extra=log_extra,
            )

    logger.info(
        f"Worker {worker_id+1} の処理が完了しました", extra={"worker_id": worker_id + 1}
    )


def main(with_deps: bool, config_path):
    # 設定読み込み
    config = load_config(config_path)

    # 出力ディレクトリの準備
    output_dir = Path(config["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)

    logger.info(f"設定ファイル {config_path} を読み込みました")

    # 解析データ読み込み
    analysis_result = load_analysis_result(output_dir / "funcs.json")
    logger.info(f"解析結果を読み込みました: {len(analysis_result)}件の関数")

    # 入力CSVを決定
    order_filename = (
        "generation_order_all.csv" if with_deps else "generation_order_with_caller.csv"
    )
    generation_order_file = output_dir / order_filename
    logger.info(f"入力CSV: {generation_order_file}")
    if not generation_order_file.exists():
        raise FileNotFoundError(
            f"入力CSVが見つかりません: {generation_order_file}。先に determine_generation_order.py を実行してください。"
        )

    logger.info("処理対象関数を読み込み中...")
    functions_to_process = load_generation_order(str(generation_order_file))
    logger.info(f"処理対象関数: {len(functions_to_process)}件")

    num_workers = config.get("num_workers", 1)
    logger.info(f"実行モード: {num_workers}ワーカー / with-deps={with_deps}")

    with ThreadPoolExecutor(max_workers=num_workers) as executor:
        futures = [
            executor.submit(
                worker_process,
                worker_id,
                num_workers,
                functions_to_process,
                config,
                output_dir,
                analysis_result,
                with_deps,
            )
            for worker_id in range(num_workers)
        ]
        for future in futures:
            future.result()

    logger.info(f"ドキュメント生成が完了しました。出力先: {output_dir}")


if __name__ == "__main__":
    main()
