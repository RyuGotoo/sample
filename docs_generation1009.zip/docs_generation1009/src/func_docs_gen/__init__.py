import logging
from pathlib import Path

from src.util import ensure_path_exists
from src.func_docs_gen import determine_generation_order
from src.func_docs_gen import generate_docs

logger = logging.getLogger()


def run(config, funcs_json_path, target_functions_path):
    config_path = Path(config["output_dir"]) / "config.json"
    determine_generation_order.main(config=config)
    generate_docs.main(with_deps=False, config_path=config_path)
    generate_docs.main(with_deps=True, config_path=config_path)
