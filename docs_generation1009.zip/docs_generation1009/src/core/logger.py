# core/logger.py
import logging
import sys
from datetime import datetime
from pathlib import Path


def setup_logger(output_dir) -> logging.Logger:
    """
    全体共通のルートロガー設定を初期化する。
    - output_dir: config["output_dir"] を渡す
    - ログファイル名は 'YYYYMMDD_HHMMSS.log'
    """

    # 出力ディレクトリ
    log_dir = Path(output_dir) / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    # ファイル名にタイムスタンプ付与
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = log_dir / f"{timestamp}.log"

    # ルートロガー設定
    root_logger = logging.getLogger()
    if root_logger.handlers:
        return root_logger  # 既に設定済みなら再利用

    root_logger.setLevel(logging.DEBUG)

    formatter = logging.Formatter(
        fmt="%(asctime)s [%(levelname)s] %(name)s:%(lineno)d - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # コンソール出力（INFO以上）
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    # ファイル出力（DEBUG以上）
    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)
    root_logger.addHandler(file_handler)

    root_logger.debug(f"Root logger initialized: {log_path.resolve()}")
    return root_logger
