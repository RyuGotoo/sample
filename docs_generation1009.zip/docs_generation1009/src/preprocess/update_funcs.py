import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple


def fill_implemented_at(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    proto要素にimplemented_atを補完する。
    - 既にimplemented_atがある場合はスキップする。
    - 同一file_path, nameのfuncがある場合、そのfuncのidをimplemented_atに設定する。
    - funcが複数あっても最初に見つかったものを採用する（安定O(n)）。
    """
    # (file_path, name) -> func_id のインデックスを作成
    func_index: Dict[Tuple[str, str], str] = {}
    for item in items:
        if item.get("type") == "func":
            key = (item.get("file_path"), item.get("name"))
            # 先勝ちにする（後勝ちにしたい場合は単純代入にする）
            func_index.setdefault(key, item.get("id"))

    # protoにimplemented_atを補完
    for item in items:
        if item.get("type") != "proto":
            continue
        if item.get("implemented_at"):  # 既に値がある場合はスキップ
            continue
        key = (item.get("file_path"), item.get("name"))
        impl_id = func_index.get(key)
        if impl_id:
            item["implemented_at"] = impl_id

    return items


def run(funcs_json_path: Path):
    output_path = funcs_json_path.parent / "funcs.json"

    # データ読み込み
    with open(funcs_json_path, "r", encoding="utf-8") as f:
        records = json.load(f)

    fixed_records = fill_implemented_at(records)

    # 結果保存
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(fixed_records, f, ensure_ascii=False, indent=2)
