import subprocess
import json
from pathlib import Path


def exec(analyzer_path: Path, c_source_dir: Path, output_dir: Path):
    analyzer_path = Path(analyzer_path).resolve()
    output_dir = Path(output_dir).resolve()

    # 実行コマンド定義
    commands = [
        [
            str(analyzer_path),
            "func",
            str(c_source_dir),
            "-o",
            str(output_dir / "funcs_tmp.json"),
            "-pv",
        ],
        # [
        #     str(analyzer_path),
        #     "func",
        #     str(c_source_dir),
        #     "-o",
        #     str(output_dir / "funcs_control_flow.json"),
        #     "-pv",
        #     "--control-flow",
        # ],
        [
            str(analyzer_path),
            "event",
            str(c_source_dir),
            "-o",
            str(output_dir / "events.json"),
            "-pv",
        ],
        [
            str(analyzer_path),
            "gui",
            str(c_source_dir),
            "-o",
            str(output_dir / "guis.json"),
            "-pv",
        ],
    ]

    # 実行ループ
    for cmd in commands:
        result = subprocess.run(cmd, capture_output=True, text=True)
        # if result.returncode == 0:
        #     print("成功:", result.stdout)
        # else:
        #     print("エラー:", result.stderr)
