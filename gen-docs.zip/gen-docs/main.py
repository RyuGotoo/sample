#!/usr/bin/env python3
"""
メインワークフロー: 関数依存グラフ作成 → 依存解決ドキュメント生成
"""

from pathlib import Path
import sys
import argparse

# srcディレクトリをパスに追加
sys.path.append(str(Path(__file__).parent / "src"))

from dependency_graph import create_calls_json
from doc_generator import process_all_functions


def main():
    """メインワークフロー実行"""
    parser = argparse.ArgumentParser(
        description="関数ドキュメント自動生成ツール",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用例:
  python main.py                           # デフォルト設定で実行
  python main.py --source-dir c_source/   # ソースディレクトリを指定
  python main.py --source-dir ../project/src/ --output-dir output/
        """,
    )

    parser.add_argument(
        "--source-dir",
        default="c_source/",
        help="Cソースファイルが格納されているディレクトリ (デフォルト: c_source/)",
    )

    parser.add_argument(
        "--output-dir",
        default="docs",
        help="ドキュメント出力ディレクトリ (デフォルト: docs)",
    )

    parser.add_argument(
        "--calls-json",
        default="out.json",
        help="関数情報JSONファイル (デフォルト: out.json)",
    )

    args = parser.parse_args()

    print("=== 関数ドキュメント自動生成ツール ===")
    print(f"ソースディレクトリ: {args.source_dir}")
    print(f"出力ディレクトリ: {args.output_dir}")

    # ステップ1: 関数依存グラフ作成
    print("\n1. 関数依存グラフを作成中...")
    try:
        create_calls_json(args.calls_json, "src/calls.json")
        print("✓ 依存関係グラフの作成が完了しました")
    except Exception as e:
        print(f"✗ 依存関係グラフの作成でエラーが発生しました: {e}")
        return

    # ステップ2: 依存解決ドキュメント生成
    print("\n2. 依存順序に従ってドキュメントを生成中...")
    try:
        generated_docs = process_all_functions(
            calls_json_path="src/calls.json",
            sys_prompt_path="prompts/sys_prompt.md",
            user_prompt_path="prompts/user_prompt.md",
            output_dir=args.output_dir,
            source_dir=args.source_dir,
        )
        print(f"✓ {len(generated_docs)}個の関数ドキュメントの生成が完了しました")
    except Exception as e:
        print(f"✗ ドキュメント生成でエラーが発生しました: {e}")
        return

    print("\n=== 処理完了 ===")
    print(f"生成されたドキュメントは {args.output_dir}/ ディレクトリに保存されました")


if __name__ == "__main__":
    main()
