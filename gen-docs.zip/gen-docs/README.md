# gen-docs

C言語関数の自動ドキュメント生成ツール

## 概要

このツールは、C言語のプロジェクトから関数情報を解析し、依存関係を考慮しながらAIを使用して自動的に関数ドキュメントを生成します。

## 主な機能

1. **関数依存グラフ作成**: C言語関数の呼び出し関係を解析し、依存グラフを作成
2. **依存解決ドキュメント生成**: 依存関係の深い順（leaf関数から）にドキュメントを生成
3. **コンテキスト重視**: 呼び出し先関数の情報を呼び出し元の生成プロンプトに含める

## 前提条件

- Python 3.13+
- [uv](https://docs.astral.sh/uv/) (Python パッケージマネージャー)
- [Ollama](https://ollama.com/) (ローカルLLM実行環境)
- Ollamaで`qwen3:4b`モデルがインストール済み

## ファイル構成

```
gen-docs/
├── main.py                    # メインエントリーポイント
├── out.json                   # 入力: C言語関数解析結果
├── src/
│   ├── dependency_graph.py    # 依存関係グラフ生成
│   ├── doc_generator.py       # ドキュメント生成
│   ├── llm.py                # LLM呼び出し
│   ├── continue_generation.py # 中断時の継続実行用
│   └── calls.json            # 生成: 依存関係データ
├── prompts/
│   ├── sys_prompt.md         # システムプロンプト
│   └── user_prompt.md        # ユーザープロンプト
├── docs/                     # 出力: 生成されたドキュメント
├── c_source/                  # C言語ソースファイル
└── pyproject.toml
```

## 使用方法

### 1. 依存関係のインストール

```bash
uv sync
```

### 2. Ollamaの準備

```bash
# Ollamaをインストール（未インストールの場合）
# https://ollama.com/

# モデルをダウンロード
ollama pull qwen3:4b
```

### 3. 入力ファイルの準備

- `out.json`: C言語関数の解析結果（既存）
- `c_source/`: 対象のC言語ソースファイル

### 4. ドキュメント生成の実行

```bash
uv run python main.py
```

実行すると以下の処理が順次実行されます：

1. 関数依存グラフの作成（`src/calls.json`に保存）
2. 依存順序に従った関数ドキュメントの生成（`docs/`に保存）

### 5. 生成結果の確認

`docs/`ディレクトリに以下の形式でXMLドキュメントが生成されます：

- `{関数名}_{関数ID}.xml`

例: `add_func_56a32a400699f829.xml`

## 生成されるドキュメント形式

各関数ドキュメントは以下のXML構造で生成されます：

```xml
<function>
  <name>関数名</name>
  <purpose>関数の目的</purpose>
  <summary>関数の概要</summary>
  <arguments>
    <arg>
      <name>引数名</name>
      <type>引数の型</type>
      <description>引数の説明</description>
    </arg>
  </arguments>
  <return-value>
    <type>戻り値の型</type>
    <description>戻り値の説明</description>
  </return-value>
  <remarks>注意事項・備考</remarks>
  <process-flow>
    <step>処理ステップ1</step>
    <step>処理ステップ2</step>
  </process-flow>
  <database-queries>
    <query>
      <description>クエリの説明</description>
      <pseudo-sql>擬似SQL</pseudo-sql>
    </query>
  </database-queries>
</function>
```

## カスタマイズ

### プロンプトの編集

- `prompts/sys_prompt.md`: システムプロンプト（AIの役割・指示）
- `prompts/user_prompt.md`: ユーザープロンプト（具体的なタスク）

### LLMモデルの変更

`src/llm.py`の`model`パラメータを変更：

```python
model="qwen3:4b"  # 他のOllamaモデルに変更可能
```

## トラブルシューティング

### 生成が中断された場合

```bash
cd src
uv run python continue_generation.py
```

### エラーが発生した場合

1. Ollamaが起動していることを確認
2. 必要なモデルがダウンロード済みか確認
3. `out.json`と`c_source/`のファイルパスが正しいか確認

## ライセンス

このプロジェクトはMITライセンスの下で公開されています。