#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/stat.h>

char* utils_trim_whitespace(char* str) {
    if (str == NULL) {
        return NULL;
    }
    
    // 先頭の空白文字をスキップ
    while (isspace((unsigned char)*str)) {
        str++;
    }
    
    if (*str == '\0') {
        return str;
    }
    
    // 末尾の空白文字を除去
    char* end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end)) {
        *end = '\0';
        end--;
    }
    
    return str;
}

bool utils_is_empty_string(const char* str) {
    return (str == NULL || *str == '\0');
}

ErrorCode utils_safe_strcpy(char* dest, const char* src, size_t dest_size) {
    if (dest == NULL || src == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    if (strlen(src) >= dest_size) {
        return ERROR_INVALID_ID; // 適切なエラーコードに変更可能
    }
    
    strcpy(dest, src);
    return SUCCESS;
}

bool utils_is_valid_email(const char* email) {
    if (utils_is_empty_string(email)) {
        return false;
    }
    
    // 簡単な email 検証
    const char* at_sign = strchr(email, '@');
    if (at_sign == NULL || at_sign == email) {
        return false;
    }
    
    const char* dot = strrchr(at_sign, '.');
    if (dot == NULL || dot == at_sign + 1) {
        return false;
    }
    
    return strlen(email) < MAX_EMAIL_LENGTH;
}

bool utils_is_valid_name(const char* name) {
    if (utils_is_empty_string(name)) {
        return false;
    }
    
    if (strlen(name) >= MAX_NAME_LENGTH) {
        return false;
    }
    
    // 名前に適切な文字のみが含まれているかチェック
    for (const char* p = name; *p; p++) {
        if (!isalpha(*p) && *p != ' ' && *p != '-' && *p != '\'') {
            return false;
        }
    }
    
    return true;
}

bool utils_is_valid_id_range(int id) {
    return (id > 0 && id <= 999999); // 6桁以下の正の整数
}

time_t utils_get_current_time(void) {
    return time(NULL);
}

char* utils_format_time(time_t timestamp, char* buffer, size_t buffer_size) {
    if (buffer == NULL) {
        return NULL;
    }
    
    struct tm* time_info = localtime(&timestamp);
    if (time_info == NULL) {
        snprintf(buffer, buffer_size, "Invalid time");
        return buffer;
    }
    
    strftime(buffer, buffer_size, "%Y-%m-%d %H:%M:%S", time_info);
    return buffer;
}

bool utils_file_exists(const char* filename) {
    if (filename == NULL) {
        return false;
    }
    
    struct stat file_stat;
    return (stat(filename, &file_stat) == 0);
}

void* utils_safe_malloc(size_t size) {
    if (size == 0) {
        return NULL;
    }
    
    void* ptr = malloc(size);
    if (ptr == NULL) {
        utils_log_error("utils_safe_malloc", ERROR_MEMORY_ALLOCATION);
    }
    
    return ptr;
}

void utils_safe_free(void** ptr) {
    if (ptr != NULL && *ptr != NULL) {
        free(*ptr);
        *ptr = NULL;
    }
}

double utils_round_to_decimal_places(double value, int decimal_places) {
    if (decimal_places < 0) {
        return value;
    }
    
    double multiplier = 1.0;
    for (int i = 0; i < decimal_places; i++) {
        multiplier *= 10.0;
    }
    
    return round(value * multiplier) / multiplier;
}

double utils_clamp_double(double value, double min_val, double max_val) {
    if (value < min_val) return min_val;
    if (value > max_val) return max_val;
    return value;
}

void utils_log_message(const char* level, const char* message) {
    if (level == NULL || message == NULL) {
        return;
    }
    
    time_t now = utils_get_current_time();
    char time_buffer[64];
    utils_format_time(now, time_buffer, sizeof(time_buffer));
    
    printf("[%s] %s: %s\n", time_buffer, level, message);
}

void utils_log_error(const char* function_name, ErrorCode error_code) {
    char error_msg[256];
    snprintf(error_msg, sizeof(error_msg), 
             "Error in %s: %s", 
             function_name ? function_name : "unknown function",
             utils_error_code_to_string(error_code));
    
    utils_log_message("ERROR", error_msg);
}

const char* utils_error_code_to_string(ErrorCode code) {
    switch (code) {
        case SUCCESS: return "Success";
        case ERROR_NULL_POINTER: return "Null pointer error";
        case ERROR_INVALID_ID: return "Invalid ID";
        case ERROR_STUDENT_NOT_FOUND: return "Student not found";
        case ERROR_DUPLICATE_ID: return "Duplicate ID";
        case ERROR_FILE_NOT_FOUND: return "File not found";
        case ERROR_MEMORY_ALLOCATION: return "Memory allocation failed";
        case ERROR_INVALID_GRADE: return "Invalid grade";
        case ERROR_MAX_STUDENTS_REACHED: return "Maximum students reached";
        default: return "Unknown error";
    }
}