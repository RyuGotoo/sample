#ifndef UTILS_H
#define UTILS_H

#include "config.h"
#include <stdbool.h>
#include <time.h>

// 文字列処理関数
char* utils_trim_whitespace(char* str);
bool utils_is_empty_string(const char* str);
ErrorCode utils_safe_strcpy(char* dest, const char* src, size_t dest_size);
ErrorCode utils_safe_strcat(char* dest, const char* src, size_t dest_size);
int utils_string_to_int(const char* str, int* result);
int utils_string_to_double(const char* str, double* result);

// 入力検証関数
bool utils_is_valid_email(const char* email);
bool utils_is_valid_name(const char* name);
bool utils_is_valid_id_range(int id);
bool utils_is_numeric_string(const char* str);
bool utils_contains_only_letters(const char* str);

// 時間処理関数
time_t utils_get_current_time(void);
char* utils_format_time(time_t timestamp, char* buffer, size_t buffer_size);
int utils_calculate_age_in_years(time_t birth_date);
bool utils_is_valid_date_range(time_t date);

// ファイル処理ユーティリティ
bool utils_file_exists(const char* filename);
long utils_get_file_size(const char* filename);
ErrorCode utils_create_backup_filename(const char* original, char* backup, size_t backup_size);
ErrorCode utils_ensure_directory_exists(const char* path);

// メモリ管理ユーティリティ
void* utils_safe_malloc(size_t size);
void* utils_safe_realloc(void* ptr, size_t new_size);
void utils_safe_free(void** ptr);
ErrorCode utils_initialize_array(void* array, size_t element_size, size_t count);

// 数値処理関数
double utils_round_to_decimal_places(double value, int decimal_places);
double utils_clamp_double(double value, double min_val, double max_val);
int utils_clamp_int(int value, int min_val, int max_val);
double utils_calculate_percentage(double part, double whole);

// ログ・デバッグ関数
void utils_log_message(const char* level, const char* message);
void utils_log_error(const char* function_name, ErrorCode error_code);
void utils_debug_print_student_brief(const void* student);

// エラーコード処理
const char* utils_error_code_to_string(ErrorCode code);
bool utils_is_critical_error(ErrorCode code);

#endif // UTILS_H