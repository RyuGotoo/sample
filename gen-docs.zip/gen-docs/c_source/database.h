#ifndef DATABASE_H
#define DATABASE_H

#include "config.h"
#include "student.h"
#include <stdio.h>

// データベース操作結果
typedef struct {
    ErrorCode status;
    int affected_rows;
    char error_message[256];
} DatabaseResult;

// データベース接続情報
typedef struct {
    char filename[MAX_FILENAME_LENGTH];
    FILE* file_handle;
    bool is_open;
    bool is_readonly;
    int record_count;
} DatabaseConnection;

// データベース初期化・終了処理
ErrorCode database_init(DatabaseConnection* conn, const char* filename, bool readonly);
ErrorCode database_close(DatabaseConnection* conn);
ErrorCode database_create_backup(const DatabaseConnection* conn, const char* backup_suffix);

// 学生データの保存・読み込み
ErrorCode database_save_student(DatabaseConnection* conn, const Student* student);
ErrorCode database_load_all_students(DatabaseConnection* conn, StudentSystem* system);
ErrorCode database_load_student_by_id(DatabaseConnection* conn, int id, Student* student);

// データベースファイル操作
ErrorCode database_create_file_if_not_exists(const char* filename);
ErrorCode database_write_header(DatabaseConnection* conn);
ErrorCode database_read_header(DatabaseConnection* conn);
ErrorCode database_validate_file_format(const DatabaseConnection* conn);

// CSV形式でのデータ処理
ErrorCode database_write_student_csv(FILE* file, const Student* student);
ErrorCode database_read_student_csv(FILE* file, Student* student);
ErrorCode database_parse_csv_line(const char* line, Student* student);
ErrorCode database_format_student_csv_line(const Student* student, char* line, size_t line_size);

// データベース検索・フィルタリング
ErrorCode database_find_students_by_major(DatabaseConnection* conn, Major major, 
                                         Student* results, int max_results, int* found_count);
ErrorCode database_find_students_by_year(DatabaseConnection* conn, Year year,
                                        Student* results, int max_results, int* found_count);
ErrorCode database_find_students_by_gpa_range(DatabaseConnection* conn, double min_gpa, double max_gpa,
                                             Student* results, int max_results, int* found_count);

// データベース統計情報
ErrorCode database_get_student_count(DatabaseConnection* conn, int* count);
ErrorCode database_get_average_gpa(DatabaseConnection* conn, double* avg_gpa);
ErrorCode database_get_major_distribution(DatabaseConnection* conn, int major_counts[]);

// データベースメンテナンス
ErrorCode database_compact_file(DatabaseConnection* conn);
ErrorCode database_verify_integrity(DatabaseConnection* conn);
ErrorCode database_remove_student_by_id(DatabaseConnection* conn, int id);
ErrorCode database_update_student(DatabaseConnection* conn, const Student* student);

// エラー処理とログ
void database_log_operation(const char* operation, ErrorCode result);
ErrorCode database_handle_file_error(DatabaseConnection* conn, const char* operation);
bool database_is_connection_valid(const DatabaseConnection* conn);

#endif // DATABASE_H