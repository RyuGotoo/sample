#include "student.h"
#include "utils.h"
#include "database.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

ErrorCode student_system_init(StudentSystem* system, int capacity) {
    if (system == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    if (capacity <= 0 || capacity > MAX_STUDENTS) {
        return ERROR_INVALID_ID;
    }
    
    system->students = (Student*)utils_safe_malloc(sizeof(Student) * capacity);
    if (system->students == NULL) {
        return ERROR_MEMORY_ALLOCATION;
    }
    
    system->count = 0;
    system->capacity = capacity;
    
    // 学生配列を初期化
    ErrorCode result = utils_initialize_array(system->students, 
                                            sizeof(Student), 
                                            capacity);
    if (result != SUCCESS) {
        utils_safe_free((void**)&system->students);
        return result;
    }
    
    utils_log_message("INFO", "Student system initialized successfully");
    return SUCCESS;
}

void student_system_cleanup(StudentSystem* system) {
    if (system == NULL) {
        return;
    }
    
    if (system->students != NULL) {
        utils_safe_free((void**)&system->students);
    }
    
    system->count = 0;
    system->capacity = 0;
    
    utils_log_message("INFO", "Student system cleaned up");
}

ErrorCode student_create(Student* student, int id, const char* name, 
                        const char* email, Year year, Major major) {
    if (student == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    // 入力値を検証
    ErrorCode validation_result = student_validate_id(id);
    if (validation_result != SUCCESS) {
        return validation_result;
    }
    
    validation_result = student_validate_name(name);
    if (validation_result != SUCCESS) {
        return validation_result;
    }
    
    validation_result = student_validate_email(email);
    if (validation_result != SUCCESS) {
        return validation_result;
    }
    
    // 学生構造体を初期化
    memset(student, 0, sizeof(Student));
    
    student->id = id;
    utils_safe_strcpy(student->name, name, sizeof(student->name));
    utils_safe_strcpy(student->email, email, sizeof(student->email));
    student->year = year;
    student->major = major;
    student->enrollment_date = utils_get_current_time();
    student->gpa = 0.0;
    student->total_credits = 0;
    student->grade_count = 0;
    
    return SUCCESS;
}

ErrorCode student_add_to_system(StudentSystem* system, const Student* student) {
    if (system == NULL || student == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    if (system->count >= system->capacity) {
        return ERROR_MAX_STUDENTS_REACHED;
    }
    
    // 重複IDをチェック
    if (student_find_by_id(system, student->id) != NULL) {
        return ERROR_DUPLICATE_ID;
    }
    
    // 学生をシステムに追加
    memcpy(&system->students[system->count], student, sizeof(Student));
    system->count++;
    
    char log_msg[128];
    snprintf(log_msg, sizeof(log_msg), 
             "Student %d (%s) added to system", 
             student->id, student->name);
    utils_log_message("INFO", log_msg);
    
    return SUCCESS;
}

Student* student_find_by_id(const StudentSystem* system, int id) {
    if (system == NULL || system->students == NULL) {
        return NULL;
    }
    
    if (student_validate_id(id) != SUCCESS) {
        return NULL;
    }
    
    // 線形検索で学生を探す
    for (int i = 0; i < system->count; i++) {
        if (system->students[i].id == id) {
            return &system->students[i];
        }
    }
    
    return NULL;
}

Student* student_find_by_name(const StudentSystem* system, const char* name) {
    if (system == NULL || system->students == NULL || name == NULL) {
        return NULL;
    }
    
    if (student_validate_name(name) != SUCCESS) {
        return NULL;
    }
    
    // 名前で検索（部分一致）
    for (int i = 0; i < system->count; i++) {
        if (strstr(system->students[i].name, name) != NULL) {
            return &system->students[i];
        }
    }
    
    return NULL;
}

ErrorCode student_add_grade(Student* student, const char* course_name, 
                           double grade, int credits) {
    if (student == NULL || course_name == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    if (student_validate_grade(grade) != SUCCESS) {
        return ERROR_INVALID_GRADE;
    }
    
    if (student->grade_count >= MAX_COURSES_PER_STUDENT) {
        return ERROR_MAX_STUDENTS_REACHED; // 適切なエラーコードに変更可能
    }
    
    // 成績を追加
    Grade* new_grade = &student->grades[student->grade_count];
    utils_safe_strcpy(new_grade->course_name, course_name, 
                     sizeof(new_grade->course_name));
    new_grade->grade = grade;
    new_grade->credits = credits;
    new_grade->completion_date = utils_get_current_time();
    
    student->grade_count++;
    
    // GPA と総単位数を更新
    student_update_total_credits(student);
    student_calculate_gpa(student);
    
    return SUCCESS;
}

ErrorCode student_calculate_gpa(Student* student) {
    if (student == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    if (student->grade_count == 0) {
        student->gpa = 0.0;
        return SUCCESS;
    }
    
    double total_grade_points = 0.0;
    int total_credits = 0;
    
    // 各科目の成績点を計算
    for (int i = 0; i < student->grade_count; i++) {
        double grade_point = student->grades[i].grade / 25.0; // 4.0スケールに変換
        grade_point = utils_clamp_double(grade_point, 0.0, 4.0);
        
        total_grade_points += grade_point * student->grades[i].credits;
        total_credits += student->grades[i].credits;
    }
    
    if (total_credits > 0) {
        student->gpa = utils_round_to_decimal_places(
            total_grade_points / total_credits, 2);
    } else {
        student->gpa = 0.0;
    }
    
    return SUCCESS;
}

ErrorCode student_update_total_credits(Student* student) {
    if (student == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    int total = 0;
    for (int i = 0; i < student->grade_count; i++) {
        total += student->grades[i].credits;
    }
    
    student->total_credits = total;
    return SUCCESS;
}

int student_compare_by_gpa(const void* a, const void* b) {
    const Student* student_a = (const Student*)a;
    const Student* student_b = (const Student*)b;
    
    if (student_a->gpa > student_b->gpa) return -1;
    if (student_a->gpa < student_b->gpa) return 1;
    return 0;
}

int student_compare_by_name(const void* a, const void* b) {
    const Student* student_a = (const Student*)a;
    const Student* student_b = (const Student*)b;
    
    return strcmp(student_a->name, student_b->name);
}

int student_compare_by_id(const void* a, const void* b) {
    const Student* student_a = (const Student*)a;
    const Student* student_b = (const Student*)b;
    
    return student_a->id - student_b->id;
}

ErrorCode student_validate_id(int id) {
    if (!utils_is_valid_id_range(id)) {
        return ERROR_INVALID_ID;
    }
    return SUCCESS;
}

ErrorCode student_validate_grade(double grade) {
    if (grade < MIN_GRADE || grade > MAX_GRADE) {
        return ERROR_INVALID_GRADE;
    }
    return SUCCESS;
}

ErrorCode student_validate_name(const char* name) {
    if (!utils_is_valid_name(name)) {
        return ERROR_INVALID_ID; // 適切なエラーコードに変更可能
    }
    return SUCCESS;
}

ErrorCode student_validate_email(const char* email) {
    if (!utils_is_valid_email(email)) {
        return ERROR_INVALID_ID; // 適切なエラーコードに変更可能
    }
    return SUCCESS;
}

void student_print_info(const Student* student) {
    if (student == NULL) {
        printf("Error: NULL student pointer\n");
        return;
    }
    
    char time_buffer[64];
    utils_format_time(student->enrollment_date, time_buffer, sizeof(time_buffer));
    
    printf("=== Student Information ===\n");
    printf("ID: %d\n", student->id);
    printf("Name: %s\n", student->name);
    printf("Email: %s\n", student->email);
    printf("Year: %d\n", student->year);
    printf("Major: %d\n", student->major);
    printf("Enrollment Date: %s\n", time_buffer);
    printf("GPA: %.2f\n", student->gpa);
    printf("Total Credits: %d\n", student->total_credits);
    printf("Courses Completed: %d\n", student->grade_count);
}

void student_print_grades(const Student* student) {
    if (student == NULL) {
        printf("Error: NULL student pointer\n");
        return;
    }
    
    printf("\n=== Grade Report for %s ===\n", student->name);
    
    if (student->grade_count == 0) {
        printf("No grades recorded.\n");
        return;
    }
    
    for (int i = 0; i < student->grade_count; i++) {
        const Grade* grade = &student->grades[i];
        char time_buffer[64];
        utils_format_time(grade->completion_date, time_buffer, sizeof(time_buffer));
        
        printf("Course: %-20s Grade: %6.1f Credits: %2d Date: %s\n",
               grade->course_name, grade->grade, grade->credits, time_buffer);
    }
    
    printf("Overall GPA: %.2f\n", student->gpa);
}

void student_print_summary(const Student* student) {
    if (student == NULL) {
        printf("Error: NULL student pointer\n");
        return;
    }
    
    printf("Student %d: %-25s GPA: %4.2f Credits: %3d\n",
           student->id, student->name, student->gpa, student->total_credits);
}