#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "config.h"
#include "student.h"
#include "database.h"
#include "utils.h"
#include "report.h"

// 関数プロトタイプ宣言
ErrorCode initialize_system(StudentSystem* system, DatabaseConnection* db_conn);
ErrorCode load_sample_data(StudentSystem* system, DatabaseConnection* db_conn);
ErrorCode process_user_commands(StudentSystem* system, DatabaseConnection* db_conn);
ErrorCode cleanup_system(StudentSystem* system, DatabaseConnection* db_conn);

void print_main_menu(void);
void print_system_status(const StudentSystem* system);
ErrorCode handle_add_student(StudentSystem* system, DatabaseConnection* db_conn);
ErrorCode handle_search_student(const StudentSystem* system);
ErrorCode handle_add_grade(StudentSystem* system);
ErrorCode handle_generate_report(const StudentSystem* system);

int main(void) {
    printf("=== Student Management System ===\n");
    printf("Version 1.0 - Academic Year 2024\n\n");
    
    StudentSystem system;
    DatabaseConnection db_conn;
    ErrorCode result;
    
    // システム初期化
    utils_log_message("INFO", "Starting Student Management System");
    
    result = initialize_system(&system, &db_conn);
    if (result != SUCCESS) {
        utils_log_error("main", result);
        printf("Failed to initialize system. Error: %s\n", 
               utils_error_code_to_string(result));
        return EXIT_FAILURE;
    }
    
    // サンプルデータの読み込み
    result = load_sample_data(&system, &db_conn);
    if (result != SUCCESS) {
        utils_log_error("main", result);
        printf("Warning: Could not load sample data. Error: %s\n",
               utils_error_code_to_string(result));
        // 致命的でないエラーなので続行
    }
    
    // システム状態を表示
    print_system_status(&system);
    
    // ユーザーコマンドの処理
    result = process_user_commands(&system, &db_conn);
    if (result != SUCCESS) {
        utils_log_error("main", result);
    }
    
    // システムクリーンアップ
    result = cleanup_system(&system, &db_conn);
    if (result != SUCCESS) {
        utils_log_error("main", result);
    }
    
    utils_log_message("INFO", "Student Management System terminated");
    printf("\nThank you for using Student Management System!\n");
    
    return (result == SUCCESS) ? EXIT_SUCCESS : EXIT_FAILURE;
}

ErrorCode initialize_system(StudentSystem* system, DatabaseConnection* db_conn) {
    if (system == NULL || db_conn == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    // 学生システムを初期化
    ErrorCode result = student_system_init(system, MAX_STUDENTS);
    if (result != SUCCESS) {
        return result;
    }
    
    // データベース接続を初期化
    result = database_init(db_conn, DATABASE_FILE, false);
    if (result != SUCCESS) {
        student_system_cleanup(system);
        return result;
    }
    
    utils_log_message("INFO", "System initialized successfully");
    return SUCCESS;
}

ErrorCode load_sample_data(StudentSystem* system, DatabaseConnection* db_conn) {
    if (system == NULL || db_conn == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    // 既存のデータベースから学生データを読み込み
    ErrorCode result = database_load_all_students(db_conn, system);
    if (result == SUCCESS && system->count > 0) {
        utils_log_message("INFO", "Existing student data loaded from database");
        return SUCCESS;
    }
    
    // サンプル学生データを作成
    Student sample_students[5];
    int sample_count = 5;
    
    // 学生データを初期化
    student_create(&sample_students[0], 12001, "Alice Johnson", 
                  "alice.johnson@university.edu", JUNIOR, COMPUTER_SCIENCE);
    student_create(&sample_students[1], 12002, "Bob Smith", 
                  "bob.smith@university.edu", SOPHOMORE, MATHEMATICS);
    student_create(&sample_students[2], 12003, "Carol Davis", 
                  "carol.davis@university.edu", SENIOR, PHYSICS);
    student_create(&sample_students[3], 12004, "David Wilson", 
                  "david.wilson@university.edu", FRESHMAN, CHEMISTRY);
    student_create(&sample_students[4], 12005, "Eve Brown", 
                  "eve.brown@university.edu", JUNIOR, BIOLOGY);
    
    // 各学生に成績を追加
    student_add_grade(&sample_students[0], "Data Structures", 88.5, 3);
    student_add_grade(&sample_students[0], "Algorithms", 92.0, 3);
    student_add_grade(&sample_students[0], "Database Systems", 85.5, 3);
    
    student_add_grade(&sample_students[1], "Calculus I", 78.5, 4);
    student_add_grade(&sample_students[1], "Linear Algebra", 82.0, 3);
    
    student_add_grade(&sample_students[2], "Quantum Physics", 91.5, 4);
    student_add_grade(&sample_students[2], "Thermodynamics", 87.0, 3);
    student_add_grade(&sample_students[2], "Modern Physics", 89.5, 3);
    
    student_add_grade(&sample_students[3], "General Chemistry", 75.5, 4);
    student_add_grade(&sample_students[3], "Organic Chemistry", 68.0, 4);
    
    student_add_grade(&sample_students[4], "Cell Biology", 86.5, 3);
    student_add_grade(&sample_students[4], "Genetics", 90.0, 3);
    
    // 学生をシステムに追加し、データベースに保存
    for (int i = 0; i < sample_count; i++) {
        result = student_add_to_system(system, &sample_students[i]);
        if (result != SUCCESS) {
            utils_log_error("load_sample_data", result);
            continue;
        }
        
        result = database_save_student(db_conn, &sample_students[i]);
        if (result != SUCCESS) {
            utils_log_error("load_sample_data", result);
        }
    }
    
    utils_log_message("INFO", "Sample data created and loaded");
    return SUCCESS;
}

void print_system_status(const StudentSystem* system) {
    if (system == NULL) {
        printf("Error: Cannot display system status - NULL pointer\n");
        return;
    }
    
    printf("\n=== System Status ===\n");
    printf("Total Students: %d/%d\n", system->count, system->capacity);
    
    if (system->count > 0) {
        // 簡単な統計を計算して表示
        double total_gpa = 0.0;
        int honor_roll_count = 0;
        
        for (int i = 0; i < system->count; i++) {
            total_gpa += system->students[i].gpa;
            if (system->students[i].gpa >= 3.5) {
                honor_roll_count++;
            }
        }
        
        double avg_gpa = total_gpa / system->count;
        printf("Average GPA: %.2f\n", avg_gpa);
        printf("Students on Honor Roll: %d\n", honor_roll_count);
    }
    
    printf("System Memory Usage: %.1f KB\n", 
           (double)(sizeof(Student) * system->capacity) / 1024.0);
    printf("===================\n\n");
}

ErrorCode process_user_commands(StudentSystem* system, DatabaseConnection* db_conn) {
    if (system == NULL || db_conn == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    int choice;
    ErrorCode result = SUCCESS;
    char input_buffer[256];
    
    while (1) {
        print_main_menu();
        
        printf("Enter your choice (1-6): ");
        if (fgets(input_buffer, sizeof(input_buffer), stdin) == NULL) {
            break;
        }
        
        if (utils_string_to_int(utils_trim_whitespace(input_buffer), &choice) != 0) {
            printf("Invalid input. Please enter a number.\n\n");
            continue;
        }
        
        switch (choice) {
            case 1:
                result = handle_add_student(system, db_conn);
                break;
            case 2:
                result = handle_search_student(system);
                break;
            case 3:
                result = handle_add_grade(system);
                break;
            case 4:
                result = handle_generate_report(system);
                break;
            case 5:
                print_system_status(system);
                break;
            case 6:
                printf("Exiting system...\n");
                return SUCCESS;
            default:
                printf("Invalid choice. Please select 1-6.\n\n");
                continue;
        }
        
        if (result != SUCCESS) {
            printf("Operation failed: %s\n\n", utils_error_code_to_string(result));
        }
    }
    
    return SUCCESS;
}

void print_main_menu(void) {
    printf("=== Main Menu ===\n");
    printf("1. Add New Student\n");
    printf("2. Search Student\n");
    printf("3. Add Grade\n");
    printf("4. Generate Report\n");
    printf("5. System Status\n");
    printf("6. Exit\n");
    printf("================\n");
}

ErrorCode handle_add_student(StudentSystem* system, DatabaseConnection* db_conn) {
    if (system == NULL || db_conn == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    printf("\n=== Add New Student ===\n");
    
    char name[MAX_NAME_LENGTH];
    char email[MAX_EMAIL_LENGTH];
    char input_buffer[256];
    int id, year_int, major_int;
    
    // 学生情報を入力
    printf("Student ID: ");
    if (fgets(input_buffer, sizeof(input_buffer), stdin) == NULL ||
        utils_string_to_int(utils_trim_whitespace(input_buffer), &id) != 0) {
        printf("Invalid ID format.\n");
        return ERROR_INVALID_ID;
    }
    
    printf("Name: ");
    if (fgets(input_buffer, sizeof(input_buffer), stdin) == NULL) {
        return ERROR_NULL_POINTER;
    }
    utils_safe_strcpy(name, utils_trim_whitespace(input_buffer), sizeof(name));
    
    printf("Email: ");
    if (fgets(input_buffer, sizeof(input_buffer), stdin) == NULL) {
        return ERROR_NULL_POINTER;
    }
    utils_safe_strcpy(email, utils_trim_whitespace(input_buffer), sizeof(email));
    
    printf("Year (1=Freshman, 2=Sophomore, 3=Junior, 4=Senior): ");
    if (fgets(input_buffer, sizeof(input_buffer), stdin) == NULL ||
        utils_string_to_int(utils_trim_whitespace(input_buffer), &year_int) != 0) {
        printf("Invalid year format.\n");
        return ERROR_INVALID_ID;
    }
    
    printf("Major (0=CS, 1=Math, 2=Physics, 3=Chemistry, 4=Biology): ");
    if (fgets(input_buffer, sizeof(input_buffer), stdin) == NULL ||
        utils_string_to_int(utils_trim_whitespace(input_buffer), &major_int) != 0) {
        printf("Invalid major format.\n");
        return ERROR_INVALID_ID;
    }
    
    // 学生を作成
    Student new_student;
    ErrorCode result = student_create(&new_student, id, name, email, 
                                    (Year)year_int, (Major)major_int);
    if (result != SUCCESS) {
        return result;
    }
    
    // システム に追加
    result = student_add_to_system(system, &new_student);
    if (result != SUCCESS) {
        return result;
    }
    
    // データベースに保存
    result = database_save_student(db_conn, &new_student);
    if (result != SUCCESS) {
        return result;
    }
    
    printf("Student added successfully!\n\n");
    return SUCCESS;
}

ErrorCode handle_search_student(const StudentSystem* system) {
    if (system == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    printf("\n=== Search Student ===\n");
    
    char input_buffer[256];
    int search_id;
    
    printf("Enter Student ID: ");
    if (fgets(input_buffer, sizeof(input_buffer), stdin) == NULL ||
        utils_string_to_int(utils_trim_whitespace(input_buffer), &search_id) != 0) {
        printf("Invalid ID format.\n");
        return ERROR_INVALID_ID;
    }
    
    Student* found_student = student_find_by_id(system, search_id);
    if (found_student == NULL) {
        printf("Student with ID %d not found.\n\n", search_id);
        return ERROR_STUDENT_NOT_FOUND;
    }
    
    // 学生情報を表示
    student_print_info(found_student);
    student_print_grades(found_student);
    printf("\n");
    
    return SUCCESS;
}

ErrorCode handle_generate_report(const StudentSystem* system) {
    if (system == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    printf("\n=== Generate Report ===\n");
    
    char filename[MAX_FILENAME_LENGTH];
    char timestamp[32];
    
    time_t now = utils_get_current_time();
    struct tm* time_info = localtime(&now);
    strftime(timestamp, sizeof(timestamp), "%Y%m%d_%H%M%S", time_info);
    
    snprintf(filename, sizeof(filename), "student_report_%s.txt", timestamp);
    
    ErrorCode result = report_generate_summary(system, filename);
    if (result != SUCCESS) {
        return result;
    }
    
    printf("Report generated successfully: %s\n\n", filename);
    return SUCCESS;
}

ErrorCode cleanup_system(StudentSystem* system, DatabaseConnection* db_conn) {
    if (system == NULL || db_conn == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    // データベース接続を閉じる
    database_close(db_conn);
    
    // 学生システムをクリーンアップ
    student_system_cleanup(system);
    
    utils_log_message("INFO", "System cleanup completed");
    return SUCCESS;
}