#include "database.h"
#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

ErrorCode database_init(DatabaseConnection* conn, const char* filename, bool readonly) {
    if (conn == NULL || filename == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    // 接続情報を初期化
    memset(conn, 0, sizeof(DatabaseConnection));
    
    ErrorCode result = utils_safe_strcpy(conn->filename, filename, sizeof(conn->filename));
    if (result != SUCCESS) {
        return result;
    }
    
    conn->is_readonly = readonly;
    conn->is_open = false;
    conn->record_count = 0;
    
    // ファイルが存在しない場合は作成
    if (!utils_file_exists(filename)) {
        if (readonly) {
            utils_log_error("database_init", ERROR_FILE_NOT_FOUND);
            return ERROR_FILE_NOT_FOUND;
        }
        
        result = database_create_file_if_not_exists(filename);
        if (result != SUCCESS) {
            return result;
        }
    }
    
    // ファイルを開く
    const char* mode = readonly ? "r" : "r+";
    conn->file_handle = fopen(filename, mode);
    
    if (conn->file_handle == NULL) {
        utils_log_error("database_init", ERROR_FILE_NOT_FOUND);
        return ERROR_FILE_NOT_FOUND;
    }
    
    conn->is_open = true;
    
    // ファイルフォーマットを検証
    result = database_validate_file_format(conn);
    if (result != SUCCESS) {
        database_close(conn);
        return result;
    }
    
    database_log_operation("database_init", SUCCESS);
    return SUCCESS;
}

ErrorCode database_close(DatabaseConnection* conn) {
    if (conn == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    if (conn->is_open && conn->file_handle != NULL) {
        fclose(conn->file_handle);
        conn->file_handle = NULL;
        conn->is_open = false;
    }
    
    database_log_operation("database_close", SUCCESS);
    return SUCCESS;
}

ErrorCode database_create_file_if_not_exists(const char* filename) {
    if (filename == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    FILE* file = fopen(filename, "w");
    if (file == NULL) {
        utils_log_error("database_create_file_if_not_exists", ERROR_FILE_NOT_FOUND);
        return ERROR_FILE_NOT_FOUND;
    }
    
    // CSVヘッダーを書き込み
    const char* header = "id,name,email,year,major,enrollment_date,gpa,total_credits\n";
    if (fprintf(file, "%s", header) < 0) {
        fclose(file);
        return ERROR_FILE_NOT_FOUND;
    }
    
    fclose(file);
    return SUCCESS;
}

ErrorCode database_save_student(DatabaseConnection* conn, const Student* student) {
    if (conn == NULL || student == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    if (!database_is_connection_valid(conn)) {
        return ERROR_FILE_NOT_FOUND;
    }
    
    if (conn->is_readonly) {
        return ERROR_FILE_NOT_FOUND; // 読み取り専用モードでは書き込み不可
    }
    
    // ファイルの末尾に移動
    if (fseek(conn->file_handle, 0, SEEK_END) != 0) {
        return database_handle_file_error(conn, "seek_end");
    }
    
    ErrorCode result = database_write_student_csv(conn->file_handle, student);
    if (result == SUCCESS) {
        conn->record_count++;
        fflush(conn->file_handle);
    }
    
    database_log_operation("database_save_student", result);
    return result;
}

ErrorCode database_write_student_csv(FILE* file, const Student* student) {
    if (file == NULL || student == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    char time_buffer[64];
    utils_format_time(student->enrollment_date, time_buffer, sizeof(time_buffer));
    
    int written = fprintf(file, "%d,%s,%s,%d,%d,%s,%.2f,%d\n",
                         student->id,
                         student->name,
                         student->email,
                         student->year,
                         student->major,
                         time_buffer,
                         student->gpa,
                         student->total_credits);
    
    if (written < 0) {
        return ERROR_FILE_NOT_FOUND;
    }
    
    return SUCCESS;
}

ErrorCode database_load_all_students(DatabaseConnection* conn, StudentSystem* system) {
    if (conn == NULL || system == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    if (!database_is_connection_valid(conn)) {
        return ERROR_FILE_NOT_FOUND;
    }
    
    // ファイルの開始位置に移動（ヘッダーをスキップ）
    rewind(conn->file_handle);
    
    char line[512];
    if (fgets(line, sizeof(line), conn->file_handle) == NULL) {
        return ERROR_FILE_NOT_FOUND; // ヘッダー行がない
    }
    
    int loaded_count = 0;
    Student temp_student;
    
    while (fgets(line, sizeof(line), conn->file_handle) != NULL && 
           loaded_count < system->capacity) {
        
        ErrorCode result = database_parse_csv_line(line, &temp_student);
        if (result == SUCCESS) {
            result = student_add_to_system(system, &temp_student);
            if (result == SUCCESS) {
                loaded_count++;
            } else {
                utils_log_error("database_load_all_students", result);
            }
        }
    }
    
    conn->record_count = loaded_count;
    database_log_operation("database_load_all_students", SUCCESS);
    
    return SUCCESS;
}

ErrorCode database_parse_csv_line(const char* line, Student* student) {
    if (line == NULL || student == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    // 学生構造体を初期化
    memset(student, 0, sizeof(Student));
    
    char line_copy[512];
    utils_safe_strcpy(line_copy, line, sizeof(line_copy));
    
    char* token = strtok(line_copy, ",");
    int field_index = 0;
    
    while (token != NULL && field_index < 8) {
        utils_trim_whitespace(token);
        
        switch (field_index) {
            case 0: // ID
                student->id = atoi(token);
                break;
            case 1: // Name
                utils_safe_strcpy(student->name, token, sizeof(student->name));
                break;
            case 2: // Email
                utils_safe_strcpy(student->email, token, sizeof(student->email));
                break;
            case 3: // Year
                student->year = (Year)atoi(token);
                break;
            case 4: // Major  
                student->major = (Major)atoi(token);
                break;
            case 5: // Enrollment date (文字列として処理)
                // 実際の実装では時間パースが必要
                student->enrollment_date = utils_get_current_time();
                break;
            case 6: // GPA
                student->gpa = atof(token);
                break;
            case 7: // Total credits
                student->total_credits = atoi(token);
                break;
        }
        
        token = strtok(NULL, ",");
        field_index++;
    }
    
    if (field_index < 8) {
        return ERROR_INVALID_ID; // 不完全なデータ
    }
    
    return SUCCESS;
}

bool database_is_connection_valid(const DatabaseConnection* conn) {
    return (conn != NULL && conn->is_open && conn->file_handle != NULL);
}

ErrorCode database_validate_file_format(const DatabaseConnection* conn) {
    if (!database_is_connection_valid(conn)) {
        return ERROR_NULL_POINTER;
    }
    
    rewind(conn->file_handle);
    
    char header[256];
    if (fgets(header, sizeof(header), conn->file_handle) == NULL) {
        return ERROR_FILE_NOT_FOUND;
    }
    
    // 簡単なヘッダー検証
    if (strstr(header, "id") == NULL || strstr(header, "name") == NULL) {
        return ERROR_FILE_NOT_FOUND;
    }
    
    return SUCCESS;
}

ErrorCode database_handle_file_error(DatabaseConnection* conn, const char* operation) {
    if (conn != NULL) {
        snprintf(conn->error_message, sizeof(conn->error_message),
                "File operation failed: %s", operation ? operation : "unknown");
    }
    
    return ERROR_FILE_NOT_FOUND;
}

void database_log_operation(const char* operation, ErrorCode result) {
    char log_message[256];
    snprintf(log_message, sizeof(log_message),
             "Database operation '%s' completed with status: %s",
             operation ? operation : "unknown",
             utils_error_code_to_string(result));
    
    if (result == SUCCESS) {
        utils_log_message("INFO", log_message);
    } else {
        utils_log_message("ERROR", log_message);
    }
}