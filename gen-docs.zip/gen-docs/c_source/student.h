#ifndef STUDENT_H
#define STUDENT_H

#include "config.h"
#include <time.h>

// 成績情報構造体
typedef struct {
    char course_name[MAX_NAME_LENGTH];
    double grade;
    int credits;
    time_t completion_date;
} Grade;

// 学生情報構造体
typedef struct {
    int id;
    char name[MAX_NAME_LENGTH];
    char email[MAX_EMAIL_LENGTH];
    Year year;
    Major major;
    Grade grades[MAX_COURSES_PER_STUDENT];
    int grade_count;
    time_t enrollment_date;
    double gpa;
    int total_credits;
} Student;

// 学生管理システム構造体
typedef struct {
    Student* students;
    int count;
    int capacity;
} StudentSystem;

// 学生管理関数の宣言
ErrorCode student_system_init(StudentSystem* system, int capacity);
void student_system_cleanup(StudentSystem* system);

ErrorCode student_create(Student* student, int id, const char* name, 
                        const char* email, Year year, Major major);
ErrorCode student_add_to_system(StudentSystem* system, const Student* student);
Student* student_find_by_id(const StudentSystem* system, int id);
Student* student_find_by_name(const StudentSystem* system, const char* name);
ErrorCode student_remove_by_id(StudentSystem* system, int id);

ErrorCode student_add_grade(Student* student, const char* course_name, 
                           double grade, int credits);
ErrorCode student_calculate_gpa(Student* student);
ErrorCode student_update_total_credits(Student* student);

int student_compare_by_gpa(const void* a, const void* b);
int student_compare_by_name(const void* a, const void* b);
int student_compare_by_id(const void* a, const void* b);

ErrorCode student_validate_id(int id);
ErrorCode student_validate_grade(double grade);
ErrorCode student_validate_name(const char* name);
ErrorCode student_validate_email(const char* email);

// 学生情報表示関数
void student_print_info(const Student* student);
void student_print_grades(const Student* student);
void student_print_summary(const Student* student);

#endif // STUDENT_H