# 最小構成テストファイル

c-analyzerの全機能を最小限のコードでテストするファイルセットです。

## ファイル構成（4ファイル、総23行）

- **math.h** - `add`関数の宣言（5行）
- **math.c** - `add`関数の実装（4行）
- **main.c** - 正常なinclude関係（7行）
- **invalid.c** - include漏れテスト用（7行）

## テストできる機能

### ✅ 1. 関数抽出
```bash
./target/release/c-analyzer test_files/
```
- `add`関数（宣言と実装）
- `main`関数（2つ）

### ✅ 2. 関数呼び出し検出
- main → add の呼び出し関係

### ✅ 3. 別ファイル関数呼び出し
- main.c → math.c のadd関数

### ✅ 4. include可視性チェック
```bash
./target/release/c-analyzer -c test_files/
```
- main.c: 警告なし（正常）
- invalid.c: 警告あり（include漏れ）

### ✅ 5. called_by関係構築
- add関数が2つのmainから呼ばれることを検出

## 期待される結果

- **関数数**: 4個（add宣言, add実装, main×2）
- **警告**: invalid.cで1件
- **呼び出し関係**: main → add

最小限のコードでc-analyzerの全ての主要機能を確認できます。