#ifndef CONFIG_H
#define CONFIG_H

// システム設定定数
#define MAX_STUDENTS 1000
#define MAX_NAME_LENGTH 50
#define MAX_EMAIL_LENGTH 100
#define MAX_COURSES_PER_STUDENT 10
#define MAX_FILENAME_LENGTH 256
#define DATABASE_FILE "students.csv"
#define REPORT_FILE "report.txt"

// 成績関連の定数
#define MIN_GRADE 0.0
#define MAX_GRADE 100.0
#define PASSING_GRADE 60.0

// エラーコード
typedef enum {
    SUCCESS = 0,
    ERROR_NULL_POINTER = -1,
    ERROR_INVALID_ID = -2,
    ERROR_STUDENT_NOT_FOUND = -3,
    ERROR_DUPLICATE_ID = -4,
    ERROR_FILE_NOT_FOUND = -5,
    ERROR_MEMORY_ALLOCATION = -6,
    ERROR_INVALID_GRADE = -7,
    ERROR_MAX_STUDENTS_REACHED = -8
} ErrorCode;

// 学年定義
typedef enum {
    FRESHMAN = 1,
    SOPHOMORE = 2,
    JUNIOR = 3,
    SENIOR = 4
} Year;

// 専攻定義
typedef enum {
    COMPUTER_SCIENCE,
    MATHEMATICS,
    PHYSICS,
    CHEMISTRY,
    BIOLOGY,
    UNKNOWN_MAJOR
} Major;

#endif // CONFIG_H