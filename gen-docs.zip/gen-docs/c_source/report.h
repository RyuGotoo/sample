#ifndef REPORT_H
#define REPORT_H

#include "config.h"
#include "student.h"
#include "database.h"

// レポートの種類
typedef enum {
    REPORT_SUMMARY,
    REPORT_DETAILED,
    REPORT_GPA_RANKING,
    REPORT_MAJOR_DISTRIBUTION,
    REPORT_ACADEMIC_STANDING
} ReportType;

// レポート統計情報
typedef struct {
    int total_students;
    double average_gpa;
    double highest_gpa;
    double lowest_gpa;
    int students_on_honor_roll;
    int students_on_probation;
    double completion_rate;
} ReportStatistics;

// 専攻別統計
typedef struct {
    Major major;
    int student_count;
    double average_gpa;
    int total_credits;
    char major_name[MAX_NAME_LENGTH];
} MajorStatistics;

// レポート生成の主要関数
ErrorCode report_generate_summary(const StudentSystem* system, const char* output_file);
ErrorCode report_generate_detailed(const StudentSystem* system, const char* output_file);
ErrorCode report_generate_gpa_ranking(const StudentSystem* system, const char* output_file);
ErrorCode report_generate_major_distribution(const StudentSystem* system, const char* output_file);

// 統計計算関数
ErrorCode report_calculate_statistics(const StudentSystem* system, ReportStatistics* stats);
ErrorCode report_calculate_major_statistics(const StudentSystem* system, 
                                          MajorStatistics major_stats[], int* major_count);
ErrorCode report_calculate_gpa_distribution(const StudentSystem* system, 
                                          double gpa_ranges[], int range_count, 
                                          int distribution[]);

// データ分析関数
ErrorCode report_find_top_students(const StudentSystem* system, int count, 
                                  Student** top_students);
ErrorCode report_find_students_by_academic_standing(const StudentSystem* system, 
                                                   double min_gpa, double max_gpa,
                                                   Student** results, int* result_count);
ErrorCode report_analyze_credit_completion(const StudentSystem* system, 
                                         double* completion_rate, 
                                         int* students_behind);

// レポート出力ヘルパー関数
ErrorCode report_write_header(FILE* file, const char* title, const char* description);
ErrorCode report_write_footer(FILE* file, const ReportStatistics* stats);
ErrorCode report_write_student_table(FILE* file, const Student* students, int count);
ErrorCode report_write_statistics_section(FILE* file, const ReportStatistics* stats);

// フォーマット関数
ErrorCode report_format_student_line(const Student* student, char* buffer, size_t buffer_size);
ErrorCode report_format_major_name(Major major, char* buffer, size_t buffer_size);
ErrorCode report_format_academic_standing(double gpa, char* buffer, size_t buffer_size);
ErrorCode report_format_percentage(double value, char* buffer, size_t buffer_size);

// レポート検証・品質チェック
ErrorCode report_validate_output_file(const char* filename);
ErrorCode report_verify_data_integrity(const StudentSystem* system, 
                                     const ReportStatistics* stats);
bool report_is_system_ready_for_reporting(const StudentSystem* system);

// レポート履歴・メタデータ
ErrorCode report_save_generation_metadata(const char* report_file, ReportType type, 
                                         const ReportStatistics* stats);
ErrorCode report_create_index_file(const char* directory);

#endif // REPORT_H