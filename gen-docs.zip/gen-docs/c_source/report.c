#include "report.h"
#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

ErrorCode report_generate_summary(const StudentSystem* system, const char* output_file) {
    if (system == NULL || output_file == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    if (!report_is_system_ready_for_reporting(system)) {
        return ERROR_INVALID_ID;
    }
    
    FILE* file = fopen(output_file, "w");
    if (file == NULL) {
        utils_log_error("report_generate_summary", ERROR_FILE_NOT_FOUND);
        return ERROR_FILE_NOT_FOUND;
    }
    
    // レポートヘッダーを書き込み
    ErrorCode result = report_write_header(file, "Student Summary Report", 
                                         "Overview of all students in the system");
    if (result != SUCCESS) {
        fclose(file);
        return result;
    }
    
    // 統計情報を計算
    ReportStatistics stats;
    result = report_calculate_statistics(system, &stats);
    if (result != SUCCESS) {
        fclose(file);
        return result;
    }
    
    // 統計セクションを書き込み
    result = report_write_statistics_section(file, &stats);
    if (result != SUCCESS) {
        fclose(file);
        return result;
    }
    
    // 学生一覧テーブルを書き込み
    result = report_write_student_table(file, system->students, system->count);
    if (result != SUCCESS) {
        fclose(file);
        return result;
    }
    
    // レポートフッターを書き込み
    result = report_write_footer(file, &stats);
    if (result != SUCCESS) {
        fclose(file);
        return result;
    }
    
    fclose(file);
    
    // メタデータを保存
    report_save_generation_metadata(output_file, REPORT_SUMMARY, &stats);
    
    utils_log_message("INFO", "Summary report generated successfully");
    return SUCCESS;
}

ErrorCode report_calculate_statistics(const StudentSystem* system, ReportStatistics* stats) {
    if (system == NULL || stats == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    memset(stats, 0, sizeof(ReportStatistics));
    
    if (system->count == 0) {
        return SUCCESS;
    }
    
    stats->total_students = system->count;
    stats->highest_gpa = 0.0;
    stats->lowest_gpa = 4.0;
    
    double total_gpa = 0.0;
    int total_completed_credits = 0;
    int expected_credits = system->count * 120; // 卒業に必要な単位数と仮定
    
    // 各学生のデータを分析
    for (int i = 0; i < system->count; i++) {
        const Student* student = &system->students[i];
        
        total_gpa += student->gpa;
        total_completed_credits += student->total_credits;
        
        // 最高・最低GPAを更新
        if (student->gpa > stats->highest_gpa) {
            stats->highest_gpa = student->gpa;
        }
        if (student->gpa < stats->lowest_gpa) {
            stats->lowest_gpa = student->gpa;
        }
        
        // 学術的地位を判定
        if (student->gpa >= 3.5) {
            stats->students_on_honor_roll++;
        } else if (student->gpa < 2.0) {
            stats->students_on_probation++;
        }
    }
    
    // 平均値を計算
    stats->average_gpa = utils_round_to_decimal_places(
        total_gpa / system->count, 2);
    
    // 完了率を計算
    if (expected_credits > 0) {
        stats->completion_rate = utils_round_to_decimal_places(
            (double)total_completed_credits / expected_credits * 100.0, 1);
    }
    
    return SUCCESS;
}

ErrorCode report_find_top_students(const StudentSystem* system, int count, 
                                  Student** top_students) {
    if (system == NULL || top_students == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    if (count <= 0 || count > system->count) {
        return ERROR_INVALID_ID;
    }
    
    // 学生データをコピーしてソート
    Student* sorted_students = (Student*)utils_safe_malloc(
        sizeof(Student) * system->count);
    if (sorted_students == NULL) {
        return ERROR_MEMORY_ALLOCATION;
    }
    
    memcpy(sorted_students, system->students, 
           sizeof(Student) * system->count);
    
    // GPAで降順ソート
    qsort(sorted_students, system->count, sizeof(Student), 
          student_compare_by_gpa);
    
    // 上位学生のポインタを設定
    for (int i = 0; i < count; i++) {
        top_students[i] = &sorted_students[i];
    }
    
    return SUCCESS;
}

ErrorCode report_write_header(FILE* file, const char* title, const char* description) {
    if (file == NULL || title == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    char time_buffer[64];
    time_t now = utils_get_current_time();
    utils_format_time(now, time_buffer, sizeof(time_buffer));
    
    fprintf(file, "=====================================\n");
    fprintf(file, "%s\n", title);
    fprintf(file, "=====================================\n");
    
    if (description != NULL) {
        fprintf(file, "Description: %s\n", description);
    }
    
    fprintf(file, "Generated on: %s\n", time_buffer);
    fprintf(file, "=====================================\n\n");
    
    return SUCCESS;
}

ErrorCode report_write_statistics_section(FILE* file, const ReportStatistics* stats) {
    if (file == NULL || stats == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    fprintf(file, "SYSTEM STATISTICS\n");
    fprintf(file, "-----------------\n");
    fprintf(file, "Total Students: %d\n", stats->total_students);
    fprintf(file, "Average GPA: %.2f\n", stats->average_gpa);
    fprintf(file, "Highest GPA: %.2f\n", stats->highest_gpa);
    fprintf(file, "Lowest GPA: %.2f\n", stats->lowest_gpa);
    fprintf(file, "Students on Honor Roll (GPA >= 3.5): %d\n", stats->students_on_honor_roll);
    fprintf(file, "Students on Academic Probation (GPA < 2.0): %d\n", stats->students_on_probation);
    fprintf(file, "Credit Completion Rate: %.1f%%\n", stats->completion_rate);
    fprintf(file, "\n");
    
    return SUCCESS;
}

ErrorCode report_write_student_table(FILE* file, const Student* students, int count) {
    if (file == NULL || students == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    if (count == 0) {
        fprintf(file, "No students to display.\n\n");
        return SUCCESS;
    }
    
    fprintf(file, "STUDENT LISTING\n");
    fprintf(file, "---------------\n");
    fprintf(file, "%-6s %-25s %-30s %-4s %-15s %-5s %-8s\n",
            "ID", "Name", "Email", "Year", "Major", "GPA", "Credits");
    fprintf(file, "%-6s %-25s %-30s %-4s %-15s %-5s %-8s\n",
            "------", "-------------------------", 
            "------------------------------", "----", 
            "---------------", "-----", "--------");
    
    for (int i = 0; i < count; i++) {
        const Student* student = &students[i];
        
        char major_name[MAX_NAME_LENGTH];
        report_format_major_name(student->major, major_name, sizeof(major_name));
        
        fprintf(file, "%-6d %-25s %-30s %-4d %-15s %5.2f %8d\n",
                student->id,
                student->name,
                student->email,
                student->year,
                major_name,
                student->gpa,
                student->total_credits);
    }
    
    fprintf(file, "\n");
    return SUCCESS;
}

ErrorCode report_format_major_name(Major major, char* buffer, size_t buffer_size) {
    if (buffer == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    const char* major_names[] = {
        "Computer Science",
        "Mathematics", 
        "Physics",
        "Chemistry",
        "Biology",
        "Unknown"
    };
    
    int index = (major >= 0 && major < UNKNOWN_MAJOR) ? major : UNKNOWN_MAJOR;
    utils_safe_strcpy(buffer, major_names[index], buffer_size);
    
    return SUCCESS;
}

ErrorCode report_write_footer(FILE* file, const ReportStatistics* stats) {
    if (file == NULL || stats == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    fprintf(file, "=====================================\n");
    fprintf(file, "Report Summary:\n");
    fprintf(file, "- %d total students processed\n", stats->total_students);
    fprintf(file, "- System average GPA: %.2f\n", stats->average_gpa);
    
    if (stats->students_on_honor_roll > 0) {
        double honor_percentage = utils_calculate_percentage(
            stats->students_on_honor_roll, stats->total_students);
        fprintf(file, "- %.1f%% of students on honor roll\n", honor_percentage);
    }
    
    if (stats->students_on_probation > 0) {
        double probation_percentage = utils_calculate_percentage(
            stats->students_on_probation, stats->total_students);
        fprintf(file, "- %.1f%% of students on academic probation\n", probation_percentage);
    }
    
    fprintf(file, "=====================================\n");
    
    return SUCCESS;
}

bool report_is_system_ready_for_reporting(const StudentSystem* system) {
    if (system == NULL) {
        return false;
    }
    
    if (system->students == NULL || system->count == 0) {
        return false;
    }
    
    // 基本的なデータ整合性をチェック
    for (int i = 0; i < system->count; i++) {
        const Student* student = &system->students[i];
        
        if (student->id <= 0) {
            return false;
        }
        
        if (utils_is_empty_string(student->name)) {
            return false;
        }
        
        if (student->gpa < 0.0 || student->gpa > 4.0) {
            return false;
        }
    }
    
    return true;
}

ErrorCode report_save_generation_metadata(const char* report_file, ReportType type, 
                                         const ReportStatistics* stats) {
    if (report_file == NULL || stats == NULL) {
        return ERROR_NULL_POINTER;
    }
    
    char metadata_file[MAX_FILENAME_LENGTH];
    snprintf(metadata_file, sizeof(metadata_file), "%s.meta", report_file);
    
    FILE* file = fopen(metadata_file, "w");
    if (file == NULL) {
        return ERROR_FILE_NOT_FOUND;
    }
    
    time_t now = utils_get_current_time();
    char time_buffer[64];
    utils_format_time(now, time_buffer, sizeof(time_buffer));
    
    fprintf(file, "report_type=%d\n", type);
    fprintf(file, "generation_time=%s\n", time_buffer);
    fprintf(file, "total_students=%d\n", stats->total_students);
    fprintf(file, "average_gpa=%.2f\n", stats->average_gpa);
    fprintf(file, "completion_rate=%.1f\n", stats->completion_rate);
    
    fclose(file);
    
    utils_log_message("INFO", "Report metadata saved");
    return SUCCESS;
}