from doc_generator import process_all_functions, load_calls_json, generate_function_documentation
import os
from pathlib import Path


def find_latest_timestamp_dir(base_dir: str = "..") -> tuple[Path, Path]:
    """最新のタイムスタンプディレクトリを見つける
    
    Returns:
        tuple[Path, Path]: (docs_dir, prompts_dir)
    """
    base_path = Path(base_dir)
    docs_dirs = list(base_path.glob("docs_*"))
    
    if not docs_dirs:
        raise FileNotFoundError("タイムスタンプ付きのdocsディレクトリが見つかりません")
    
    # 最新のディレクトリを選択（名前順でソート）
    latest_dir = sorted(docs_dirs)[-1]
    docs_dir = latest_dir / "docs"
    prompts_dir = latest_dir / "prompts"
    
    print(f"最新のタイムスタンプディレクトリを使用: {latest_dir}")
    
    return docs_dir, prompts_dir


def continue_doc_generation(source_dir: str = "c_source/"):
    """中断された生成処理を継続する"""
    calls_data = load_calls_json("./calls.json")
    
    try:
        docs_dir, prompts_dir = find_latest_timestamp_dir()
    except FileNotFoundError as e:
        print(f"エラー: {e}")
        print("新しい生成を開始するには process_all_functions() を使用してください。")
        return

    # 既に生成済みのファイルを確認
    existing_files = []
    if docs_dir.exists():
        existing_files = [f.stem for f in docs_dir.glob("*.xml")]

    print(f"既存ファイル: {existing_files}")

    # 未生成の関数を特定
    remaining_functions = []
    for func_id in calls_data["processing_order"]:
        func_info = calls_data["functions"][func_id]
        expected_filename = f"{func_info['name']}_{func_id}"

        if expected_filename not in existing_files:
            remaining_functions.append(func_id)

    print(f"残り {len(remaining_functions)} 個の関数を生成します:")
    for func_id in remaining_functions:
        func_info = calls_data["functions"][func_id]
        print(f"  - {func_info['name']} ({func_id})")

    if not remaining_functions:
        print("すべての関数ドキュメントが既に生成済みです。")
        return

    # プロンプトテンプレートを読み込み
    sys_prompt_template = Path("../prompts/sys_prompt.md").read_text(encoding="utf-8")
    user_prompt_template = Path("../prompts/user_prompt.md").read_text(encoding="utf-8")

    # 既に生成済みのドキュメントを読み込み
    generated_docs = {}
    for xml_file in docs_dir.glob("*.xml"):
        func_id = xml_file.stem.split("_")[-1]  # func_idを抽出
        generated_docs[func_id] = xml_file.read_text(encoding="utf-8")

    for func_id in remaining_functions:
        func_info = calls_data["functions"][func_id]

        print(f"関数 {func_info['name']} ({func_id}) のドキュメントを生成中...")

        # ドキュメント生成（プロンプトも保存）
        documentation = generate_function_documentation(
            func_info, sys_prompt_template, user_prompt_template, generated_docs, prompts_dir, source_dir
        )

        # 生成済みドキュメントに保存
        generated_docs[func_id] = documentation

        # ドキュメントファイルに保存
        output_file = docs_dir / f"{func_info['name']}_{func_id}.xml"
        output_file.write_text(documentation, encoding="utf-8")

        print(f"  → ドキュメント: {output_file} に保存完了")


if __name__ == "__main__":
    continue_doc_generation()
