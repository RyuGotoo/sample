import json
from typing import Dict, List, Set
from pathlib import Path


def load_functions_from_json(json_path: str) -> List[Dict]:
    """out.jsonから関数情報を読み込む"""
    with open(json_path, "r", encoding="utf-8") as f:
        return json.load(f)


def build_dependency_graph(functions: List[Dict]) -> Dict[str, Dict]:
    """関数情報から依存グラフを構築する

    Returns:
        Dict[str, Dict]: {
            "functions": {func_id: func_info},
            "dependencies": {func_id: [called_func_ids]},
            "reverse_dependencies": {func_id: [caller_func_ids]}
        }
    """
    functions_map = {}
    dependencies = {}
    reverse_dependencies = {}

    # 関数IDでマップを作成
    for func in functions:
        func_id = func["id"]
        functions_map[func_id] = func
        dependencies[func_id] = []
        reverse_dependencies[func_id] = []

    # 依存関係を構築
    for func in functions:
        func_id = func["id"]
        for called_func in func.get("calls", []):
            # called_funcがIDの場合とexternal関数の場合を区別
            if called_func.startswith("func_"):
                # 内部関数への依存
                if called_func in functions_map:
                    dependencies[func_id].append(called_func)
                    reverse_dependencies[called_func].append(func_id)

    return {
        "functions": functions_map,
        "dependencies": dependencies,
        "reverse_dependencies": reverse_dependencies,
    }


def topological_sort(dependencies: Dict[str, List[str]]) -> List[str]:
    """トポロジカルソートで依存順序を決定する

    Returns:
        List[str]: 依存の浅い順に並んだ関数IDのリスト
    """
    # 入次数を計算
    in_degree = {func_id: 0 for func_id in dependencies.keys()}
    for func_id, deps in dependencies.items():
        for dep in deps:
            if dep in in_degree:
                in_degree[dep] += 1

    # 入次数0の関数をキューに追加
    queue = [func_id for func_id, degree in in_degree.items() if degree == 0]
    result = []

    while queue:
        current = queue.pop(0)
        result.append(current)

        # 現在の関数に依存する関数の入次数を減らす
        for func_id, deps in dependencies.items():
            if current in deps:
                in_degree[func_id] -= 1
                if in_degree[func_id] == 0:
                    queue.append(func_id)

    return result


def create_calls_json(json_path: str, output_path: str = "calls.json"):
    """out.jsonから依存関係を解析してcalls.jsonを作成する"""

    # 関数情報を読み込み
    functions = load_functions_from_json(json_path)

    # 依存グラフを構築
    graph = build_dependency_graph(functions)

    # トポロジカルソートで順序決定
    sorted_order = topological_sort(graph["dependencies"])

    # 結果データを構築
    result = {
        "functions": graph["functions"],
        "dependencies": graph["dependencies"],
        "reverse_dependencies": graph["reverse_dependencies"],
        "processing_order": sorted_order,
    }

    # JSONに出力
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print(f"依存関係グラフを {output_path} に保存しました")
    print(f"処理順序: {sorted_order}")

    return result


if __name__ == "__main__":
    create_calls_json("../out.json")
