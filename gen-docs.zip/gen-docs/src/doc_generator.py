import json
from pathlib import Path
from typing import Dict, List
from datetime import datetime
from llm import chat_completion


def load_calls_json(calls_json_path: str) -> Dict:
    """calls.jsonから依存関係データを読み込む"""
    with open(calls_json_path, "r", encoding="utf-8") as f:
        return json.load(f)


def read_c_source(
    file_path: str, line_start: int, line_end: int, source_dir: str = "c_source/"
) -> str:
    """指定されたファイルの指定行範囲を読み込む

    Args:
        file_path: out.jsonで記録されたファイルパス
        line_start: 開始行番号（1ベース）
        line_end: 終了行番号（1ベース）
        source_dir: 実際のソースファイルが格納されているディレクトリ
    """
    try:
        # out.jsonのパス形式を実際のソースディレクトリパスに変換
        # 例: "test_files/math.c" -> "c_source/math.c"
        if "/" in file_path:
            # ディレクトリ部分を削除してファイル名のみ取得
            filename = file_path.split("/")[-1]
        else:
            filename = file_path

        # 指定されたソースディレクトリでファイルパスを構築
        actual_file_path = Path(source_dir) / filename

        # 相対パスの場合は、main.pyがあるディレクトリから解決
        if not actual_file_path.is_absolute():
            # srcディレクトリから実行されているため、親ディレクトリ経由でアクセス
            full_path = Path(__file__).parent.parent / actual_file_path
        else:
            full_path = actual_file_path

        with open(full_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
            # 行番号は1ベースなので調整
            source_lines = lines[line_start - 1 : line_end]
            return "".join(source_lines)
    except FileNotFoundError:
        return f"// ファイルが見つかりません: {full_path}"
    except Exception as e:
        return f"// ファイル読み込みエラー: {e}"


def build_external_function_info(
    called_functions: List[str],
    generated_docs: Dict[str, str],
    header_to_impl_mapping: Dict[str, str],
    functions_dict: Dict = None,
) -> str:
    """外部関数の情報を構築する"""
    external_info = []

    for func_call in called_functions:
        if func_call.startswith("func_"):
            # 内部関数の処理
            impl_func_id = func_call
            is_mapped = False

            # .hファイルのIDの場合、対応する.cファイルのIDに変換
            if func_call in header_to_impl_mapping:
                impl_func_id = header_to_impl_mapping[func_call]
                is_mapped = True
                print(f"マッピング適用: {func_call} -> {impl_func_id}")

            if impl_func_id in generated_docs:
                # 既に生成された内部関数のドキュメント
                # 関数名を取得（フォールバックとして関数IDを使用）
                if functions_dict and impl_func_id in functions_dict:
                    func_name = functions_dict[impl_func_id]["name"]
                    external_info.append(
                        f"### {func_name}:\n{generated_docs[impl_func_id]}"
                    )
                else:
                    external_info.append(
                        f"### {impl_func_id}:\n{generated_docs[impl_func_id]}"
                    )
            else:
                # 未生成の関数 - この状況を詳しく分析
                if is_mapped:
                    # ヘッダー関数がマッピングされたが、実装が見つからない場合
                    # これは実装が存在しない（宣言のみ）ことを意味する
                    if functions_dict and func_call in functions_dict:
                        func_name = functions_dict[func_call]["name"]
                        external_info.append(
                            f"### {func_call}:\n内部関数（{func_name} - 宣言のみ、実装なし）"
                        )
                        print(
                            f"WARNING: 関数 {func_name} ({func_call}) は宣言のみで実装されていません"
                        )
                    else:
                        external_info.append(
                            f"### {func_call}:\n内部関数（宣言のみ、実装なし）"
                        )
                else:
                    # .cファイルの関数だが未生成の場合 - これは依存関係解決の問題
                    if functions_dict and func_call in functions_dict:
                        func_info = functions_dict[func_call]
                        if func_info["file_path"].endswith(".c"):
                            # .cファイルの関数が未生成なのは問題
                            raise RuntimeError(
                                f"依存関係解決エラー: .c関数 {func_call} ({func_info['name']}) が処理済みリストに見つかりません。トポロジカルソートに問題があります。"
                            )
                        else:
                            # .hファイルの関数で実装がない場合
                            external_info.append(
                                f"### {func_call}:\n内部関数（{func_info['name']} - 宣言のみ、実装なし）"
                            )
                    else:
                        external_info.append(f"### {func_call}:\n内部関数（未生成）")

        elif func_call.startswith("ext_"):
            # 外部ライブラリ関数
            func_name = func_call[4:]  # "ext_"を除去
            external_info.append(f"### {func_name}:\n標準ライブラリ関数")

    return "\n\n".join(external_info) if external_info else "なし"


def topological_sort(
    functions_dict: Dict, header_to_impl_mapping: Dict[str, str]
) -> List[str]:
    """依存グラフに基づいてトポロジカルソートを実行し、依存関係の末端から順に並べる

    Args:
        functions_dict: 関数辞書（out.jsonのfunctions部分）
        header_to_impl_mapping: .hファイルのIDから.cファイルのIDへのマッピング

    Returns:
        List[str]: 依存関係を考慮した処理順序のfunc_idリスト
    """
    # 依存関係グラフを構築
    graph = {}  # func_id -> 依存先のfunc_idリスト
    in_degree = {}  # func_id -> 依存元の数

    # .cファイルの関数のみを対象とする
    c_functions = {
        func_id: info
        for func_id, info in functions_dict.items()
        if info["file_path"].endswith(".c")
    }

    # 初期化
    for func_id in c_functions:
        graph[func_id] = []
        in_degree[func_id] = 0

    # 依存関係グラフを構築
    for func_id, func_info in c_functions.items():
        for call in func_info.get("calls", []):
            if call.startswith("func_"):
                # .hファイルのIDの場合、対応する.cファイルのIDに変換
                target_call = call
                if call in header_to_impl_mapping:
                    target_call = header_to_impl_mapping[call]
                    print(f"依存関係マッピング: {call} -> {target_call}")

                # .cファイルの関数への依存のみを追加
                if target_call in c_functions:
                    graph[target_call].append(
                        func_id
                    )  # target_call関数がfunc_id関数に依存される
                    in_degree[func_id] += 1

    # トポロジカルソート実行（Kahn's algorithm）
    queue = []
    result = []

    # 依存関係のない関数をキューに追加
    for func_id in c_functions:
        if in_degree[func_id] == 0:
            queue.append(func_id)

    while queue:
        current = queue.pop(0)
        result.append(current)

        # currentに依存していた関数の依存度を減らす
        for dependent in graph[current]:
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)

    # 循環依存がある場合の検出
    if len(result) != len(c_functions):
        print(
            f"警告: 循環依存が検出されました。処理できない関数数: {len(c_functions) - len(result)}"
        )
        # 循環依存の関数も追加（順序は保証されない）
        remaining = [func_id for func_id in c_functions if func_id not in result]
        result.extend(remaining)

    return result


def create_header_to_impl_mapping(functions_dict: Dict) -> Dict[str, str]:
    """ヘッダーファイル(.h)の関数IDを実装ファイル(.c)の関数IDにマッピング

    Args:
        functions_dict: 関数辞書（out.jsonのfunctions部分）

    Returns:
        Dict[str, str]: .hのfunc_id -> .cのfunc_idのマッピング
    """
    mapping = {}

    # 関数名でグループ化
    name_to_ids = {}
    for func_id, func_info in functions_dict.items():
        func_name = func_info["name"]
        if func_name not in name_to_ids:
            name_to_ids[func_name] = {"header": None, "impl": None}

        if func_info["file_path"].endswith(".h"):
            name_to_ids[func_name]["header"] = func_id
        elif func_info["file_path"].endswith(".c"):
            name_to_ids[func_name]["impl"] = func_id

    # .hから.cへのマッピングを作成
    for func_name, ids in name_to_ids.items():
        if ids["header"] and ids["impl"]:
            mapping[ids["header"]] = ids["impl"]
            print(f"マッピング: {func_name} (.h: {ids['header']} -> .c: {ids['impl']})")

    print(f"作成されたマッピング数: {len(mapping)}")
    return mapping


def create_timestamp_directories(base_dir: str = "../docs") -> tuple[Path, Path]:
    """タイムスタンプ付きのディレクトリ構造を作成する

    Returns:
        tuple[Path, Path]: (docs_dir, prompts_dir)
    """
    # タイムスタンプを生成
    timestamp = datetime.now().strftime("%Y_%m_%d_%H%M%S")
    timestamp_dir = Path(base_dir).parent / f"docs_{timestamp}"

    # ディレクトリを作成
    docs_dir = timestamp_dir / "docs"
    prompts_dir = timestamp_dir / "prompts"

    docs_dir.mkdir(parents=True, exist_ok=True)
    prompts_dir.mkdir(parents=True, exist_ok=True)

    print(f"タイムスタンプディレクトリを作成しました: {timestamp_dir}")

    return docs_dir, prompts_dir


def generate_function_documentation(
    func_info: Dict,
    sys_prompt_template: str,
    user_prompt_template: str,
    generated_docs: Dict[str, str],
    header_to_impl_mapping: Dict[str, str],
    functions_dict: Dict,
    prompts_dir: Path = None,
    source_dir: str = "c_source/",
) -> str:
    """単一関数のドキュメントを生成する"""

    # C言語ソースコードを読み込み
    c_source = read_c_source(
        func_info["file_path"],
        func_info["line_start"],
        func_info["line_end"],
        source_dir,
    )

    # 外部関数情報を構築
    external_function_info = build_external_function_info(
        func_info.get("calls", []),
        generated_docs,
        header_to_impl_mapping,
        functions_dict,
    )

    # プロンプトテンプレートの変数を置換
    user_prompt = user_prompt_template.format(
        c_source=c_source, external_function_info=external_function_info
    )

    # プロンプトを保存（prompts_dirが指定されている場合）
    if prompts_dir:
        func_id = func_info["id"]
        func_name = func_info["name"]

        # システムプロンプトを保存
        sys_prompt_file = prompts_dir / f"{func_name}_{func_id}_sys_prompt.txt"
        sys_prompt_file.write_text(sys_prompt_template, encoding="utf-8")

        # ユーザープロンプトを保存
        user_prompt_file = prompts_dir / f"{func_name}_{func_id}_user_prompt.txt"
        user_prompt_file.write_text(user_prompt, encoding="utf-8")

    # LLMでドキュメント生成
    try:
        documentation = chat_completion(sys_prompt_template, user_prompt)
        return documentation
    except Exception as e:
        return f"<error>ドキュメント生成エラー: {e}</error>"


def process_all_functions(
    calls_json_path: str = "../out.json",
    sys_prompt_path: str = "../prompts/sys_prompt.md",
    user_prompt_path: str = "../prompts/user_prompt.md",
    output_dir: str = "../docs",
    source_dir: str = "c_source/",
) -> Dict[str, str]:
    """すべての関数のドキュメントを依存順序で生成する"""

    # 依存関係データを読み込み
    calls_data = load_calls_json(calls_json_path)

    # データ構造を統一（リストの場合は辞書に変換）
    if isinstance(calls_data, list):
        functions_dict = {func["id"]: func for func in calls_data}
    else:
        functions_dict = calls_data["functions"]

    # プロンプトテンプレートを読み込み
    sys_prompt_template = Path(sys_prompt_path).read_text(encoding="utf-8")
    user_prompt_template = Path(user_prompt_path).read_text(encoding="utf-8")

    # タイムスタンプ付きディレクトリを作成
    docs_dir, prompts_dir = create_timestamp_directories(output_dir)

    # 生成済みドキュメントを保存する辞書
    generated_docs = {}

    # .hファイルから.cファイルへのIDマッピングを作成
    print("ヘッダーファイルと実装ファイルのマッピングを作成中...")
    header_to_impl_mapping = create_header_to_impl_mapping(functions_dict)

    # 依存グラフに基づく処理順序を生成
    print("依存関係を分析し、処理順序を決定中...")
    processing_order = topological_sort(functions_dict, header_to_impl_mapping)
    total_c_functions = len(processing_order)

    print(
        f"トポロジカルソート完了: {total_c_functions}個の.c関数を依存順序で処理します"
    )

    processed_count = 0

    # 依存関係を考慮した順序で関数ドキュメントを生成
    for func_id in processing_order:
        func_info = functions_dict[func_id]

        processed_count += 1
        print(
            f"({processed_count}/{total_c_functions}) 関数 {func_info['name']} ({func_id}) のドキュメントを生成中..."
        )

        # ドキュメント生成（プロンプトも保存）
        documentation = generate_function_documentation(
            func_info,
            sys_prompt_template,
            user_prompt_template,
            generated_docs,
            header_to_impl_mapping,
            functions_dict,
            prompts_dir,
            source_dir,
        )

        # 生成済みドキュメントに保存
        generated_docs[func_id] = documentation

        # ドキュメントファイルに保存
        output_file = docs_dir / f"{func_info['name']}_{func_id}.xml"
        output_file.write_text(documentation, encoding="utf-8")

        print(f"  → ドキュメント: {output_file} に保存完了")

    print(f"\nすべての関数ドキュメント生成が完了しました。")
    print(f"生成されたファイル数: {len(generated_docs)}")
    print(f"ドキュメント保存先: {docs_dir}")
    print(f"プロンプト保存先: {prompts_dir}")

    return generated_docs


if __name__ == "__main__":
    generated_docs = process_all_functions()
