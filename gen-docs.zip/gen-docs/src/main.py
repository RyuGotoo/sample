from pathlib import Path
from llm import chat_completion


def process_md_file(md_file_path, replacements):
    """
    MDファイルを読み込み、複数のプレースホルダーを置換する関数

    Args:
        md_file_path (str | Path): MDファイルのパス
        replacements (dict): 置換パターンの辞書 {'placeholder': 'replacement_text'}
    """
    try:
        # Pathオブジェクトに変換
        md_path = Path(md_file_path)

        # ファイルの存在確認
        if not md_path.exists():
            print(f"エラー: ファイル '{md_path}' が見つかりません。")
            return

        # MDファイルを読み込み
        md_content = md_path.read_text(encoding="utf-8")

        # 辞書に基づいて置換
        for placeholder, replacement in replacements.items():
            md_content = md_content.replace(f"{{{placeholder}}}", replacement)

        print(md_content)

    except Exception as e:
        print(f"エラーが発生しました: {e}")


def main():
    c_source = Path("../c_source/main.c")
    replacements = {"c_source": c_source.read_text(encoding="utf-8")}

    process_md_file("../prompts/user_prompt.md", replacements)
    ret = chat_completion(
        sys_prompt="あなたは優秀なAIアシスタントです",
        user_prompt="なぜ空は青いの？",
    )
    print(ret)


if __name__ == "__main__":
    main()
