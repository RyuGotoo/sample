#!/usr/bin/env python3
"""
analysis_result.jsonの不足情報を修正するツール

使用方法:
    python3 fix_analysis_result.py <analysis_result.json>

説明:
    type=protoのレコードでimplemented_atフィールドが欠落しているものを検出し、
    対応するtype=funcレコードを探して補完する。
    修正されたファイルは元ファイルと同じディレクトリにanalysis_result_fixed.jsonとして保存される。
"""

import json
import sys
import csv
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple


def parse_arguments() -> Tuple[Path, Path]:
    """コマンドライン引数をパースし、入出力パスを決定"""
    # 引数の確認
    if len(sys.argv) != 2:
        print("エラー: 引数が不正です")
        print("使用方法: python3 fix_analysis_result.py <analysis_result.json>")
        sys.exit(1)

    # 入力ファイルパス
    input_path = Path(sys.argv[1])

    # 入力ファイルの存在確認
    if not input_path.exists():
        print(f"エラー: 入力ファイルが見つかりません: {input_path}")
        sys.exit(1)

    if not input_path.is_file():
        print(f"エラー: 入力パスがファイルではありません: {input_path}")
        sys.exit(1)

    # 出力ファイルパスを生成（同じディレクトリに_fixedサフィックス付き）
    output_path = input_path.parent / f"{input_path.stem}_fixed{input_path.suffix}"

    return input_path, output_path


def load_json_data(file_path: Path) -> List[Dict[str, Any]]:
    """JSONファイルの読み込みとパース"""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, list):
            raise ValueError("JSONデータはリストである必要があります")

        print(f"JSONファイルを読み込みました: {len(data)}件のレコード")
        return data

    except json.JSONDecodeError as e:
        print(f"エラー: JSONパースエラー: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"エラー: ファイル読み込みエラー: {e}")
        sys.exit(1)


def find_implementation(
    records: List[Dict[str, Any]], proto_record: Dict[str, Any]
) -> Optional[str]:
    """
    type=protoレコードに対応するtype=funcレコードを検索

    Args:
        records: 全レコードのリスト
        proto_record: 実装を探すprotoレコード

    Returns:
        見つかった場合はfuncレコードのID、見つからない場合はNone
    """
    target_file_path = proto_record.get("file_path")
    target_name = proto_record.get("name")

    if not target_file_path or not target_name:
        return None

    # 同一file_path、同一nameのtype=funcレコードを検索
    for record in records:
        if (
            record.get("type") == "func"
            and record.get("file_path") == target_file_path
            and record.get("name") == target_name
        ):
            return record["id"]

    return None


def fix_proto_records(
    records: List[Dict[str, Any]],
) -> Tuple[List[Dict[str, Any]], Dict[str, int], List[Dict[str, Any]]]:
    """
    type=protoレコードのimplemented_atフィールドを補完

    Returns:
        修正済みレコードのリスト、統計情報、CSV用詳細データ
    """
    stats = {
        "total_proto": 0,
        "already_has_implemented_at": 0,
        "no_implementation_warning": 0,
        "fixed": 0,
        "error": 0,
    }

    # レコードをコピー（元データを変更しないため）
    fixed_records = []
    # CSV用詳細データ
    csv_data = []

    for record in records:
        # レコードをディープコピー
        fixed_record = record.copy()

        if record.get("type") == "proto":
            stats["total_proto"] += 1

            # CSV用レコードの基本情報
            csv_record = {
                "proto_id": record.get("id", ""),
                "file_path": record.get("file_path", ""),
                "name": record.get("name", ""),
                "status": "",
                "implemented_at": "",
                "notes": "",
            }

            # すでにimplemented_atが存在する場合
            if "implemented_at" in record:
                stats["already_has_implemented_at"] += 1
                csv_record["status"] = "ALREADY_SET"
                csv_record["implemented_at"] = record["implemented_at"]

            # warningsに"no implementation found"が含まれる場合
            elif record.get("warnings") and any(
                "no implementation found" in w.lower() for w in record["warnings"]
            ):
                stats["no_implementation_warning"] += 1
                csv_record["status"] = "WARNING"
                csv_record["notes"] = "no implementation found in warnings"

            # implemented_atを補完する必要がある場合
            else:
                implementation_id = find_implementation(records, record)

                if implementation_id:
                    fixed_record["implemented_at"] = implementation_id
                    stats["fixed"] += 1
                    csv_record["status"] = "FOUND"
                    csv_record["implemented_at"] = implementation_id
                    print(
                        f"implemented_atを追加: {record['id']} -> {implementation_id}"
                    )
                else:
                    stats["error"] += 1
                    csv_record["status"] = "NOT_FOUND"
                    csv_record["notes"] = "実装が見つかりません"
                    print(
                        f"警告: 実装が見つかりません: {record['id']} (file: {record.get('file_path')}, name: {record.get('name')})"
                    )
                    # エラーとして記録するが、処理は継続

            csv_data.append(csv_record)

        fixed_records.append(fixed_record)

    return fixed_records, stats, csv_data


def save_result(data: List[Dict[str, Any]], output_path: Path) -> None:
    """修正済みデータをJSONファイルとして保存"""
    try:
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"結果を保存しました: {output_path}")
    except Exception as e:
        print(f"エラー: ファイル保存エラー: {e}")
        sys.exit(1)


def save_csv_summary(csv_data: List[Dict[str, Any]], csv_path: Path) -> None:
    """実装の有無一覧をCSVファイルとして保存"""
    try:
        with open(csv_path, "w", encoding="utf-8-sig", newline="") as f:
            if csv_data:
                fieldnames = [
                    "proto_id",
                    "file_path",
                    "name",
                    "status",
                    "implemented_at",
                    "notes",
                ]
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(csv_data)
        print(f"CSV結果を保存しました: {csv_path}")
    except Exception as e:
        print(f"エラー: CSV保存エラー: {e}")


def print_summary(stats: Dict[str, int]) -> None:
    """処理結果のサマリーを表示"""
    print("\n=== 処理結果サマリー ===")
    print(f"総proto数: {stats['total_proto']}")
    print(f"既にimplemented_atあり: {stats['already_has_implemented_at']}")
    print(f"実装なし（警告あり）: {stats['no_implementation_warning']}")
    print(f"修正済み: {stats['fixed']}")
    print(f"エラー（実装が見つからない）: {stats['error']}")
    print("========================\n")


def main():
    """メイン処理"""
    # コマンドライン引数をパース
    input_path, output_path = parse_arguments()

    print(f"入力ファイル: {input_path}")
    print(f"出力ファイル: {output_path}")
    print("処理を開始します...")

    # データ読み込み
    records = load_json_data(input_path)

    # implemented_at補完処理
    fixed_records, stats, csv_data = fix_proto_records(records)

    # 結果保存
    save_result(fixed_records, output_path)

    # CSV結果保存
    csv_path = input_path.parent / f"{input_path.stem}_implementation_summary.csv"
    save_csv_summary(csv_data, csv_path)

    # サマリー表示
    print_summary(stats)

    # エラーがある場合は警告
    if stats["error"] > 0:
        print(f"\n注意: {stats['error']}件のレコードで実装が見つかりませんでした。")

    print("処理が完了しました。")


if __name__ == "__main__":
    main()
