#!/usr/bin/env python3
"""
C言語関数ドキュメント生成スクリプト

generation_order.csvに基づいて、C言語関数を順次解析し、
XML形式のドキュメントを生成するスクリプト。
"""

import argparse
import csv
import json
import re
import sys
import traceback
import xml.etree.ElementTree as ET
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from llm import chat_completions
from logger_config import setup_logger, get_logger


def load_settings(settings_file: str) -> Dict:
    """設定ファイルを読み込む"""
    try:
        with open(settings_file, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        raise Exception(f"設定ファイル {settings_file} が見つかりません")
    except json.JSONDecodeError as e:
        raise Exception(
            f"設定ファイル {settings_file} のJSONフォーマットが正しくありません: {e}"
        )


def load_file(file_path: str) -> str:
    """ファイルの内容を読み込む"""
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()


def load_analysis_result(analysis_file: str) -> Dict[str, Dict]:
    """analysis_result.jsonを読み込んで関数IDをキーとする辞書を返す"""
    try:
        with open(analysis_file, "r", encoding="utf-8") as f:
            analysis_data = json.load(f)

        # 関数IDをキーとする辞書を作成
        analysis_dict = {}
        for item in analysis_data:
            if item.get("type") == "func":
                analysis_dict[item["id"]] = item

        return analysis_dict
    except FileNotFoundError:
        raise Exception(f"解析結果ファイル {analysis_file} が見つかりません")
    except json.JSONDecodeError as e:
        raise Exception(
            f"解析結果ファイル {analysis_file} のJSONフォーマットが正しくありません: {e}"
        )


def load_generation_order(csv_file: str) -> List[Dict[str, str]]:
    """CSV読み込み機能"""
    functions = []
    with open(csv_file, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            functions.append(
                {
                    "order": row["order"],
                    "id": row["id"],
                    "name": row["name"],
                    "type": row["type"],
                    "file_path": row["file_path"],
                }
            )
    return functions


def get_function_doc_from_xml(
    func_id: str, output_dir: Path
) -> Optional[Dict[str, str]]:
    """
    XMLファイルから関数ドキュメント情報を読み込む

    Args:
        func_id: 関数ID
        output_dir: 出力ディレクトリのルートパス

    Returns:
        関数情報の辞書 (name, purpose, summary等) またはNone
    """
    # 関数IDファイルを探索してXMLファイルパスを特定
    id_files = list(output_dir.glob(f"**/{func_id}"))

    if not id_files:
        return None

    # 同じディレクトリのdoc.xmlを読み込み
    xml_path = id_files[0].parent / "doc.xml"

    if not xml_path.exists():
        return None

    try:
        # XMLを読み込んで解析
        tree = ET.parse(xml_path)
        root = tree.getroot()

        # 必要な情報を抽出
        doc_info = {
            "name": (
                root.find(".//name").text
                if root.find(".//name") is not None
                else func_id
            ),
            "purpose": (
                root.find(".//purpose").text
                if root.find(".//purpose") is not None
                else "<不明>"
            ),
            "summary": (
                root.find(".//summary").text
                if root.find(".//summary") is not None
                else "<不明>"
            ),
        }

        return doc_info
    except Exception:
        return None


def check_function_exists(func_id: str, output_dir: Path) -> bool:
    """
    関数のドキュメントが既に生成済みかチェック

    Args:
        func_id: 関数ID
        output_dir: 出力ディレクトリのルートパス

    Returns:
        生成済みの場合True
    """
    # 関数IDファイルの存在確認
    id_files = list(output_dir.glob(f"**/{func_id}"))
    return len(id_files) > 0


def extract_function_from_c_file(file_path: str, line_start: int, line_end: int) -> str:
    """Cファイルから指定した行範囲のソースコードを抽出する"""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except UnicodeDecodeError:
        # UTF-8でデコードできない場合はShift_JISを試す
        try:
            with open(file_path, "r", encoding="shift_jis") as f:
                lines = f.readlines()
        except Exception as e:
            raise Exception(
                f"ファイル {file_path} を読み込めません (UTF-8/Shift_JIS両方で失敗): {e}"
            )

    # 行番号は1ベースなので、0ベースのインデックスに変換
    start_idx = line_start - 1
    end_idx = line_end  # line_endは含む

    if start_idx < 0 or end_idx > len(lines):
        raise Exception(
            f"指定された行範囲 {line_start}-{line_end} がファイル範囲外です"
        )

    # 指定された行範囲のソースコードを抽出
    function_source = "".join(lines[start_idx:end_idx])

    return function_source.strip()


def get_function_calls_from_analysis(analysis_info: Dict) -> List[str]:
    """analysis_result.jsonから関数呼び出し情報を取得する"""
    calls = analysis_info.get("calls", [])
    # calls配列には外部関数名（ext_*）と内部関数ID（func_*）が混在
    return calls


def get_external_function_info(analysis_info: Dict, output_dir: Path) -> str:
    """外部関数情報を収集・構築する（XMLファイルから随時読み込み）"""
    function_calls = get_function_calls_from_analysis(analysis_info)
    external_info_parts = []

    for func_call_id in function_calls:
        # XMLファイルから情報を取得
        doc_info = get_function_doc_from_xml(func_call_id, output_dir)

        if doc_info:
            func_name = doc_info.get("name", func_call_id)
            info_text = f"**{func_name}**:\n"
            info_text += f"  目的: {doc_info.get('purpose', '<不明>')}\n"
            info_text += f"  概要: {doc_info.get('summary', '<不明>')}"
            external_info_parts.append(info_text)

    if external_info_parts:
        return "\n\n".join(external_info_parts)
    else:
        return "外部関数の情報はありません。"


def create_user_prompt(
    template: str, c_source: str, external_function_info: str
) -> str:
    """user_promptを作成する"""
    return template.format(
        c_source=c_source, external_function_info=external_function_info
    )


def parse_xml_from_response(response: str) -> Optional[str]:
    """LLMレスポンスからXMLを抽出する"""
    # ```xml ~~~ ``` で囲まれた部分を抽出
    xml_pattern = r"```xml\s*(.*?)\s*```"
    match = re.search(xml_pattern, response, re.DOTALL)

    if match:
        return match.group(1).strip()
    else:
        # XMLタグで囲まれた部分を直接探す
        xml_start = response.find("<function>")
        xml_end = response.find("</function>")

        if xml_start != -1 and xml_end != -1:
            return response[xml_start : xml_end + len("</function>")].strip()

    return None


def validate_and_parse_xml(xml_content: str) -> Dict[str, str]:
    """XMLの妥当性を検証し、必要な情報を抽出する"""
    try:
        root = ET.fromstring(xml_content)

        # 必要な要素を抽出
        extracted_info = {
            "name": root.find("name").text if root.find("name") is not None else "",
            "purpose": (
                root.find("purpose").text if root.find("purpose") is not None else ""
            ),
            "summary": (
                root.find("summary").text if root.find("summary") is not None else ""
            ),
        }

        return extracted_info

    except ET.ParseError as e:
        raise Exception(f"XMLパースエラー: {e}")


def save_error_log(error_info: Dict, output_dir: Path):
    """エラー情報をログファイルに保存する"""
    log_file = output_dir / "error.log"

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"""
================================================================================
時刻: {timestamp}
関数名: {error_info.get('function_name', 'N/A')}
ファイルパス: {error_info.get('file_path', 'N/A')}
エラー: {error_info.get('error_message', 'N/A')}
試行回数: {error_info.get('attempt', 'N/A')}/{error_info.get('max_retries', 'N/A')}
詳細:
{error_info.get('traceback', 'N/A')}
================================================================================
"""

    with open(log_file, "a", encoding="utf-8") as f:
        f.write(log_entry)


def save_function_documents(
    func_info: Dict[str, str], xml_content: str, user_prompt: str, output_dir: Path
):
    """関数ドキュメントを適切なディレクトリ構造で保存する"""
    logger = get_logger("generate_docs")
    # 元のファイルパスからディレクトリ構造を取得
    original_path = Path(func_info["file_path"])

    # ファイル名（拡張子なし）を含む構造を保持
    relative_dir = str(original_path.parent)
    file_stem = original_path.stem  # 拡張子なしのファイル名

    # 関数専用ディレクトリを作成
    function_dir = output_dir / relative_dir / file_stem / func_info["name"]
    function_dir.mkdir(parents=True, exist_ok=True)

    # user_prompt.mdを保存
    user_prompt_filepath = function_dir / "user_prompt.md"
    with open(user_prompt_filepath, "w", encoding="utf-8") as f:
        f.write(user_prompt)

    # doc.xmlを保存
    xml_filepath = function_dir / "doc.xml"
    with open(xml_filepath, "w", encoding="utf-8") as f:
        f.write(xml_content)

    # 関数IDファイルを作成（空ファイル）
    func_id_filepath = function_dir / func_info["id"]
    func_id_filepath.touch()

    logger.debug(f"  ドキュメント保存完了: {function_dir}")
    logger.debug(f"    - user_prompt.md: {len(user_prompt)} 文字")
    logger.debug(f"    - doc.xml: {len(xml_content)} 文字")
    logger.debug(f"    - {func_info['id']}: 関数IDファイル")


def process_function_with_retry(
    func_info: Dict[str, str],
    settings: Dict,
    output_dir: Path,
    analysis_result: Dict[str, Dict],
) -> bool:
    """リトライ機能付きで関数を処理する"""
    logger = get_logger("generate_docs")
    max_retries = settings.get("max_retries", 3)

    for attempt in range(max_retries):
        try:
            # analysis_resultから行番号情報を取得
            func_id = func_info["id"]
            if func_id not in analysis_result:
                raise Exception(f"関数ID {func_id} がanalysis_resultに見つかりません")

            analysis_info = analysis_result[func_id]
            line_start = analysis_info["line_start"]
            line_end = analysis_info["line_end"]

            # C言語ソースコードを抽出
            c_source = extract_function_from_c_file(
                func_info["file_path"], line_start, line_end
            )
            logger.debug(f"  関数ソースコード抽出完了: {len(c_source)} 文字")

            # external_function_info作成
            external_function_info = get_external_function_info(
                analysis_info, output_dir
            )

            # プロンプトテンプレートを読み込み
            user_prompt_template = load_file(settings["user_prompt_template_file"])
            sys_prompt = load_file(settings["sys_prompt_file"])

            # user_prompt作成
            user_prompt = create_user_prompt(
                user_prompt_template, c_source, external_function_info
            )
            logger.debug(f"  プロンプト作成完了: {len(user_prompt)} 文字")

            # LLM呼び出し
            response = chat_completions(sys_prompt, user_prompt)
            logger.debug(f"  LLM応答取得完了: {len(response)} 文字")

            # XMLパース
            xml_content = parse_xml_from_response(response)
            if xml_content is None:
                raise Exception("レスポンスからXMLを抽出できませんでした")

            # XML妥当性検証
            extracted_info = validate_and_parse_xml(xml_content)

            # ドキュメント保存（user_prompt.md と doc.xml）
            save_function_documents(func_info, xml_content, user_prompt, output_dir)

            # 処理成功
            return True

        except Exception as e:
            error_info = {
                "function_name": func_info["name"],
                "file_path": func_info["file_path"],
                "error_message": str(e),
                "attempt": attempt + 1,
                "max_retries": max_retries,
                "traceback": traceback.format_exc(),
            }

            # エラーログを保存
            save_error_log(error_info, output_dir)

            logger.error(f"  試行 {attempt + 1}/{max_retries} 失敗: {e}")
            if attempt < max_retries - 1:
                retry_delay = settings.get("retry_delay_seconds", 1)
                logger.warning(f"  {retry_delay}秒後にリトライします...")
                time.sleep(retry_delay)
            else:
                logger.error(
                    f"  最大リトライ回数に達しました。関数 {func_info['name']} の処理をスキップします。"
                )
                raise

    return False


def worker_process(
    worker_id: int,
    num_workers: int,
    functions_list: List[Dict[str, str]],
    settings: Dict,
    output_dir: Path,
    analysis_result: Dict[str, Dict],
):
    """各ワーカーが担当する関数を処理する

    Args:
        worker_id: ワーカーID (0から始まる)
        num_workers: 総ワーカー数
        functions_list: 処理対象の関数リスト
        settings: 設定情報
        output_dir: 出力ディレクトリ
        analysis_result: 解析結果の辞書
    """
    logger = get_logger("generate_docs")
    processed = set()
    total_functions = len(functions_list)
    no_work_cycles = 0
    max_no_work_cycles = 10  # 連続で作業がない回数の上限

    while True:
        work_done = False
        has_pending_work = False  # 依存関係で待機中の作業があるかどうか

        for func_info in functions_list:
            order = int(func_info["order"])

            # このワーカーが担当する関数かチェック (order % num_workers == worker_id)
            if order % num_workers != worker_id:
                continue

            func_id = func_info["id"]

            # 既に処理済みならスキップ
            if func_id in processed or check_function_exists(func_id, output_dir):
                processed.add(func_id)
                continue

            # まだ処理されていない関数がある
            has_pending_work = True

            # 依存関数がすべて生成済みかチェック
            dependencies_ready = True
            if func_id in analysis_result:
                calls = analysis_result[func_id].get("calls", [])
                for call in calls:
                    # func_で始まる内部関数のみチェック
                    if call.startswith("func_"):
                        if not check_function_exists(call, output_dir):
                            dependencies_ready = False
                            break

            if dependencies_ready:
                # 処理実行
                current_time = datetime.now().strftime("%H:%M:%S")
                progress = f"[{order}/{total_functions}]"

                if num_workers > 1:
                    logger.info(
                        f"{progress} [Worker {worker_id+1}/{num_workers}] {func_info['name']} を処理中... ({current_time})"
                    )
                else:
                    logger.info(
                        f"{progress} {func_info['name']} を処理中... ({current_time})"
                    )

                start_time = time.time()
                try:
                    success = process_function_with_retry(
                        func_info, settings, output_dir, analysis_result
                    )
                    if success:
                        elapsed_time = time.time() - start_time
                        if num_workers > 1:
                            logger.info(
                                f"✓ [Worker {worker_id+1}] {func_info['name']} の処理が完了しました ({elapsed_time:.1f}秒)"
                            )
                        else:
                            logger.info(
                                f"✓ {func_info['name']} の処理が完了しました ({elapsed_time:.1f}秒)"
                            )
                    else:
                        logger.error(f"✗ {func_info['name']} の処理に失敗しました")

                    processed.add(func_id)
                    work_done = True

                except Exception as e:
                    # 最終的なエラーとしてログに記録
                    error_info = {
                        "function_name": func_info["name"],
                        "file_path": func_info["file_path"],
                        "error_message": f"全試行失敗: {str(e)}",
                        "attempt": "FINAL",
                        "max_retries": settings.get("max_retries", 3),
                        "traceback": traceback.format_exc(),
                    }
                    save_error_log(error_info, output_dir)

                    if num_workers > 1:
                        logger.error(
                            f"✗ [Worker {worker_id+1}] {func_info['name']} の処理でエラーが発生しました: {e}"
                        )
                    else:
                        logger.error(
                            f"✗ {func_info['name']} の処理でエラーが発生しました: {e}"
                        )

        # 作業の完了判定
        if work_done:
            no_work_cycles = 0  # 作業があったらカウンターリセット
        else:
            no_work_cycles += 1

        # 待機中の作業がなく、連続で作業がない場合は終了
        if not has_pending_work and no_work_cycles >= max_no_work_cycles:
            break

        # CPU負荷軽減のための短い待機
        time.sleep(5)

    if num_workers > 1:
        logger.info(f"Worker {worker_id+1} の処理が完了しました")


def main():
    """メイン実行関数"""
    parser = argparse.ArgumentParser(description="C言語関数ドキュメント生成スクリプト")
    parser.add_argument(
        "settings_file",
        nargs="?",
        default="settings.json",
        help="設定ファイルのパス (デフォルト: settings.json)",
    )

    args = parser.parse_args()

    try:
        # 設定読み込み
        settings = load_settings(args.settings_file)

        # 出力ディレクトリの準備
        output_dir = Path(settings["output_dir"])
        output_dir.mkdir(parents=True, exist_ok=True)

        # ロガーの設定
        logger = setup_logger(
            "generate_docs",
            output_dir,
            level="INFO",
            console_output=True,
            file_output=True,
        )

        logger.info(f"設定ファイル {args.settings_file} を読み込みました")

        logger.info(f"ドキュメント生成を開始します...")

        # analysis_result.jsonを読み込み
        analysis_result = load_analysis_result(settings["analysis_result_file"])
        logger.info(f"解析結果を読み込みました: {len(analysis_result)}件の関数")

        # CSV読み込み（output_dirからgeneration_order.csvのパスを計算）
        generation_order_file = Path(settings["output_dir"]) / "generation_order.csv"
        functions_to_process = load_generation_order(str(generation_order_file))
        logger.info(f"処理対象関数: {len(functions_to_process)}件")

        # ワーカー数を設定から取得（デフォルト: 1）
        num_workers = settings.get("num_workers", 1)

        if num_workers == 1:
            logger.info("順次処理モードで実行します")
        else:
            logger.info(f"並列処理モードで実行します: {num_workers}ワーカー")

        # ThreadPoolExecutorで並列処理（num_workers=1なら実質順次処理）
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            futures = [
                executor.submit(
                    worker_process,
                    worker_id,
                    num_workers,
                    functions_to_process,
                    settings,
                    output_dir,
                    analysis_result,
                )
                for worker_id in range(num_workers)
            ]

            # 全ワーカーの完了を待つ
            for future in futures:
                future.result()

        logger.info(f"ドキュメント生成が完了しました。出力先: {output_dir}")

    except Exception as e:
        # 設定読み込みエラーの場合はprintを使用（ロガー未設定のため）
        print(f"エラー: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
