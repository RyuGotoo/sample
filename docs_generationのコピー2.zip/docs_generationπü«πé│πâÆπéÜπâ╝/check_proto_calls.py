#!/usr/bin/env python3
"""
analysis_result.json内のcalls配列にproto_xxxが含まれているかを検証するスクリプト
"""

import json
import sys
from pathlib import Path


def check_proto_calls(json_file_path):
    """
    JSONファイルを読み込み、calls配列内にproto_xxxパターンがあるかチェックする
    
    Args:
        json_file_path (str): 解析対象のJSONファイルパス
    
    Returns:
        dict: 検証結果を含む辞書
    """
    try:
        with open(json_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        return {"error": f"ファイルが見つかりません: {json_file_path}"}
    except json.JSONDecodeError as e:
        return {"error": f"JSONの解析に失敗しました: {e}"}
    
    # proto_xxxを含むcallsを持つ関数を収集
    functions_with_proto_calls = []
    total_functions = 0
    total_proto_calls = 0
    
    for item in data:
        if item.get("type") == "func" and "calls" in item:
            total_functions += 1
            calls = item["calls"]
            proto_calls = [call for call in calls if call.startswith("proto_")]
            
            if proto_calls:
                functions_with_proto_calls.append({
                    "function_id": item["id"],
                    "function_name": item["name"],
                    "file_path": item["file_path"],
                    "line_start": item["line_start"],
                    "proto_calls": proto_calls
                })
                total_proto_calls += len(proto_calls)
    
    return {
        "total_functions": total_functions,
        "functions_with_proto_calls": len(functions_with_proto_calls),
        "total_proto_calls": total_proto_calls,
        "details": functions_with_proto_calls
    }


def main():
    json_file = "analysis_result.json"
    
    # ファイルの存在確認
    if not Path(json_file).exists():
        print(f"エラー: {json_file} が見つかりません")
        sys.exit(1)
    
    # 検証実行
    result = check_proto_calls(json_file)
    
    if "error" in result:
        print(f"エラー: {result['error']}")
        sys.exit(1)
    
    # 結果出力
    print("=== proto_xxx呼び出し検証結果 ===")
    print(f"総関数数: {result['total_functions']}")
    print(f"proto_xxxを呼び出す関数数: {result['functions_with_proto_calls']}")
    print(f"proto_xxx呼び出し総数: {result['total_proto_calls']}")
    print()
    
    if result['functions_with_proto_calls'] > 0:
        print("=== proto_xxxを呼び出している関数 ===")
        for func in result['details']:
            print(f"関数: {func['function_name']} (ID: {func['function_id']})")
            print(f"  ファイル: {func['file_path']}:{func['line_start']}")
            print(f"  proto_xxx呼び出し: {', '.join(func['proto_calls'])}")
            print()
    else:
        print("proto_xxxを呼び出している関数は見つかりませんでした。")


if __name__ == "__main__":
    main()