from __future__ import annotations

import argparse
import sys
from pathlib import Path

from dotenv import load_dotenv

from src.doc_code_mapper import MappingConfig, generate_mapping


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Doc-Code Mapper: マニュアルとソースツリーを突き合わせ、"
            "キーワード単位のマッピング結果を生成します。"
        )
    )
    parser.add_argument(
        "--manual-dir", required=True, help="Markdownマニュアルのディレクトリ"
    )
    parser.add_argument("--code-dir", required=True, help="ソースコードディレクトリ")
    parser.add_argument(
        "--output",
        help="結果を書き出すJSONファイルパス (省略時は標準出力にサマリのみ表示)",
    )
    parser.add_argument("--model", default="gpt-4o-mini", help="OpenAIモデル名")
    parser.add_argument(
        "--keywords-per-doc",
        type=int,
        default=20,
        help="マニュアル1件あたりの最大キーワード数",
    )
    parser.add_argument(
        "--matches-per-keyword",
        type=int,
        default=5,
        help="キーワード1件あたりの最大マッチ数",
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=0.1,
        help="LLMのtemperature",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    load_dotenv()

    config = MappingConfig(
        manual_dir=Path(args.manual_dir).resolve(),
        code_dir=Path(args.code_dir).resolve(),
        model=args.model,
        keywords_per_doc=args.keywords_per_doc,
        matches_per_keyword=args.matches_per_keyword,
        temperature=args.temperature,
        output_path=Path(args.output).resolve() if args.output else None,
    )

    try:
        result = generate_mapping(config)
    except Exception as exc:  # noqa: BLE001
        print(f"[ERROR] {exc}", file=sys.stderr)
        raise SystemExit(1) from exc

    if not args.output:
        _print_summary(result)
    else:
        print(f"結果を {config.output_path} に保存しました。")


def _print_summary(result) -> None:
    print(
        "マッピング完了:\n"
        f"- マニュアルディレクトリ: {result.manual_dir}\n"
        f"- ソースコードディレクトリ: {result.code_dir}\n"
        f"- 処理日時(UTC): {result.generated_at.isoformat()}\n"
        f"- 対象マニュアル数: {len(result.documents)}"
    )
    for doc in result.documents:
        keywords = ", ".join(doc.keywords) if doc.keywords else "(キーワード無し)"
        print(f"\n[{doc.document.path.name}] {keywords}")
        for match in doc.matches:
            hit_count = len(match.occurrences)
            print(f"  - {match.keyword}: {hit_count}件のヒット")
            for occ in match.occurrences:
                print(
                    f"      * {occ.file_path}:{occ.line_number} -> {occ.line_preview[:80]}"
                )


if __name__ == "__main__":
    main()
