# Doc-Code Mapper

Doc-Code Mapperは、複数のMarkdownマニュアルとソースコードディレクトリを突き合わせ、マニュアルに記載された機能をLLMでキーワード化し、該当しそうなコード断片を横断検索するツールです。

## 特徴
- マニュアル(H1タイトル付きMarkdown)を自動収集し、LLM(GPT-4o系)で機能キーワードを抽出
- 抽出キーワードでソースコード全体を全文検索し、ファイル・行番号・スニペットを取得
- 結果はJSONとして保存でき、CLI上でもサマリを確認可能

## 動作要件
- Python 3.9 以上
- [uv](https://github.com/astral-sh/uv)
- OpenAI APIキー（`OPENAI_API_KEY`）

## セットアップ
```bash
# 依存パッケージのインストール
uv sync

# OpenAIキーを.envに記載 (.envはリポジトリルート)
cat <<'ENV' > .env
OPENAI_API_KEY=sk-...
ENV
```

## 使い方
```bash
uv run python main.py \
  --manual-dir ./docs \
  --code-dir ./src \
  --output ./artifacts/mapping.json \
  --model gpt-4o-mini \
  --keywords-per-doc 8 \
  --matches-per-keyword 5
```

### 主なオプション
| オプション | 必須 | 説明 |
| --- | --- | --- |
| `--manual-dir` | ✅ | Markdownマニュアルが格納されたディレクトリ(再帰探索) |
| `--code-dir` | ✅ | 全文検索対象のソースコードディレクトリ |
| `--output` |  | 結果JSONの保存先。未指定ならサマリのみ標準出力 |
| `--model` |  | 使用するOpenAI Chat Completionsモデル名（既定: `gpt-4o-mini`） |
| `--keywords-per-doc` |  | 各マニュアルで抽出するキーワード数上限（既定: 8） |
| `--matches-per-keyword` |  | 各キーワードで保持するコードヒット数上限（既定: 5） |
| `--temperature` |  | LLMのtemperature（既定: 0.1） |

## 出力フォーマット例
```json
{
  "manual_dir": "/path/to/docs",
  "code_dir": "/path/to/src",
  "generated_at": "2025-11-18T01:23:45.678901+00:00",
  "documents": [
    {
      "manual_path": "/path/to/docs/concept.md",
      "title": "Doc-Code Mapper コンセプト",
      "keywords": ["マッピング", "オンボーディング"],
      "matches": [
        {
          "keyword": "マッピング",
          "occurrences": [
            {
              "file_path": "handlers/mapper.py",
              "line_number": 42,
              "line_preview": "class Mapper:"
            }
          ]
        }
      ]
    }
  ]
}
```

## 内部構成
- `ManualLoader`：マニュアルディレクトリから`.md`を収集し、タイトルと本文を読み込む
- `KeywordExtractor`：OpenAI Chat Completions APIを呼び出し、`{"keywords": [...]}`形式でキーワードを取得
- `CodeSearcher`：抽出キーワードを正規表現で走査し、該当行スニペットを取得
- `generate_mapping`：上記コンポーネントを連携し、結果をJSON化

## 制限事項
- LLM呼び出しにはAPIコストが発生し、ネットワーク接続が必須です
- 巨大ファイル(>200KB)やバイナリ拡張子は検索対象外にしています
- JSON出力は上限を持たないため、保存先の容量に注意してください
