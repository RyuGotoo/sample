from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from openai import OpenAI


@dataclass
class _LLMConfig:
    model: str = "gpt-4o-mini"
    temperature: float = 0.1


_client: Optional[OpenAI] = None
_config = _LLMConfig()


def configure_llm(*, model: Optional[str] = None, temperature: Optional[float] = None) -> None:
    """Update default LLM settings for subsequent calls."""
    global _config
    if model is not None:
        _config.model = model
    if temperature is not None:
        _config.temperature = temperature


def _get_client() -> OpenAI:
    global _client
    if _client is None:
        _client = OpenAI()
    return _client


def chat_completions(sys_prompt: str, user_prompt: str, *, model: Optional[str] = None, temperature: Optional[float] = None) -> str:
    """Call OpenAI Chat Completions API with shared configuration.

    Additional keyword-only arguments allow explicit override per call while keeping
    compatibility with the required positional signature.
    """

    effective_model = model or _config.model
    effective_temperature = _config.temperature if temperature is None else temperature

    response = _get_client().chat.completions.create(
        model=effective_model,
        temperature=effective_temperature,
        messages=[
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": user_prompt},
        ],
    )
    message = response.choices[0].message
    content = getattr(message, "content", None)
    if content is None and isinstance(message, dict):
        content = message.get("content")
    if content is None:
        return ""
    return content.strip()
