from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Sequence

from openai import OpenAI

from .code_search import CodeSearcher, CodeOccurrence
from .keyword_extractor import KeywordExtractor
from .manual_loader import ManualLoader, ManualDocument


@dataclass
class KeywordMatch:
    keyword: str
    occurrences: List[CodeOccurrence]

    def to_dict(self) -> dict:
        return {
            "keyword": self.keyword,
            "occurrences": [
                {
                    "file_path": occ.file_path,
                    "line_number": occ.line_number,
                    "line_preview": occ.line_preview,
                }
                for occ in self.occurrences
            ],
        }


@dataclass
class DocumentMapping:
    document: ManualDocument
    keywords: Sequence[str]
    matches: List[KeywordMatch]

    def to_dict(self) -> dict:
        return {
            "manual_path": str(self.document.path),
            "title": self.document.title,
            "keywords": list(self.keywords),
            "matches": [match.to_dict() for match in self.matches],
        }


@dataclass
class MappingResult:
    manual_dir: Path
    code_dir: Path
    generated_at: datetime
    documents: List[DocumentMapping] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "manual_dir": str(self.manual_dir),
            "code_dir": str(self.code_dir),
            "generated_at": self.generated_at.isoformat(),
            "documents": [doc.to_dict() for doc in self.documents],
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)


@dataclass
class MappingConfig:
    manual_dir: Path
    code_dir: Path
    model: str = "gpt-4o-mini"
    keywords_per_doc: int = 8
    matches_per_keyword: int = 5
    temperature: float = 0.1
    output_path: Path | None = None


def generate_mapping(config: MappingConfig) -> MappingResult:
    if config.keywords_per_doc <= 0:
        raise ValueError("keywords_per_doc must be greater than 0")
    if config.matches_per_keyword <= 0:
        raise ValueError("matches_per_keyword must be greater than 0")

    manual_loader = ManualLoader(config.manual_dir)
    documents = manual_loader.load()
    client = OpenAI()
    keyword_extractor = KeywordExtractor(
        client=client,
        model=config.model,
        max_keywords=config.keywords_per_doc,
        temperature=config.temperature,
    )
    code_searcher = CodeSearcher(
        code_dir=config.code_dir,
        max_matches_per_keyword=config.matches_per_keyword,
    )

    document_mappings: List[DocumentMapping] = []
    for document in documents:
        extraction = keyword_extractor.extract(document)
        keyword_matches: List[KeywordMatch] = []
        for keyword in extraction.keywords:
            occurrences = code_searcher.search(keyword)
            keyword_matches.append(
                KeywordMatch(keyword=keyword, occurrences=occurrences)
            )
        document_mappings.append(
            DocumentMapping(
                document=document, keywords=extraction.keywords, matches=keyword_matches
            )
        )

    result = MappingResult(
        manual_dir=config.manual_dir,
        code_dir=config.code_dir,
        generated_at=datetime.now(timezone.utc),
        documents=document_mappings,
    )

    if config.output_path:
        config.output_path.parent.mkdir(parents=True, exist_ok=True)
        config.output_path.write_text(result.to_json(), encoding="utf-8")

    return result
