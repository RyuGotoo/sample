"""Doc-Code Mapper core package."""

from .mapper import MappingConfig, MappingResult, generate_mapping  # noqa: F401
