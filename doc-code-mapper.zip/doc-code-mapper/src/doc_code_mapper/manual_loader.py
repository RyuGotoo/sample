from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List


@dataclass
class ManualDocument:
    """Represents a markdown manual file."""

    path: Path
    title: str
    content: str


class ManualLoader:
    """Loads markdown manuals from a directory."""

    def __init__(self, manual_dir: Path, encoding: str = "utf-8") -> None:
        self.manual_dir = manual_dir
        self.encoding = encoding

    def load(self) -> List[ManualDocument]:
        if not self.manual_dir.exists():
            raise FileNotFoundError(f"Manual directory not found: {self.manual_dir}")

        documents: List[ManualDocument] = []
        for path in sorted(self._iter_markdown_files(self.manual_dir)):
            try:
                text = path.read_text(encoding=self.encoding)
            except UnicodeDecodeError:
                # Skip files we cannot decode safely
                continue

            title = self._extract_title(text) or path.stem
            documents.append(ManualDocument(path=path, title=title, content=text))

        if not documents:
            raise ValueError(
                f"No markdown files were found under manual directory: {self.manual_dir}"
            )
        return documents

    @staticmethod
    def _iter_markdown_files(root: Path) -> Iterable[Path]:
        for path in root.rglob("*.md"):
            if path.is_file() and not path.name.startswith("."):
                yield path

    @staticmethod
    def _extract_title(text: str) -> str | None:
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith("# "):
                return stripped.lstrip("# ").strip()
        return None
