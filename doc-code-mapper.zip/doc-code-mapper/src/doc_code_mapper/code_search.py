from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List


@dataclass
class CodeOccurrence:
    file_path: str
    line_number: int
    line_preview: str


class CodeSearcher:
    """Performs simple keyword search across a source tree."""

    def __init__(
        self,
        code_dir: Path,
        max_matches_per_keyword: int = 5,
        max_file_size: int = 200_000,
    ) -> None:
        self.code_dir = code_dir
        self.max_matches_per_keyword = max_matches_per_keyword
        self.max_file_size = max_file_size
        self._binary_suffixes = {
            ".png",
            ".jpg",
            ".jpeg",
            ".gif",
            ".bmp",
            ".pdf",
            ".zip",
            ".exe",
            ".dll",
            ".so",
            ".dylib",
            ".pyc",
        }

    def search(self, keyword: str) -> List[CodeOccurrence]:
        if not keyword:
            return []
        pattern = re.compile(re.escape(keyword), re.IGNORECASE)
        occurrences: List[CodeOccurrence] = []
        for file_path in self._iter_text_files():
            if len(occurrences) >= self.max_matches_per_keyword:
                break
            try:
                with file_path.open("r", encoding="utf-8", errors="ignore") as handle:
                    for idx, line in enumerate(handle, start=1):
                        if pattern.search(line):
                            relative_path = self._safe_relative_path(file_path)
                            occurrences.append(
                                CodeOccurrence(
                                    file_path=relative_path,
                                    line_number=idx,
                                    line_preview=line.strip(),
                                )
                            )
                            if len(occurrences) >= self.max_matches_per_keyword:
                                break
            except OSError:
                continue
        return occurrences

    def _iter_text_files(self) -> Iterable[Path]:
        if not self.code_dir.exists():
            raise FileNotFoundError(f"Code directory not found: {self.code_dir}")
        for path in self.code_dir.rglob("*"):
            if not path.is_file():
                continue
            if path.suffix.lower() in self._binary_suffixes:
                continue
            try:
                if path.stat().st_size > self.max_file_size:
                    continue
            except OSError:
                continue
            yield path

    def _safe_relative_path(self, path: Path) -> str:
        try:
            return str(path.relative_to(self.code_dir))
        except ValueError:
            return str(path)
