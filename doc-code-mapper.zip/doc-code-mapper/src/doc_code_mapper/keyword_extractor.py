from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import List

from .manual_loader import ManualDocument
from .llm import chat_completions


@dataclass
class KeywordExtractionResult:
    document: ManualDocument
    keywords: List[str]


class KeywordExtractor:
    """Extracts keywords from manual documents using an LLM."""

    def __init__(
        self,
        model: str,
        max_keywords: int = 8,
        temperature: float = 0.1,
    ) -> None:
        self.model = model
        self.max_keywords = max_keywords
        self.temperature = temperature

    def extract(self, document: ManualDocument) -> KeywordExtractionResult:
        prompt = self._build_prompt(document)
        content = chat_completions(
            sys_prompt=(
                "あなたは技術マニュアルから機能を特定するリサーチャーです。"
                "出力は必ずJSONのみで返してください。"
            ),
            user_prompt=prompt,
            model=self.model,
            temperature=self.temperature,
        )
        keywords = self._parse_keywords(content)
        return KeywordExtractionResult(document=document, keywords=keywords)

    def _build_prompt(self, document: ManualDocument) -> str:
        snippet = document.content
        if len(snippet) > 6000:
            snippet = snippet[:6000]
        instructions = (
            "次のマニュアルの内容から、機能を特定できるキーワードまたは短いフレーズを"
            f"最大{self.max_keywords}件抽出してください。"
            "キーワードは仕様や機能名称を優先し、一般的すぎる語は避けてください。"
            'JSONは {"keywords": ["..."]} の形式で返してください。'
        )
        return f"{instructions}\n\n--- マニュアル ---\n{snippet}\n---"

    def _parse_keywords(self, response_content: str) -> List[str]:
        json_text = self._extract_json(response_content)
        keywords: List[str] = []
        if json_text:
            try:
                data = json.loads(json_text)
                if isinstance(data, dict):
                    keywords = [
                        str(item).strip()
                        for item in data.get("keywords", [])
                        if str(item).strip()
                    ]
            except json.JSONDecodeError:
                keywords = []
        if not keywords:
            keywords = self._fallback_keyword_parse(response_content)
        return keywords[: self.max_keywords]

    @staticmethod
    def _extract_json(text: str) -> str | None:
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            return match.group(0)
        return None

    @staticmethod
    def _fallback_keyword_parse(text: str) -> List[str]:
        candidates: List[str] = []
        for line in text.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            bullet_removed = stripped.lstrip("-•*# \\t")
            if not bullet_removed:
                continue
            if len(bullet_removed.split()) <= 6 or stripped.startswith(
                ("-", "*", "#", "•")
            ):
                candidates.append(bullet_removed)
        return candidates
