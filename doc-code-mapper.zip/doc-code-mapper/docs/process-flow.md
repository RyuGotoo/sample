# Doc-Code Mapper 処理フロー

この文書は、Doc-Code Mapperがマニュアルとソースコードを入力にどのような手順でマッピング結果を生成するかをまとめたものです。技術者がトレースしやすいよう、主要コンポーネントと入出力を順序立てて説明します。

## 1. CLIエントリーポイント
1. `main.py` が `argparse` で次の引数を受け取る。
   - `--manual-dir`: Markdownマニュアルを再帰探索するルート
   - `--code-dir`: 検索対象のソースコードルート
   - 任意の `--output`, `--model`, `--keywords-per-doc`, `--matches-per-keyword`, `--temperature`
2. `.env` から `OPENAI_API_KEY` を読み込むために `dotenv.load_dotenv()` を実行。
3. 受け取ったパラメータを `MappingConfig` に詰め、`generate_mapping(config)` を呼び出す。

## 2. マニュアル読み込み (`ManualLoader`)
1. `manual_dir` 以下の `.md` ファイルを再帰取得。隠しファイルは除外。
2. 各ファイルをUTF-8で読み込み、最初の `# ` 行をタイトルとして抽出。無ければファイル名をタイトルに使用。
3. `ManualDocument` (path, title, content) のリストを返却。対象が0件なら例外を送出。

## 3. キーワード抽出 (`KeywordExtractor`)
1. `OpenAI` クライアントを生成し、`chat.completions.create` を呼び出す。
2. プロンプトにはマニュアル本文(最大6000文字)と「JSON形式でキーワード配列のみ返す」指示を付与。
3. 応答から `{"keywords": [...]}` をパース。失敗した場合は行単位のフォールバックで候補語を抽出。
4. `max_keywords`（既定8件）でキーワード数を制限し、`KeywordExtractionResult` にまとめる。

## 4. コード検索 (`CodeSearcher`)
1. `code_dir` 以下のテキストファイルを列挙。バイナリ拡張子や200KB超のファイルは除外。
2. 各キーワードに対して大文字小文字を無視した単純一致検索を実施。
3. 見つかった行について、相対パス・行番号・行内容を `CodeOccurrence` として保持。キーワードごとに `max_matches_per_keyword`（既定5件）を上限とする。

## 5. マッピング結果生成 (`generate_mapping`)
1. 各 `ManualDocument` について `KeywordExtractor` と `CodeSearcher` を順番に実行。
2. キーワードと検索結果を `KeywordMatch` → `DocumentMapping` にまとめる。
3. すべてのマニュアル分を `MappingResult` に集約し、処理日時(`datetime.now(timezone.utc)`)を付与。

## 6. 出力
- `--output` が指定されていれば親ディレクトリを作成し、`MappingResult.to_json()` の内容をUTF-8で保存。
- 指定が無い場合は標準出力にサマリを表示（対象マニュアル数、各ファイルのキーワード、ヒット件数、該当スニペット）。

## 参考トレース
1. CLIで `uv run python main.py --manual-dir ./docs --code-dir ./src --output ./artifacts/mapping.json` を実行。
2. `.env` からAPIキーを読み込み、`MappingConfig` を構築。
3. `generate_mapping` 内でマニュアル→キーワード→コード検索→結果集約という順で処理。
4. 完了後、`./artifacts/mapping.json` にフル結果が保存され、ターミナルには簡易サマリが表示される。
