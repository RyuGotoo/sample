# Doc-Code Mapper ドキュメント

## ドキュメント作成ルール

### リンクポリシー
- **別のドキュメントへのリンクは記載しない**
  - 他のドキュメントへの相対パス（例: `[概要](./overview.md)`）は使用禁止
  - 同一ドキュメント内のアンカーリンク（例: `[セクション](#section)`）のみ使用可能
  - ドキュメント間の関連性は、このREADME（ドキュメント一覧）で管理する

### その他のルール
- Markdown形式で記述
- 見出しレベルは適切に使用（H1は1つ、H2以降で構造化）
- コードブロックには言語指定を含める

## ドキュメント一覧

### コンセプト・概要
- [concept.md](./concept.md) - Doc-Code Mapperのコンセプト、背景と課題、目的
- [designs/overview.md](./designs/overview.md) - 設計概要、基本設計思想
- [implementation-plan.md](./implementation-plan.md) - 実装計画、フェーズ別タスク
