# Doc-Code Mapper 設計概要

## 実行環境
- 言語: Python 3.9
- パッケージ管理: uv

## インフラ依存
- OpenAI Chat Completions API
- OpenAI GPT-4o

## マニュアルとソースコードのマッチングロジック

### キーワード検索
LLMを用いて、マニュアルからキーワードリストを取得する
そのキーワードでソースコードから全文検索