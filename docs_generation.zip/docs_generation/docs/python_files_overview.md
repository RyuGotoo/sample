# main.py
* （済）エントリーポイント
* （済）コマンドライン引数の処理
* （済）output_timestamp ディレクトリ作成
* （済）targets.txt を走査し対象ファイル一覧 (target_files.csv) を作成
* （済）全対象ファイルから生成対象関数一覧 (target_funcitons.csv) を作成
* （未）各処理のオーケストレーション

# fix_analysis_result.py
## 概要
実行方法: 
python3 fix_analysis_result.py <analysis_result.json の path> <出力先ディレクトリ path>

入力: 
* analysis_result.json の path
* 出力先ディレクトリの path

出力: 
* analysis_result2.json 

## 実装状況
* （済）analysis_result.json の不足情報を解決し analysis_result2.json として保存
  * 不足情報については @docs/tasks/fix_analysis_reuslt.md を参照

# determine_generation_order.py
## 概要
@analysis_result2.json をもとに関数の依存関係を解析し、依存の末端から番号を振り、生成順序を決定しcsvに保存する処理。
依存関係は id (func_xxx) と calls を追うことで対応可能。

実行方法:
python3 determine_generation_order.py <analysis_result.json の path> <出力先ディレクトリ path>

入力:
* analysis_result2.json の path
* 出力先ディレクトリ path

出力:
* generation_order.csv

### type=proto の扱いについて
type=proto の場合は implemented_at を実態として処理する。

## 実装状況
* （済）生成順序決定
  * 出力: generation_order.csv

## 機能追加: target_functions.csv にある関数を生成する際の順序決定
（実装済み）
上記の処理では analysis_result 内のすべての関数に対する依存関係の解決及び順序決定だったが、このモードでは target_functions にある関数のみを対象とする。

実行方法:
python3 determine_generation_order.py <analysis_result.json の path> <target_functions.csv の path> <出力先ディレクトリ path>

# generate_docs.py
入力: 
* @generation_order.csv , 
* c_source_files (例: @sample_files )

出力:
* generated_docs/ 配下に生成された関数ドキュメントxmlを出力（ディレクトリ構造は元のシステムの構造を踏襲）

機能:
* user_prompt作成
  * @prompts/user_prompt.md 内の {c_source}, {external_function_info} に情報を代入
* {external_function_info} 作成
  * 外部関数を入力する箇所。依存する関数の関数ドキュメントを入力する
* @llm.py chat_completions を用いて関数ドキュメントを生成
  * sys_prompt には @prompts/sys_prompe.md を代入（どの関数においてもシステムプロンプトは不変）
  * user_prompt には上記で作成した user_prompt を代入
* chat_completions の返り値をパースし、保存
  * chat_completions 内には ```xml ~~~ ``` で囲われた箇所があるべきで、ここをパースし保存する（ディレクトリ構造は元の c_source の構造を踏襲）
  * パースに失敗したら retry

# llm.py
* 生成AIのAPI呼び出し関数定義
  * 現状mockで実装している
