# 概要

LLMを用いて関数仕様書を生成するシステム

# 実行コマンドイメージ

python3 main.py <関数仕様書生成対象のCシステムコードファイルディレクトリ> <関数依存関係解析結果jsonファイル> <生成対象パスが記載されたtxtファイル>
例: `python3 main.py sample_files/ analysis_result.json targets.txt`

## 各ディレクトリ、ファイルの説明

<関数仕様書生成対象のCシステムコードファイルディレクトリ>:
システムのコードが入ったディレクトリパス。
例: @sample_files/

<関数依存関係解析結果jsonファイル>:
解析は別システムで作成済みで、そのファイルのパス。
例: analysis_result_sample_files.json

<生成対象パスが記載されたtxtファイル>:
全関数が生成対象ではなく、指定されているので、それらへのパス。
例: @targets.txt
