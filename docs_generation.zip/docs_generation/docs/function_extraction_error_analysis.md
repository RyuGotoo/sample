# 関数抽出エラー調査結果

## 概要
`generate_docs.py`実行時に発生した`extract_function_from_c_file`関数のエラーについて調査を実施した。

## 発生したエラー
1. **gen_trees_header関数**: 関数の終了が見つからないエラー
2. **bi_reverse関数**: 関数の終了が見つからないエラー  
3. **ZEXPORTVA関数**: 関数が見つからないエラー

## 問題の原因分析

### 1. プリプロセッサディレクティブの問題
- `gen_trees_header`関数は`#ifdef GEN_TREES_H`〜`#endif`ブロック内に定義されている（lines 319-376）
- 現在の実装では、プリプロセッサディレクティブを考慮せずに関数を検索している
- このため、条件付きコンパイル部分の関数が正しく抽出できない

### 2. K&Rスタイル関数定義の処理問題  
- `bi_reverse`関数は古いK&Rスタイルで定義されている（line 1154-1164）
```c
local unsigned bi_reverse(code, len)
    unsigned code; /* the value to invert */
    int len;       /* its bit length */
{
    // 関数本体
}
```
- 現在の中括弧バランス検出ロジックが、このスタイルに対応していない可能性がある

### 3. マクロ関数の誤認識
- `ZEXPORTVA`は関数名ではなくマクロ（zlib.hで定義）
- 実際の関数は`gzvprintf`、`gzprintf`等で、`ZEXPORTVA`は修飾子として使用されている
- 関数抽出時に、マクロ修飾子と実際の関数名を区別する必要がある

## 技術的詳細

### extract_function_from_c_file関数の問題点（lines 70-117）
1. **関数名パターンマッチング**: シンプルな正規表現`\b{function_name}\s*\(`のみ使用
2. **プリプロセッサ無視**: `#ifdef`/`#endif`ブロックを考慮していない
3. **中括弧バランス**: K&Rスタイルでパラメータ宣言部分を考慮していない
4. **マクロ展開**: マクロ修飾子付き関数の処理が不適切

## 解決策: analysis_result.jsonの活用

### 現状の問題解決
`analysis_result.json`には既に正確な行番号情報が含まれている：

```json
{
  "id": "func_145fca1c79c305b1",
  "type": "func", 
  "name": "gen_trees_header",
  "file_path": "sample_files/sudo/lib/zlib/trees.c",
  "line_start": 328,
  "line_end": 375
}
```

### 改善された実装案
現在の複雑な`extract_function_from_c_file`関数を、`analysis_result.json`の行番号を使用する単純な実装に置き換えることで：

1. **正確性の向上**: プリプロセッサディレクティブやK&Rスタイル定義にも対応
2. **性能の向上**: 正規表現や中括弧バランス検出が不要
3. **保守性の向上**: シンプルな行番号ベースの抽出
4. **信頼性の向上**: 既に解析済みの確実な情報を利用

この方法により、今回発生したすべてのエラーが根本的に解決される。