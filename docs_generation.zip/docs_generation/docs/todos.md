### 生成されてほしい項目が生成されていない

* Dss_CDrDoneCB, Dss_MctDoneCB
* 生成順序csvの時点で取りこぼしている
* analysisには入っている
* protoの取得でミスっている？

### コンテキストサイズエラー？

* いくつかエラーが出ていた
* 最初に全ファイルのエンコーディング、長さチェックをした方が良さそう

* 依存関係は適切に解決されている？
* 依存元の生成が未生成の場合の挙動は？

総じて、Win環境での検証を面倒がらずにやらなきゃいけないな。。



### done! リスタート機能実装

途中で処理が止まってしまった場合、リスタートできるようにする。
現状新規実行しかできない。

### done! 並列化

### done! 関数概要の持ち方

いま辞書でメモリに持っているが、対象関数が多いとやばいのでは

### done! 出力のディレクトリ構造がおかしい

元ディレクトリが dir/file_name.c の場合、
生成後の出力ディレクトリ構造は 
dir/file_name/doc.xml, user_prompt.md, func_id 
であるべきなのに、
dir/doc.xml, user_prompt.md, func_id となっている

例:
output_0819_01/sample_files/sudo/src/add_io_events/doc.xml
となっているが、
sample_files/sudo/src/exec_pty.c/add_io_events/doc.xml
となっているべき。

### done! プロンプト修正

stepsで処理内容が出るが、どの行のなにを根拠にそう判断したのかを書かせる




