# main.pyのsettings.json対応実装計画

## 概要
main.pyの実行方法を、コマンドライン引数からsettings.jsonファイルを使用する方式に変更する。

## 現状の分析

### 現在のmain.py
- コマンドライン引数で3つのパラメータを受け取る
  1. `base_dir`: ベースディレクトリ（例: sample_files）
  2. `analysis_file`: 解析結果ファイル（例: analysis_result.json）
  3. `targets_file`: 対象ファイルリスト（例: targets.txt）

### settings.jsonの内容
```json
{
  "output_dir": "./generated_docs_0806_01/",
  "c_source_dir": "./sample_files/",
  "analysis_result_file": "./analysis_result.json",
  "target_paths_file": "./target_paths.txt"
}
```

## 実装計画

### 1. settings.json読み込み機能の実装
- JSONファイルを読み込む関数を作成（既存のjsonモジュールを使用）
- エラーハンドリングを実装（ファイルが存在しない、フォーマットエラーなど）

### 2. main関数の修正
- コマンドライン引数の処理を変更
  - 引数なし、または`--settings`オプションでsettings.jsonのパスを指定可能に
  - デフォルトは`./settings.json`
- settings.jsonから読み込んだ値を使用するように変更

### 3. 出力ディレクトリの扱い
- settings.jsonの`output_dir`を使用
- タイムスタンプ付きディレクトリの生成ロジックを確認・調整

### 4. パスの対応関係
- `c_source_dir` → `base_dir`として使用
- `analysis_result_file` → `analysis_file`として使用
- `target_paths_file` → `targets_file`として使用

## テスト計画
1. settings.jsonを使用した実行テスト
2. settings.jsonが存在しない場合のエラーハンドリング確認
3. 不正なJSONフォーマットの場合のエラーハンドリング確認
4. 出力ディレクトリの生成確認

## 注意事項
- 既存の機能に影響を与えないよう慎重に実装する