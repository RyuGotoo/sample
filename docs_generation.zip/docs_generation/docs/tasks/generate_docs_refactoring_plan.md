# generate_docs.py リファクタリング計画

## 現在の問題点

1. **DocumentGeneratorクラスが不要**: 状態を持つ必要性が低く、関数ベースの方がシンプル
2. **設定の管理方法**: ハードコーディングされた設定値を`settings.json`から読み込むべき
3. **実行方法**: `python3 generate_docs.py settings.json`として引数で設定ファイルを指定したい

## リファクタリングの方針

### 1. クラスを関数に分解
`DocumentGenerator`クラスを以下の独立した関数に分解:
- `load_settings(settings_file)`: 設定ファイル読み込み
- `load_generation_order(csv_file)`: CSV読み込み機能
- `extract_function_from_c_file(file_path, function_name)`: C関数抽出
- `find_function_calls(c_source)`: 関数呼び出し検出
- `get_external_function_info(c_source, generated_docs)`: 外部関数情報収集
- `create_user_prompt(template, c_source, external_info)`: プロンプト作成
- `parse_xml_from_response(response)`: XML抽出
- `validate_and_parse_xml(xml_content)`: XML検証・パース
- `save_function_documents(func_info, xml_content, user_prompt, output_dir)`: ドキュメント保存
- `process_function_with_retry(func_info, settings, generated_docs)`: 関数処理（リトライ付き）
- `main()`: メイン実行関数

### 2. 設定管理の改善
`settings.json`の拡張:
```json
{
  "generation_order_file": "./generation_order.csv",
  "output_dir": "./generated_docs_0806_01/",
  "c_source_dir": "./sample_files/",
  "analysis_result_file": "./analysis_result.json",
  "target_paths_file": "./target_paths.txt",
  "sys_prompt_file": "./prompts/sys_prompt.md",
  "user_prompt_template_file": "./prompts/user_prompt.md",
  "max_retries": 3
}
```

### 3. 実行方式の変更
- コマンドライン引数で設定ファイルを指定
- `python3 generate_docs.py settings.json`
- デフォルトは`settings.json`

### 4. 状態管理の変更
- `generated_docs`辞書を関数間で渡すパラメータとして扱う
- グローバル状態を排除してテスタビリティを向上

## 実装手順

1. 設定読み込み機能の実装
2. 各機能を独立した関数に分解
3. メイン関数での統合
4. コマンドライン引数処理の追加
5. 既存機能の動作確認

## 期待される効果

- **可読性向上**: 単純な関数構成でコードが理解しやすい
- **テスタビリティ向上**: 各関数が独立してテスト可能
- **設定の柔軟性**: JSON設定ファイルで容易に設定変更可能
- **実行の便利さ**: コマンドライン引数で設定ファイルを指定可能
- **保守性向上**: 機能ごとの責任が明確になる