# determine_generation_order.py 実装計画

## 1. 概要
`analysis_result2.json` をもとに関数の依存関係を解析し、依存の末端から番号を振り、生成順序を決定してCSVに保存する処理。

## 2. 実行方法
```bash
python3 determine_generation_order.py <analysis_result.json の path> <出力先ディレクトリ path>
```

## 3. 入出力仕様
### 入力
- `analysis_result2.json` のパス
- 出力先ディレクトリのパス

### 出力
- `generation_order.csv`

## 4. 処理の流れ

### 4.1 データ読み込みフェーズ
JSONファイルから関数情報を読み込み、内部データ構造に変換する。各関数のID、型、名前、ファイルパス、依存関係（calls）を取得する。

### 4.2 依存関係の解析
- `func_`で始まるIDを持つ関数間の依存関係を構築
- `calls`フィールドから呼び出し先関数を特定
- `proto`タイプの場合は`implemented_at`を参照して実装関数と紐付け
- `ext_`で始まる外部関数は依存関係から除外

### 4.3 生成順序の決定
トポロジカルソートアルゴリズムを使用して、依存関係に基づく順序を決定する。
- 依存されていない関数（末端の関数）から順に番号を振る
- 循環依存が存在する場合はエラーとして検出

### 4.4 結果の出力
決定した順序に従って、以下の形式でCSVファイルを生成：

```csv
order,id,name,type,file_path
1,func_522e1a281f33600d,group_plugin_query,func,sample_files/sudo/plugins/group_file/plugin_test.c
2,func_6db57051691a64f0,myendgrent,func,sample_files/sudo/plugins/group_file/getgrent.c
```

## 5. エラーハンドリング
- ファイル読み込みエラー
- JSON解析エラー
- 出力ディレクトリの存在確認
- 循環依存の検出と報告

## 6. 重要な考慮事項
- 外部関数（ext_プレフィックス）は生成対象外
- プロトタイプ宣言は実装関数と同じ順序で扱う
- 依存関係の解析は関数IDベースで行う