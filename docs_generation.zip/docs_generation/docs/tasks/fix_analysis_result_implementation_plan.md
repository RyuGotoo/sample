# fix_analysis_result.py 実装計画

## 概要
analysis_result.jsonファイルに含まれるtype=protoのレコードで、implemented_atフィールドが欠落しているものを修正し、analysis_result2.jsonとして出力するツール。

## 入出力仕様
- **入力**:
  1. analysis_result.jsonのパス（コマンドライン引数）
  2. 出力先ディレクトリのパス（コマンドライン引数）
- **出力**: analysis_result2.json（修正済みデータ）

## 処理フロー

### 1. 初期化処理
- コマンドライン引数の検証
- 入力ファイルの存在確認
- 出力ディレクトリの存在確認（なければ作成）

### 2. データ読み込み
- analysis_result.jsonを読み込み、JSONデータをパース
- データ構造の検証（必須フィールドの確認）

### 3. implemented_at補完処理
type=protoのレコードを対象に以下の処理を実行：

#### 3.1 implemented_atフィールドの確認
- すでにimplemented_atが存在する場合はスキップ
- warningsフィールドに"no implementation found"が含まれる場合もスキップ

#### 3.2 実装の探索
同一file_path、同一nameのtype=funcレコードを検索：
- 見つかった場合: funcレコードのidをimplemented_atとして追加
- 見つからない場合: エラーとして記録

#### 3.3 エラーハンドリング
- 想定外のケースではエラーを発生させる
- エラーログに詳細情報を記録

### 4. 結果の出力
- 修正済みデータをanalysis_result2.jsonとして保存
- 処理結果のサマリーを表示（修正件数、スキップ件数、エラー件数）

## データ構造

### 入力データ例（type=proto）
```json
{
  "id": "proto_dd40f99ca64a6b1e",
  "type": "proto",
  "name": "main",
  "file_path": "sample_files/sudo/plugins/group_file/plugin_test.c",
  "line_start": 32,
  "line_end": 32,
  "signature": "__dso_public main(int argc, char *argv[])"
}
```

### 出力データ例（implemented_at追加後）
```json
{
  "id": "proto_dd40f99ca64a6b1e",
  "type": "proto",
  "name": "main",
  "file_path": "sample_files/sudo/plugins/group_file/plugin_test.c",
  "line_start": 32,
  "line_end": 32,
  "signature": "__dso_public main(int argc, char *argv[])",
  "implemented_at": "func_54dacc2cf12a5acb"
}
```

## モジュール構成

### main関数
- コマンドライン引数の処理
- 全体の処理フロー制御

### load_json_data関数
- JSONファイルの読み込みとパース
- データ構造の検証

### find_implementation関数
- type=funcレコードの検索
- file_pathとnameによるマッチング

### fix_proto_records関数
- type=protoレコードの処理
- implemented_atフィールドの補完

### save_result関数
- 修正済みデータの保存
- JSON形式での出力

## エラー処理方針
1. **ファイルアクセスエラー**: 明確なエラーメッセージを表示して終了
2. **データ形式エラー**: JSONパースエラーの詳細を表示
3. **実装が見つからない場合**: エラーログに記録し、処理を継続
4. **想定外のケース**: 詳細なエラー情報と共に例外を発生

## ログ出力
- INFO: 処理の進行状況
- WARNING: スキップしたレコード
- ERROR: 処理できなかったレコード
- DEBUG: 詳細な処理情報（デバッグモード時）

## テスト方針
1. 正常系: implemented_atが正しく追加されるケース
2. スキップ系: すでにimplemented_atが存在する、"no implementation found"のケース
3. エラー系: 実装が見つからない、不正なデータ形式のケース