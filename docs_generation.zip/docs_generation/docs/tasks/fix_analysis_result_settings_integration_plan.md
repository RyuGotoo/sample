# fix_analysis_result.py の設定ファイル統合計画

## 概要
`fix_analysis_result.py` スクリプトの入力パラメータを、コマンドライン引数から `settings.json` ファイルでの指定に変更する。

## 現状
- 現在の使用方法: `python3 fix_analysis_result.py <analysis_result.json の path> <出力先ディレクトリ path>`
- 2つのコマンドライン引数を必須としている

## 変更後の仕様
- 使用方法: `python3 fix_analysis_result.py` （引数なし）
- `settings.json` から以下の設定を読み込む：
  - `analysis_result_file`: 入力ファイルのパス
  - `output_dir`: 出力先ディレクトリのパス

## 実装方針

### 1. settings.json の構造確認
現在の `settings.json` には既に必要なフィールドが存在：
```json
{
  "output_dir": "./generated_docs_0806_01/",
  "analysis_result_file": "./analysis_result.json",
  ...
}
```

### 2. 変更箇所

#### a. コマンドライン引数の処理を削除
- `validate_args()` 関数を `load_settings()` に変更
- sys.argv のチェックを削除

#### b. settings.json の読み込み処理を追加
- JSONファイルを読み込み、必要なフィールドを取得
- エラーハンドリング（ファイルが存在しない、必須フィールドがない等）

#### c. main関数の修正
- `validate_args()` の呼び出しを `load_settings()` に変更
- 出力ファイルは `output_dir/analysis_result2.json` に保存（現在と同じ動作）

### 3. エラーハンドリング
- settings.json が存在しない場合
- 必須フィールド（`analysis_result_file`, `output_dir`）が欠けている場合
- パスが無効な場合

### 4. ドキュメントの更新
- docstring の使用方法を更新
- エラーメッセージを適切に修正

## 利点
- 他のスクリプト（`main.py`など）と設定方法が統一される
- 複数回実行する際にパスを毎回指定する必要がなくなる
- プロジェクト全体の設定を一元管理できる

## 注意点
- 既存の `settings.json` ファイルのフォーマットとの互換性を保つ
- 相対パスの扱いに注意（settings.json からの相対パスとして解釈）