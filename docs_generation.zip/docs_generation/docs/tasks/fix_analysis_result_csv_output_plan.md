# fix_analysis_result.py CSV出力計画

## 概要
fix_analysis_result.pyの処理結果を一覧できるCSVファイルを出力する機能の実装計画。

## CSV出力形式

### ファイル名
- `analysis_result_implementation_summary.csv`
- 元のJSONファイルと同じディレクトリに出力

### CSVカラム構成

| カラム名 | 説明 | 例 |
|---------|------|-----|
| proto_id | プロトタイプ定義のID | proto_123 |
| file_path | ファイルパス | src/module/example.py |
| name | 関数/クラス名 | calculate_total |
| status | 実装の状態 | FOUND, NOT_FOUND, ALREADY_SET, WARNING |
| implemented_at | 実装のID（見つかった場合） | func_456 |
| notes | 備考（警告メッセージなど） | no implementation found in warnings |

### ステータスの定義
- **FOUND**: 実装が見つかり、implemented_atを新規追加した
- **NOT_FOUND**: 実装が見つからなかった
- **ALREADY_SET**: 既にimplemented_atが設定されていた
- **WARNING**: warningsフィールドに"no implementation found"が含まれていた

## 出力例

```csv
proto_id,file_path,name,status,implemented_at,notes
proto_001,src/auth/login.py,authenticate_user,FOUND,func_101,
proto_002,src/auth/login.py,validate_token,ALREADY_SET,func_102,
proto_003,src/data/parser.py,parse_json,NOT_FOUND,,実装が見つかりません
proto_004,src/utils/helper.py,format_date,WARNING,,"no implementation found in warnings"
```

## 実装方針

1. `fix_proto_records`関数を拡張して、各レコードの処理結果を詳細に記録
2. CSV出力用の新しい関数`save_csv_summary`を追加
3. 処理結果を構造化データとして保持し、最後にCSVに変換
4. エンコーディングはUTF-8（BOM付き）で日本語に対応

## 利点

- 実装の有無が一目で確認できる
- NOT_FOUNDのレコードをフィルタリングして、実装が必要な箇所を特定しやすい
- ファイルパスでソートして、同じファイル内の問題をまとめて確認できる
- Excelなどで開いて、フィルタリングや集計が容易