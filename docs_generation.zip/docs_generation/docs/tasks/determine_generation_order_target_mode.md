# determine_generation_order.py 機能追加要件：target_functionsモード

## 概要
既存の全関数対象モードに加えて、特定の関数のみを対象とした生成順序決定モードを追加する。

## 背景
- 現在の実装：analysis_result.json内のすべての関数について依存関係を解析し、生成順序を決定
- 新機能：target_functions.csvで指定された関数のみを対象として生成順序を決定

## 実行方法
### 既存モード（全関数対象）
```bash
python3 determine_generation_order.py <analysis_result.json の path> <出力先ディレクトリ path>
```

### 新モード（target_functions指定）
```bash
python3 determine_generation_order.py <analysis_result.json の path> <target_functions.csv の path> <出力先ディレクトリ path>
```

## 入力仕様
### target_functions.csv
- CSVファイル形式
- ヘッダー行あり
- 4列構成：
  1. **file_path**: ソースファイルのパス
  2. **func_type**: 関数タイプ（通常は"func"）
  3. **func_id**: 関数ID（func_xxx形式） ← この列を使用
  4. **func_name**: 関数名

#### 例：
```csv
file_path,func_type,func_id,func_name
sample_files/sudo/lib/util/regress/sudo_parseln/parseln_test.c,func,func_15614da23c0c41ac,main
sample_files/sudo/lib/zlib/gzwrite.c,func,func_1835e1dfa3206bd1,gz_init
```

## 処理フロー
1. **コマンドライン引数の解析**
   - 引数の数で動作モードを判定（2個：全関数モード、3個：target指定モード）

2. **target_functions.csvの読み込み**
   - CSVファイルを読み込み（ヘッダー行をスキップ）
   - 3列目のfunc_idを抽出
   - 対象関数IDのセットを作成
   - 存在しない関数IDがある場合は警告を出力

3. **依存関係の解析**
   - target_functionsに含まれる関数のみを対象
   - ただし、依存関係の解決では全関数情報を参照
   - target内の関数が依存する関数も考慮

4. **生成順序の決定**
   - 以下の2つのアプローチが考えられる：
     - **アプローチ1**: targetの関数とその依存先すべてを含めて順序決定
     - **アプローチ2**: targetの関数のみの相対的な順序を決定

5. **出力**
   - generation_order.csv：target_functionsに含まれる関数のみを出力

## 重要な考慮事項

### 依存関係の扱い
- target_functions内の関数Aが、target外の関数Bに依存している場合の扱い
  - 案1：関数Bも出力に含める（依存関係の完全性を保つ）
  - 案2：関数Aのみ出力（targetで指定された関数のみ）
  - 案3：警告を出して、関数Aと関数Bの両方を出力

### 循環依存
- target_functions内での循環依存の検出と報告
- target外との循環依存の扱い

### エラーハンドリング
- target_functions.csvが存在しない場合
- target_functions.csv内のIDがanalysis_result.jsonに存在しない場合
- 空のtarget_functions.csvの場合

## 実装方針の選択肢

### 案1：依存関係の完全性を重視
- target内の関数が依存するすべての関数を含めて出力
- メリット：生成時の依存関係が保証される
- デメリット：指定していない関数も出力される

### 案2：指定関数のみを厳密に出力
- target_functionsで指定された関数のみを出力
- メリット：ユーザーの意図通りの出力
- デメリット：依存関係が不完全になる可能性

### 案3：ハイブリッドアプローチ
- 基本はtarget関数のみ出力
- 依存関係で必要な関数がある場合は警告
- オプションで依存先も含めるか選択可能

## 推奨実装
案3のハイブリッドアプローチを推奨。理由：
- ユーザーの意図を尊重しつつ、依存関係の問題を可視化
- 必要に応じて完全な依存関係を含められる柔軟性

## 出力形式
### generation_order.csv
- 既存モードと同じ形式を維持
- target_functionsで指定された関数のみを含む
- 形式：
  ```csv
  order,id,name,type,file_path
  1,func_xxx,function_name,func,path/to/file.c
  ```

## 実装の詳細
1. **コマンドライン引数の判定**
   - `len(sys.argv) == 3`: 全関数モード
   - `len(sys.argv) == 4`: target指定モード

2. **target関数の依存解析**
   - target内の関数間の依存関係を優先
   - target外への依存がある場合：
     - 警告メッセージを表示
     - 依存先の関数名とIDを列挙
     - 出力には含めない（ユーザーが明示的に指定した関数のみ）

3. **トポロジカルソート**
   - target関数のみでサブグラフを構成
   - 通常通りトポロジカルソートを実行
   - target外への依存は無視（ただし警告は出力）