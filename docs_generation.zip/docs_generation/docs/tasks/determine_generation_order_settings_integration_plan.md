# determine_generation_order.py の settings.json 統合計画

## 目的
`determine_generation_order.py`をコマンドライン引数から`settings.json`から設定を読み込むように変更する

## 現在の状況

### コマンドライン引数の使用方法（現状）
1. **全関数モード**: 
   ```bash
   python3 determine_generation_order.py <analysis_result.json> <出力ディレクトリ>
   ```

2. **target指定モード**:
   ```bash
   python3 determine_generation_order.py <analysis_result.json> <target_functions.csv> <出力ディレクトリ>
   ```

### settings.jsonの構造
```json
{
  "output_dir": "./generated_docs_0806_01/",
  "c_source_dir": "./sample_files/",
  "analysis_result_file": "./analysis_result.json",
  "target_paths_file": "./target_paths.txt"
}
```

## 変更計画

### 1. settings.jsonの構造（変更なし）
`settings.json`の構造は現状のままとし、`target_functions.csv`のパスは以下のルールで自動計算する：

```
target_functions_file = {output_dir}/target_functions.csv
```

現在の`settings.json`：
```json
{
  "output_dir": "./generated_docs_0806_01/",
  "c_source_dir": "./sample_files/",
  "analysis_result_file": "./analysis_result.json",
  "target_paths_file": "./target_paths.txt"
}
```

例：`output_dir`が`"./generated_docs_0806_01/"`の場合、
`target_functions_file`は`"./generated_docs_0806_01/target_functions.csv"`となる。

### 2. determine_generation_order.pyの変更内容

#### 2.1 新規追加するインポートと関数
- `from pathlib import Path`をインポートに追加
- `load_settings(settings_path: str) -> Dict`: settings.jsonを読み込む関数

#### 2.2 main()関数の変更
- コマンドライン引数の処理を変更（`--all`フラグの確認）
- settings.jsonを読み込み、そこから必要な情報を取得
- `target_functions_file`を`Path(output_dir) / "target_functions.csv"`として計算
- `--all`フラグの有無でモードを判定
- target指定モードの場合、計算したtarget_functions_fileの存在を確認

#### 2.3 コマンドライン引数の新仕様
1. **全関数モード**:
   ```bash
   python3 determine_generation_order.py --all
   ```

2. **target指定モード**（デフォルト）:
   ```bash
   python3 determine_generation_order.py
   ```

- 引数なしまたは`--all`以外の場合はtarget指定モード
- `--all`フラグが指定された場合は全関数モード
- 両モードとも`./settings.json`から設定を読み込む（カスタムパスのサポートは将来的に検討）

### 3. 実装手順

1. **settings.jsonの読み込み関数を追加**
   - JSONファイルの読み込みとエラーハンドリング
   - 必須フィールドの検証

2. **main()関数の修正**
   - コマンドライン引数の処理を簡素化（`--all`フラグのチェック）
   - settings.jsonから設定を読み込む
   - `target_functions_file`を`Path(output_dir) / "target_functions.csv"`として計算
   - `--all`フラグの有無でモードを判定
   - target指定モードの場合は計算したtarget_functions_fileの存在確認

3. **エラーハンドリングの追加**
   - settings.jsonに必須フィールドがない場合のエラー処理
   - ファイルパスの検証

### 4. 互換性の考慮
- 既存のコマンドライン引数形式（2つまたは3つの引数）が検出された場合は、非推奨警告を表示
- 新しい形式（引数なしまたは`--all`）への移行を促す

### 5. テスト項目
- settings.jsonからの正常な読み込み
- `--all`フラグありの場合の全関数モード動作確認
- `--all`フラグなしの場合のtarget指定モード動作確認
- target_functions_fileが存在しない場合のエラー処理確認
- エラーケース（settings.jsonが存在しない、必須フィールドがない等）の確認
- 既存のコマンドライン引数形式での動作確認（互換性と非推奨警告）

## 期待される効果
- 設定の一元管理により、プロジェクト全体の一貫性が向上
- コマンドライン引数の簡素化により、使いやすさが向上
- 他のスクリプト（main.py、fix_analysis_result.py）との統一性が確保される