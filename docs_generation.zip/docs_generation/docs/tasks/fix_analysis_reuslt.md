# analysis_result.json に不足している情報について

type=proto となっている関数はC言語のプロトタイプ宣言を意味しており、基本的にどこかに実装が書いてある。
本来 type=proto のものに関しては implemented_at フィールドが存在するが、そのフィールドがない場合がある。
この implemented_at 情報の不足は問題であるため、修正する必要がある。
修正後、すべての proto=type のレコードは implemented_at を持つべきであるが、一部解決できないものもあり、これについては後述。

## 具体例:

implemented_at フィールドが存在する、正しい例:
```json
  {
    "id": "proto_976d48f32b579ae5",
    "type": "proto",
    "name": "mysetgrent",
    "file_path": "sample_files/sudo/plugins/group_file/getgrent.c",
    "line_start": 48,
    "line_end": 48,
    "signature": "void mysetgrent(void)",
    "implemented_at": "func_8df6bfc7cd92e400"
  },
```

implemented_at フィールドが存在しない、修正が必要な例:
```json
  {
    "id": "proto_dd40f99ca64a6b1e",
    "type": "proto",
    "name": "main",
    "file_path": "sample_files/sudo/plugins/group_file/plugin_test.c",
    "line_start": 32,
    "line_end": 32,
    "signature": "__dso_public main(int argc, char *argv[])"
  },
```

# implemented_at の追い方

implemented_at の追い方は複数パターンある。

## 同一の file_path かつ、同一の name の type=func が存在するケース

type=proto のレコードと同一の file_path かつ name かつ type=func が存在する場合、そのレコードの func_xxx を implemented_at フィールドに追加しレコードを更新する。

具体例: 
```json
  {
    "id": "proto_dd40f99ca64a6b1e",
    "type": "proto",
    "name": "main",
    "file_path": "sample_files/sudo/plugins/group_file/plugin_test.c",
    "line_start": 32,
    "line_end": 32,
    "signature": "__dso_public main(int argc, char *argv[])"
  },
```

このレコードは type=proto であるが、implemented_at フィールドが存在しない。
この場合、このレコードと同一の file_path に、同一の name があるか analysis_result.json から調べる。
今回のケースでは、file_path="sample_files/sudo/plugins/group_file/plugin_test.c", name="main" であるため、これを analysis_result.json から調べると、

```json
  {
    "id": "func_54dacc2cf12a5acb",
    "type": "func",
    "name": "main",
    "file_path": "sample_files/sudo/plugins/group_file/plugin_test.c",
    "line_start": 170,
    "line_end": 211,
    "signature": "int main(int argc, char *argv[])",
    "calls": [
      "func_f1937666ce8ef86b",
      "ext_getpwnam",
      "func_8cc3f69937c4a26c",
      "ext_printf",
      "ext_fprintf",
      "ext_strchr",
      "func_8d412ba3d1fc20d1",
      "func_a4833b1925a67aa6",
      "ext_getopt",
      "ext_exit"
    ]
  },
```

このレコードがヒットする。（同一の file_path, name であることが確認できる）
よって func_54dacc2cf12a5acb を proto_dd40f99ca64a6b1e の実装とみなし、

```json
  {
    "id": "proto_dd40f99ca64a6b1e",
    "type": "proto",
    "name": "main",
    "file_path": "sample_files/sudo/plugins/group_file/plugin_test.c",
    "line_start": 32,
    "line_end": 32,
    "signature": "__dso_public main(int argc, char *argv[])",
    "implemented_at": "func_54dacc2cf12a5acb"
  },
```

のように implemented_at フィールドを追加し更新する。

## 実装が存在しない (no implementation found) ケース

warnings フィールドに "no implementation found" とある場合、実装がないので対応不要。

具体例: 
```json
  {
    "id": "proto_f0827c08aad8a69d",
    "type": "proto",
    "name": "OF",
    "file_path": "sample_files/sudo/lib/zlib/crc32.c",
    "line_start": 60,
    "line_end": 60,
    "signature": "make_crc_table OF((void))",
    "warnings": [
      "Function 'OF' has prototype declaration but no implementation found"
    ]
  },
```

この type=proto には実装がない（no implementation found）ので、対応不要。

## 上記以外のケース

上記のいずれのケースにもマッチしない場合、想定外なので、raise errorする。
