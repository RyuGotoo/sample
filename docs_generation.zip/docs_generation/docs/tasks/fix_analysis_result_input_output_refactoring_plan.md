# fix_analysis_result.py 入出力パス変更計画

## 現状分析

### 現在の実装
- `settings.json`から設定を読み込む
- `analysis_result_file`と`output_dir`を使用
- 出力は`output_dir`配下の`analysis_result.json`
- バックアップも`output_dir`配下に作成

### 現在のフロー
1. `settings.json`から`analysis_result_file`と`output_dir`を読み取り
2. 入力ファイルを読み込み
3. `output_dir`にバックアップと修正済みファイルを保存

## 新要件

### 変更後の仕様
- コマンドライン引数で`analysis_result.json`のパスを直接指定
- 実行例: `python3 fix_analysis_result.py ./analysis_result.json`
- 出力ファイル名: 元ファイルと同階層の`analysis_result_fixed.json`

### 変更後のフロー
1. コマンドライン引数から入力ファイルパスを取得
2. 入力ファイルの存在確認
3. 出力ファイルパスを生成（同階層に`_fixed`サフィックス付き）
4. バックアップは作成しない（元ファイルはそのまま保持）

## 実装計画

### 1. コマンドライン引数処理の追加
- `argparse`または`sys.argv`を使用
- 引数の検証（ファイル存在確認）

### 2. 入出力パス処理の変更
- `load_settings()`関数の廃止
- 新しい`parse_arguments()`関数を作成
- 出力パス生成ロジックの実装

### 3. メイン関数の変更
- settings.json依存の削除
- 新しい引数処理フローに変更
- バックアップ処理の削除

### 4. 関数の修正対象
- `load_settings()` → `parse_arguments()`に置換
- `main()`関数の入出力パス処理変更
- バックアップ関連コードの削除

### 5. エラーハンドリング
- 引数不足エラー
- ファイル存在確認エラー
- 出力ディレクトリ作成エラー

## 影響範囲

### 削除される機能
- settings.json依存
- バックアップ機能
- output_dir指定

### 新しく追加される機能
- コマンドライン引数パース
- 自動出力ファイル名生成
- 同階層出力

## テスト項目

1. 正常ケース: `python3 fix_analysis_result.py ./analysis_result.json`
2. ファイル不存在エラー
3. 引数不足エラー
4. 権限不足エラー（出力ディレクトリ）
5. JSONパースエラー