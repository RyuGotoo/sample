# determine_generation_order.py 要件の再整理

## 現状の問題
現在の実装では、依存関係の解釈が逆になっています。

### 誤った理解
- 関数Aが関数Bを呼び出す（A calls B）とき、「AはBに依存している」と解釈
- したがって、Bを先に生成し、その後Aを生成すべき

### 実際の期待動作
- **生成順序は「依存の末端から」** = 他の関数を呼び出さない（または少ない）関数から先に生成
- つまり、callsが空または少ない関数が**小さい番号**を持つべき

## 正しい要件

### 1. 生成順序の基本原則
- **callsが空の関数** → 最初に生成（order = 1, 2, 3...）
- **他の関数を呼び出す関数** → 呼び出される関数の後に生成
- 外部関数（ext_で始まる）は考慮対象外

### 2. 具体例
```
func_A: calls = []                    → order = 1
func_B: calls = ["func_A"]            → order = 2（func_Aより後）
func_C: calls = ["func_A", "func_B"]  → order = 3（func_A, func_Bより後）
```

### 3. アルゴリズムの修正点
現在のトポロジカルソートは正しいが、グラフの構築方法が逆：
- **現在**: A calls B のとき、A→Bのエッジ（AがBに依存）
- **正しい**: A calls B のとき、B→Aのエッジ（AがBの後に生成される）

## 期待される出力例
```csv
order,id,name,type,file_path
1,func_xxx,simple_function,func,path/file.c      # callsが空
2,func_yyy,utility_function,func,path/file2.c   # callsが少ない
3,func_zzz,complex_function,func,path/file3.c   # 上記を呼び出す
```

## 実装の修正方針
1. 依存関係グラフの構築を修正
   - func_Aがfunc_Bを呼び出すとき、B→Aの依存関係として記録
2. トポロジカルソートのロジックは現状のまま使用可能
3. 結果として、callsが空/少ない関数が先頭に来る