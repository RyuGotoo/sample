あなたはC言語のエキスパートプログラマーです。
与えられたC言語の関数コードを分析し、その関数の詳細なドキュメントをXML形式で生成してください。
与えられたコードはFOXシステムの一部です。
FOX (FOreign eXchange system) は三井住友銀行が開発した為替ディーリングシステムです。FOXは2000年に、フロントシステム機能をメインフレームからUNIXシステムへ移行する際に開発された独自アプリケーションです。このシステムは取引発注から約定入力、執行、決済、照合に至る一連の取引処理をシステム化することで、STP（Straight Through Processing）を実現しています。
以下の手順に従って、思考プロセスを明確に示しながら作業を進めてください：

1. コードの初期分析:
  a. 関数名を特定し、記録します。
  b. パラメータと戻り値の型を確認します。
  c. コード内のコメントや命名規則から関数の目的を推測します。
1. 関数の動作分析:
  a. コードを一行ずつ読み、各部分の役割を理解します。
  b. 条件分岐、ループ、エラー処理などの制御構造を特定します。
  c. 外部リソース（データベース、ファイル）へのアクセスを確認します。
1. データベースアクセスの分析 (該当する場合):
  a. SQL文や関連するコードを特定します。
  b. クエリの目的と条件を分析します。
  c. 擬似SQLを構築し、変数や条件分岐を含めます。
1. 処理フローの構築:
  a. 関数の主要なステップを特定し、論理的な順序で並べます。
  b. 各ステップを簡潔な日本語で説明します。
  c. 条件分岐やループがある場合、それらを適切に表現します。
1. ドキュメントの生成:
  a. 分析結果に基づいて、各XML要素の内容を決定します。
  b. 不明確な点があれば、<不明>と明記します。
  c. 整形されたXMLを生成します。
1. 最終確認:
  a. 生成されたドキュメントを元のコードと照らし合わせて確認します。
  b. 矛盾や不適切な情報がないか確認します。
  c. 必要に応じて修正を行います。

以下の構造に従ってXML形式でドキュメントを生成してください：

```xml
<function>
  <name></name>
  <purpose></purpose>
  <summary></summary>
  <arguments>
    <arg>
      <name></name>
      <type></type>
      <description></description>
    </arg>
    <!-- 複数のパラメータがある場合は、この構造を繰り返してください -->
  </arguments>
  <return-value>
    <type></type>
    <description></description>
  </return-value>
  <remarks></remarks>
  <process-flow>
    <step>
      <description></description>
      <rationale></rationale>
    </step>
    <!-- 複数のステップがある場合は、この構造を繰り返してください -->
  </process-flow>
  <database-queries>
    <query>
      <description></description>
      <pseudo-sql></pseudo-sql>
    </query>
    <!-- 複数のクエリがある場合は、この構造を繰り返してください -->
  </database-queries>
</function>
```

## 各要素の詳細:

- `<name>`: 関数の正確な名前を記入してください。
- `<purpose>`: この関数が提供する主要な価値や解決する問題を簡潔に説明してください。
- `<summary>`: 関数の基本的な動作と、その動作がプロジェクトの全体的な目的にどう寄与するか。技術的な詳細は最小限にし、関数の役割や影響に焦点を当てます。
- `<arguments>`: 全てのパラメータを列挙し、それぞれの名前、型、説明を提供してください。
- `<return-value>`: 戻り値の型と説明を記入してください。
- `<remarks>`: 関数の動作に関する追加の重要な情報や注意点を記載してください。ただし、過度に詳細な実装の警告は避け、利用上の重要なポイントに絞ります。
- `<process-flow>`: 関数の処理の流れを日本語で連番で説明してください。各ステップを `<step>` タグで囲んでください。
  - `<step>`: 以下のサブ要素を含めて記載してください：
    - `<description>`: 各ステップの処理内容を日本語で説明
    - `<rationale>`: そのステップの根拠（何行目のどのような処理を根拠としたのか）を記載
- `<database-queries>`: データベースアクセス処理がある場合、それぞれのクエリについて以下を記載してください：
  - `<description>`: クエリの目的や条件を日本語で説明します。
  - `<pseudo-sql>`: 実際のSQLに近い形で、条件分岐を含めた擬似SQLを記述します。

## 注意事項:

- 情報が不明確または不足している場合は、推測せずに `<不明>` と記入してください。
- コード内のコメントや命名規則から推測できる情報がある場合は、それを活用してください。ただしコメントに関しては古い誤ったものが残っているので注意して下さい。
- ハルシネーション（不正確な情報の生成）を避けるために、直接コードから読み取れる情報に基づいていなければなりません。
- 上位ドキュメントの作成に役立つ重要な情報を含むようにし、過度に詳細な技術的内容は避けてください。
- 生成したドキュメントが完全で正確であることを確認するため、入力されたコードを再度確認してください。
- XMLの構造が正しいことを確認し、整形されたXMLを出力してください。

## C言語コード:

```c
int
fork_pty(struct command_details *details, int sv[], sigset_t *omask)
{
    struct command_status cstat;
    int io_pipe[3][2];
    sigaction_t sa;
    sigset_t mask;
    pid_t child;
    debug_decl(fork_pty, SUDO_DEBUG_EXEC);

    ppgrp = getpgrp(); /* parent's pgrp, so child can signal us */

    memset(&sa, 0, sizeof(sa));
    sigemptyset(&sa.sa_mask);

    if (io_fds[SFD_USERTTY] != -1) {
	sa.sa_flags = SA_RESTART;
	sa.sa_handler = sigwinch;
	if (sudo_sigaction(SIGWINCH, &sa, NULL) != 0)
	    sudo_warn(U_("unable to set handler for signal %d"), SIGWINCH);
    }

    /* So we can block tty-generated signals */
    sigemptyset(&ttyblock);
    sigaddset(&ttyblock, SIGINT);
    sigaddset(&ttyblock, SIGQUIT);
    sigaddset(&ttyblock, SIGTSTP);
    sigaddset(&ttyblock, SIGTTIN);
    sigaddset(&ttyblock, SIGTTOU);

    /*
     * Setup stdin/stdout/stderr for child, to be duped after forking.
     * In background mode there is no stdin.
     */
    if (!ISSET(details->flags, CD_BACKGROUND))
	io_fds[SFD_STDIN] = io_fds[SFD_SLAVE];
    io_fds[SFD_STDOUT] = io_fds[SFD_SLAVE];
    io_fds[SFD_STDERR] = io_fds[SFD_SLAVE];

    if (io_fds[SFD_USERTTY] != -1) {
	/* Read from /dev/tty, write to pty master */
	if (!ISSET(details->flags, CD_BACKGROUND)) {
	    io_buf_new(io_fds[SFD_USERTTY], io_fds[SFD_MASTER],
		log_ttyin, &iobufs);
	}

	/* Read from pty master, write to /dev/tty */
	io_buf_new(io_fds[SFD_MASTER], io_fds[SFD_USERTTY],
	    log_ttyout, &iobufs);

	/* Are we the foreground process? */
	foreground = tcgetpgrp(io_fds[SFD_USERTTY]) == ppgrp;
    }

    /*
     * If either stdin, stdout or stderr is not a tty we use a pipe
     * to interpose ourselves instead of duping the pty fd.
     */
    memset(io_pipe, 0, sizeof(io_pipe));
    if (io_fds[SFD_STDIN] == -1 || !isatty(STDIN_FILENO)) {
	sudo_debug_printf(SUDO_DEBUG_INFO, "stdin not a tty, creating a pipe");
	pipeline = true;
	if (pipe(io_pipe[STDIN_FILENO]) != 0)
	    sudo_fatal(U_("unable to create pipe"));
	io_buf_new(STDIN_FILENO, io_pipe[STDIN_FILENO][1],
	    log_stdin, &iobufs);
	io_fds[SFD_STDIN] = io_pipe[STDIN_FILENO][0];
    }
    if (io_fds[SFD_STDOUT] == -1 || !isatty(STDOUT_FILENO)) {
	sudo_debug_printf(SUDO_DEBUG_INFO, "stdout not a tty, creating a pipe");
	pipeline = true;
	if (pipe(io_pipe[STDOUT_FILENO]) != 0)
	    sudo_fatal(U_("unable to create pipe"));
	io_buf_new(io_pipe[STDOUT_FILENO][0], STDOUT_FILENO,
	    log_stdout, &iobufs);
	io_fds[SFD_STDOUT] = io_pipe[STDOUT_FILENO][1];
    }
    if (io_fds[SFD_STDERR] == -1 || !isatty(STDERR_FILENO)) {
	sudo_debug_printf(SUDO_DEBUG_INFO, "stderr not a tty, creating a pipe");
	if (pipe(io_pipe[STDERR_FILENO]) != 0)
	    sudo_fatal(U_("unable to create pipe"));
	io_buf_new(io_pipe[STDERR_FILENO][0], STDERR_FILENO,
	    log_stderr, &iobufs);
	io_fds[SFD_STDERR] = io_pipe[STDERR_FILENO][1];
    }

    /* We don't want to receive SIGTTIN/SIGTTOU, getting EIO is preferable. */
    sa.sa_handler = SIG_IGN;
    if (sudo_sigaction(SIGTTIN, &sa, NULL) != 0)
	sudo_warn(U_("unable to set handler for signal %d"), SIGTTIN);
    if (sudo_sigaction(SIGTTOU, &sa, NULL) != 0)
	sudo_warn(U_("unable to set handler for signal %d"), SIGTTOU);

    /* Job control signals to relay from parent to child. */
    sigfillset(&sa.sa_mask);
    sa.sa_flags = SA_INTERRUPT; /* do not restart syscalls */
#ifdef SA_SIGINFO
    sa.sa_flags |= SA_SIGINFO;
    sa.sa_sigaction = handler;
#else
    sa.sa_handler = handler;
#endif
    if (sudo_sigaction(SIGCHLD, &sa, NULL) != 0)
	sudo_warn(U_("unable to set handler for signal %d"), SIGCHLD);
    if (sudo_sigaction(SIGTSTP, &sa, NULL) != 0)
	sudo_warn(U_("unable to set handler for signal %d"), SIGTSTP);

    if (foreground) {
	/* Copy terminal attrs from user tty -> pty slave. */
	if (sudo_term_copy(io_fds[SFD_USERTTY], io_fds[SFD_SLAVE])) {
	    tty_initialized = true;
	    sync_ttysize(io_fds[SFD_USERTTY], io_fds[SFD_SLAVE]);
	}

	/* Start out in raw mode unless part of a pipeline or backgrounded. */
	if (!pipeline && !ISSET(details->flags, CD_EXEC_BG)) {
	    if (sudo_term_raw(io_fds[SFD_USERTTY], 0))
		ttymode = TERM_RAW;
	}
    }

    /*
     * Block some signals until cmnd_pid is set in the parent to avoid a
     * race between exec of the command and receipt of a fatal signal from it.
     */
    sigemptyset(&mask);
    sigaddset(&mask, SIGTERM);
    sigaddset(&mask, SIGHUP);
    sigaddset(&mask, SIGINT);
    sigaddset(&mask, SIGQUIT);
    sigprocmask(SIG_BLOCK, &mask, omask);

    child = sudo_debug_fork();
    switch (child) {
    case -1:
	sudo_fatal(U_("unable to fork"));
	break;
    case 0:
	/* child */
	close(sv[0]);
	close(signal_pipe[0]);
	close(signal_pipe[1]);
	(void)fcntl(sv[1], F_SETFD, FD_CLOEXEC);
	sigprocmask(SIG_SETMASK, omask, NULL);
	/* Close the other end of the stdin/stdout/stderr pipes and exec. */
	if (io_pipe[STDIN_FILENO][1])
	    close(io_pipe[STDIN_FILENO][1]);
	if (io_pipe[STDOUT_FILENO][0])
	    close(io_pipe[STDOUT_FILENO][0]);
	if (io_pipe[STDERR_FILENO][0])
	    close(io_pipe[STDERR_FILENO][0]);
	exec_monitor(details, sv[1]);
	cstat.type = CMD_ERRNO;
	cstat.val = errno;
	ignore_result(send(sv[1], &cstat, sizeof(cstat), 0));
	_exit(1);
    }

    /* Close the other end of the stdin/stdout/stderr pipes. */
    if (io_pipe[STDIN_FILENO][0])
	close(io_pipe[STDIN_FILENO][0]);
    if (io_pipe[STDOUT_FILENO][1])
	close(io_pipe[STDOUT_FILENO][1]);
    if (io_pipe[STDERR_FILENO][1])
	close(io_pipe[STDERR_FILENO][1]);

    debug_return_int(child);
}
```

## 外部関数情報:

**sample_func**:
  目的: sample
  概要: len(sys_prompt): 960, len(user_prompt): 10209

**sample_func**:
  目的: sample
  概要: len(sys_prompt): 960, len(user_prompt): 3866

**sample_func**:
  目的: sample
  概要: len(sys_prompt): 960, len(user_prompt): 3385

**sample_func**:
  目的: sample
  概要: len(sys_prompt): 960, len(user_prompt): 3127
