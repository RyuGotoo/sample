あなたはC言語のエキスパートプログラマーです。
与えられたC言語の関数コードを分析し、その関数の詳細なドキュメントをXML形式で生成してください。
与えられたコードはFOXシステムの一部です。
FOX (FOreign eXchange system) は三井住友銀行が開発した為替ディーリングシステムです。FOXは2000年に、フロントシステム機能をメインフレームからUNIXシステムへ移行する際に開発された独自アプリケーションです。このシステムは取引発注から約定入力、執行、決済、照合に至る一連の取引処理をシステム化することで、STP（Straight Through Processing）を実現しています。
以下の手順に従って、思考プロセスを明確に示しながら作業を進めてください：

1. コードの初期分析:
  a. 関数名を特定し、記録します。
  b. パラメータと戻り値の型を確認します。
  c. コード内のコメントや命名規則から関数の目的を推測します。
1. 関数の動作分析:
  a. コードを一行ずつ読み、各部分の役割を理解します。
  b. 条件分岐、ループ、エラー処理などの制御構造を特定します。
  c. 外部リソース（データベース、ファイル）へのアクセスを確認します。
1. データベースアクセスの分析 (該当する場合):
  a. SQL文や関連するコードを特定します。
  b. クエリの目的と条件を分析します。
  c. 擬似SQLを構築し、変数や条件分岐を含めます。
1. 処理フローの構築:
  a. 関数の主要なステップを特定し、論理的な順序で並べます。
  b. 各ステップを簡潔な日本語で説明します。
  c. 条件分岐やループがある場合、それらを適切に表現します。
1. ドキュメントの生成:
  a. 分析結果に基づいて、各XML要素の内容を決定します。
  b. 不明確な点があれば、<不明>と明記します。
  c. 整形されたXMLを生成します。
1. 最終確認:
  a. 生成されたドキュメントを元のコードと照らし合わせて確認します。
  b. 矛盾や不適切な情報がないか確認します。
  c. 必要に応じて修正を行います。

以下の構造に従ってXML形式でドキュメントを生成してください：

```xml
<function>
  <name></name>
  <purpose></purpose>
  <summary></summary>
  <arguments>
    <arg>
      <name></name>
      <type></type>
      <description></description>
    </arg>
    <!-- 複数のパラメータがある場合は、この構造を繰り返してください -->
  </arguments>
  <return-value>
    <type></type>
    <description></description>
  </return-value>
  <remarks></remarks>
  <process-flow>
    <step>
      <description></description>
      <rationale></rationale>
    </step>
    <!-- 複数のステップがある場合は、この構造を繰り返してください -->
  </process-flow>
  <database-queries>
    <query>
      <description></description>
      <pseudo-sql></pseudo-sql>
    </query>
    <!-- 複数のクエリがある場合は、この構造を繰り返してください -->
  </database-queries>
</function>
```

## 各要素の詳細:

- `<name>`: 関数の正確な名前を記入してください。
- `<purpose>`: この関数が提供する主要な価値や解決する問題を簡潔に説明してください。
- `<summary>`: 関数の基本的な動作と、その動作がプロジェクトの全体的な目的にどう寄与するか。技術的な詳細は最小限にし、関数の役割や影響に焦点を当てます。
- `<arguments>`: 全てのパラメータを列挙し、それぞれの名前、型、説明を提供してください。
- `<return-value>`: 戻り値の型と説明を記入してください。
- `<remarks>`: 関数の動作に関する追加の重要な情報や注意点を記載してください。ただし、過度に詳細な実装の警告は避け、利用上の重要なポイントに絞ります。
- `<process-flow>`: 関数の処理の流れを日本語で連番で説明してください。各ステップを `<step>` タグで囲んでください。
  - `<step>`: 以下のサブ要素を含めて記載してください：
    - `<description>`: 各ステップの処理内容を日本語で説明
    - `<rationale>`: そのステップの根拠（何行目のどのような処理を根拠としたのか）を記載
- `<database-queries>`: データベースアクセス処理がある場合、それぞれのクエリについて以下を記載してください：
  - `<description>`: クエリの目的や条件を日本語で説明します。
  - `<pseudo-sql>`: 実際のSQLに近い形で、条件分岐を含めた擬似SQLを記述します。

## 注意事項:

- 情報が不明確または不足している場合は、推測せずに `<不明>` と記入してください。
- コード内のコメントや命名規則から推測できる情報がある場合は、それを活用してください。ただしコメントに関しては古い誤ったものが残っているので注意して下さい。
- ハルシネーション（不正確な情報の生成）を避けるために、直接コードから読み取れる情報に基づいていなければなりません。
- 上位ドキュメントの作成に役立つ重要な情報を含むようにし、過度に詳細な技術的内容は避けてください。
- 生成したドキュメントが完全で正確であることを確認するため、入力されたコードを再度確認してください。
- XMLの構造が正しいことを確認し、整形されたXMLを出力してください。

## C言語コード:

```c
static int
exec_monitor(struct command_details *details, int backchannel)
{
    struct command_status cstat;
    struct sudo_event_base *evbase;
    struct monitor_closure mc;
    sigaction_t sa;
    int errpipe[2], n;
    debug_decl(exec_monitor, SUDO_DEBUG_EXEC);

    /* Close unused fds. */
    if (io_fds[SFD_MASTER] != -1)
	close(io_fds[SFD_MASTER]);
    if (io_fds[SFD_USERTTY] != -1)
	close(io_fds[SFD_USERTTY]);

    /*
     * We use a pipe to atomically handle signal notification within
     * the event loop.
     */
    if (pipe_nonblock(signal_pipe) != 0)
	sudo_fatal(U_("unable to create pipe"));

    /* Reset SIGWINCH and SIGALRM. */
    memset(&sa, 0, sizeof(sa));
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART;
    sa.sa_handler = SIG_DFL;
    if (sudo_sigaction(SIGWINCH, &sa, NULL) != 0)
	sudo_warn(U_("unable to set handler for signal %d"), SIGWINCH);
    if (sudo_sigaction(SIGALRM, &sa, NULL) != 0)
	sudo_warn(U_("unable to set handler for signal %d"), SIGALRM);

    /* Ignore any SIGTTIN or SIGTTOU we get. */
    sa.sa_handler = SIG_IGN;
    if (sudo_sigaction(SIGTTIN, &sa, NULL) != 0)
	sudo_warn(U_("unable to set handler for signal %d"), SIGTTIN);
    if (sudo_sigaction(SIGTTOU, &sa, NULL) != 0)
	sudo_warn(U_("unable to set handler for signal %d"), SIGTTOU);

    /* Block all signals in mon_handler(). */
    sigfillset(&sa.sa_mask);

    /* Note: HP-UX poll() will not be interrupted if SA_RESTART is set. */
    sa.sa_flags = SA_INTERRUPT;
#ifdef SA_SIGINFO
    sa.sa_flags |= SA_SIGINFO;
    sa.sa_sigaction = mon_handler;
#else
    sa.sa_handler = mon_handler;
#endif
    if (sudo_sigaction(SIGCHLD, &sa, NULL) != 0)
	sudo_warn(U_("unable to set handler for signal %d"), SIGCHLD);

    /* Catch common signals so we can cleanup properly. */
    sa.sa_flags = SA_RESTART;
#ifdef SA_SIGINFO
    sa.sa_flags |= SA_SIGINFO;
    sa.sa_sigaction = mon_handler;
#else
    sa.sa_handler = mon_handler;
#endif
    if (sudo_sigaction(SIGHUP, &sa, NULL) != 0)
	sudo_warn(U_("unable to set handler for signal %d"), SIGHUP);
    if (sudo_sigaction(SIGINT, &sa, NULL) != 0)
	sudo_warn(U_("unable to set handler for signal %d"), SIGINT);
    if (sudo_sigaction(SIGQUIT, &sa, NULL) != 0)
	sudo_warn(U_("unable to set handler for signal %d"), SIGQUIT);
    if (sudo_sigaction(SIGTERM, &sa, NULL) != 0)
	sudo_warn(U_("unable to set handler for signal %d"), SIGTERM);
    if (sudo_sigaction(SIGTSTP, &sa, NULL) != 0)
	sudo_warn(U_("unable to set handler for signal %d"), SIGTSTP);
    if (sudo_sigaction(SIGUSR1, &sa, NULL) != 0)
	sudo_warn(U_("unable to set handler for signal %d"), SIGUSR1);
    if (sudo_sigaction(SIGUSR2, &sa, NULL) != 0)
	sudo_warn(U_("unable to set handler for signal %d"), SIGUSR2);

    /*
     * Start a new session with the parent as the session leader
     * and the slave pty as the controlling terminal.
     * This allows us to be notified when the command has been suspended.
     */
    if (setsid() == -1) {
	sudo_warn("setsid");
	goto bad;
    }
    if (io_fds[SFD_SLAVE] != -1) {
#ifdef TIOCSCTTY
	if (ioctl(io_fds[SFD_SLAVE], TIOCSCTTY, NULL) != 0)
	    sudo_fatal(U_("unable to set controlling tty"));
#else
	/* Set controlling tty by reopening slave. */
	if ((n = open(slavename, O_RDWR)) >= 0)
	    close(n);
#endif
    }

    mon_pgrp = getpgrp();	/* save a copy of our process group */

    /*
     * If stdin/stdout is not a tty, start command in the background
     * since it might be part of a pipeline that reads from /dev/tty.
     * In this case, we rely on the command receiving SIGTTOU or SIGTTIN
     * when it needs access to the controlling tty.
     */
    if (pipeline)
	foreground = false;

    /* Start command and wait for it to stop or exit */
    if (pipe(errpipe) == -1)
	sudo_fatal(U_("unable to create pipe"));
    cmnd_pid = sudo_debug_fork();
    if (cmnd_pid == -1) {
	sudo_warn(U_("unable to fork"));
	goto bad;
    }
    if (cmnd_pid == 0) {
	/* We pass errno back to our parent via pipe on exec failure. */
	close(backchannel);
	close(signal_pipe[0]);
	close(signal_pipe[1]);
	close(errpipe[0]);
	(void)fcntl(errpipe[1], F_SETFD, FD_CLOEXEC);
	restore_signals();

	/* setup tty and exec command */
	exec_pty(details, &cstat, errpipe[1]);
	while (write(errpipe[1], &cstat, sizeof(cstat)) == -1) {
	    if (errno != EINTR)
		break;
	}
	_exit(1);
    }
    close(errpipe[1]);

    /* Send the command's pid to main sudo process. */
    cstat.type = CMD_PID;
    cstat.val = cmnd_pid;
    ignore_result(send(backchannel, &cstat, sizeof(cstat), 0));

    /* If any of stdin/stdout/stderr are pipes, close them in parent. */
    if (io_fds[SFD_STDIN] != io_fds[SFD_SLAVE])
	close(io_fds[SFD_STDIN]);
    if (io_fds[SFD_STDOUT] != io_fds[SFD_SLAVE])
	close(io_fds[SFD_STDOUT]);
    if (io_fds[SFD_STDERR] != io_fds[SFD_SLAVE])
	close(io_fds[SFD_STDERR]);

    /* Put command in its own process group. */
    cmnd_pgrp = cmnd_pid;
    setpgid(cmnd_pid, cmnd_pgrp);

    /* Make the command the foreground process for the pty slave. */
    if (foreground && !ISSET(details->flags, CD_EXEC_BG)) {
	do {
	    n = tcsetpgrp(io_fds[SFD_SLAVE], cmnd_pgrp);
	} while (n == -1 && errno == EINTR);
    }

    /*
     * Create new event base and register read events for the
     * signal pipe, error pipe, and backchannel.
     */
    evbase = sudo_ev_base_alloc();
    if (evbase == NULL)
	sudo_fatal(NULL);

    memset(&cstat, 0, sizeof(cstat));
    mc.cstat = &cstat;
    mc.evbase = evbase;
    mc.backchannel = backchannel;
    mc.alive = true;

    mc.signal_pipe_event = sudo_ev_alloc(signal_pipe[0],
	SUDO_EV_READ|SUDO_EV_PERSIST, mon_signal_pipe_cb, &mc);
    if (mc.signal_pipe_event == NULL)
	sudo_fatal(NULL);
    if (sudo_ev_add(evbase, mc.signal_pipe_event, NULL, false) == -1)
	sudo_fatal(U_("unable to add event to queue"));

    mc.errpipe_event = sudo_ev_alloc(errpipe[0],
	SUDO_EV_READ|SUDO_EV_PERSIST, mon_errpipe_cb, &mc);
    if (mc.errpipe_event == NULL)
	sudo_fatal(NULL);
    if (sudo_ev_add(evbase, mc.errpipe_event, NULL, false) == -1)
	sudo_fatal(U_("unable to add event to queue"));

    mc.backchannel_event = sudo_ev_alloc(backchannel,
	SUDO_EV_READ|SUDO_EV_PERSIST, mon_backchannel_cb, &mc);
    if (mc.backchannel_event == NULL)
	sudo_fatal(NULL);
    if (sudo_ev_add(evbase, mc.backchannel_event, NULL, false) == -1)
	sudo_fatal(U_("unable to add event to queue"));

    /*
     * Wait for errno on pipe, signal on backchannel or for SIGCHLD.
     * The event loop ends when the child is no longer running and
     * the error pipe is closed.
     */
    (void) sudo_ev_loop(evbase, 0);
    if (mc.alive) {
	/* XXX An error occurred, should send a message back. */
	sudo_debug_printf(SUDO_DEBUG_ERROR,
	    "Command still running after event loop exit, sending SIGKILL");
	kill(cmnd_pid, SIGKILL);
    } else {
	/* Send parent status. */
	send_status(backchannel, &cstat);
    }
    sudo_debug_exit_int(__func__, __FILE__, __LINE__, sudo_debug_subsys, 1);
    _exit(1);

bad:
    debug_return_int(errno);
}
```

## 外部関数情報:

**sample_func**:
  目的: sample
  概要: len(sys_prompt): 960, len(user_prompt): 3339

**sample_func**:
  目的: sample
  概要: len(sys_prompt): 960, len(user_prompt): 4094

**sample_func**:
  目的: sample
  概要: len(sys_prompt): 960, len(user_prompt): 3378

**sample_func**:
  目的: sample
  概要: len(sys_prompt): 960, len(user_prompt): 3139

**sample_func**:
  目的: sample
  概要: len(sys_prompt): 960, len(user_prompt): 3385
