あなたはC言語のエキスパートプログラマーです。
与えられたC言語の関数コードを分析し、その関数の詳細なドキュメントをXML形式で生成してください。
与えられたコードはFOXシステムの一部です。
FOX (FOreign eXchange system) は三井住友銀行が開発した為替ディーリングシステムです。FOXは2000年に、フロントシステム機能をメインフレームからUNIXシステムへ移行する際に開発された独自アプリケーションです。このシステムは取引発注から約定入力、執行、決済、照合に至る一連の取引処理をシステム化することで、STP（Straight Through Processing）を実現しています。
以下の手順に従って、思考プロセスを明確に示しながら作業を進めてください：

1. コードの初期分析:
  a. 関数名を特定し、記録します。
  b. パラメータと戻り値の型を確認します。
  c. コード内のコメントや命名規則から関数の目的を推測します。
1. 関数の動作分析:
  a. コードを一行ずつ読み、各部分の役割を理解します。
  b. 条件分岐、ループ、エラー処理などの制御構造を特定します。
  c. 外部リソース（データベース、ファイル）へのアクセスを確認します。
1. データベースアクセスの分析 (該当する場合):
  a. SQL文や関連するコードを特定します。
  b. クエリの目的と条件を分析します。
  c. 擬似SQLを構築し、変数や条件分岐を含めます。
1. 処理フローの構築:
  a. 関数の主要なステップを特定し、論理的な順序で並べます。
  b. 各ステップを簡潔な日本語で説明します。
  c. 条件分岐やループがある場合、それらを適切に表現します。
1. ドキュメントの生成:
  a. 分析結果に基づいて、各XML要素の内容を決定します。
  b. 不明確な点があれば、<不明>と明記します。
  c. 整形されたXMLを生成します。
1. 最終確認:
  a. 生成されたドキュメントを元のコードと照らし合わせて確認します。
  b. 矛盾や不適切な情報がないか確認します。
  c. 必要に応じて修正を行います。

以下の構造に従ってXML形式でドキュメントを生成してください：

```xml
<function>
  <name></name>
  <purpose></purpose>
  <summary></summary>
  <arguments>
    <arg>
      <name></name>
      <type></type>
      <description></description>
    </arg>
    <!-- 複数のパラメータがある場合は、この構造を繰り返してください -->
  </arguments>
  <return-value>
    <type></type>
    <description></description>
  </return-value>
  <remarks></remarks>
  <process-flow>
    <step>
      <description></description>
      <rationale></rationale>
    </step>
    <!-- 複数のステップがある場合は、この構造を繰り返してください -->
  </process-flow>
  <database-queries>
    <query>
      <description></description>
      <pseudo-sql></pseudo-sql>
    </query>
    <!-- 複数のクエリがある場合は、この構造を繰り返してください -->
  </database-queries>
</function>
```

## 各要素の詳細:

- `<name>`: 関数の正確な名前を記入してください。
- `<purpose>`: この関数が提供する主要な価値や解決する問題を簡潔に説明してください。
- `<summary>`: 関数の基本的な動作と、その動作がプロジェクトの全体的な目的にどう寄与するか。技術的な詳細は最小限にし、関数の役割や影響に焦点を当てます。
- `<arguments>`: 全てのパラメータを列挙し、それぞれの名前、型、説明を提供してください。
- `<return-value>`: 戻り値の型と説明を記入してください。
- `<remarks>`: 関数の動作に関する追加の重要な情報や注意点を記載してください。ただし、過度に詳細な実装の警告は避け、利用上の重要なポイントに絞ります。
- `<process-flow>`: 関数の処理の流れを日本語で連番で説明してください。各ステップを `<step>` タグで囲んでください。
  - `<step>`: 以下のサブ要素を含めて記載してください：
    - `<description>`: 各ステップの処理内容を日本語で説明
    - `<rationale>`: そのステップの根拠（何行目のどのような処理を根拠としたのか）を記載
- `<database-queries>`: データベースアクセス処理がある場合、それぞれのクエリについて以下を記載してください：
  - `<description>`: クエリの目的や条件を日本語で説明します。
  - `<pseudo-sql>`: 実際のSQLに近い形で、条件分岐を含めた擬似SQLを記述します。

## 注意事項:

- 情報が不明確または不足している場合は、推測せずに `<不明>` と記入してください。
- コード内のコメントや命名規則から推測できる情報がある場合は、それを活用してください。ただしコメントに関しては古い誤ったものが残っているので注意して下さい。
- ハルシネーション（不正確な情報の生成）を避けるために、直接コードから読み取れる情報に基づいていなければなりません。
- 上位ドキュメントの作成に役立つ重要な情報を含むようにし、過度に詳細な技術的内容は避けてください。
- 生成したドキュメントが完全で正確であることを確認するため、入力されたコードを再度確認してください。
- XMLの構造が正しいことを確認し、整形されたXMLを出力してください。

## C言語コード:

```c
bool
exec_setup(struct command_details *details, const char *ptyname, int ptyfd)
{
    bool rval = false;
    debug_decl(exec_setup, SUDO_DEBUG_EXEC)

#ifdef HAVE_SELINUX
    if (ISSET(details->flags, CD_RBAC_ENABLED)) {
	if (selinux_setup(details->selinux_role, details->selinux_type,
	    ptyname ? ptyname : user_details.tty, ptyfd) == -1)
	    goto done;
    }
#endif

    if (details->pw != NULL) {
#ifdef HAVE_PROJECT_H
	set_project(details->pw);
#endif
#ifdef HAVE_PRIV_SET
	if (details->privs != NULL) {
	    if (setppriv(PRIV_SET, PRIV_INHERITABLE, details->privs) != 0) {
		sudo_warn("unable to set privileges");
		goto done;
	    }
	}
	if (details->limitprivs != NULL) {
	    if (setppriv(PRIV_SET, PRIV_LIMIT, details->limitprivs) != 0) {
		sudo_warn("unable to set limit privileges");
		goto done;
	    }
	} else if (details->privs != NULL) {
	    if (setppriv(PRIV_SET, PRIV_LIMIT, details->privs) != 0) {
		sudo_warn("unable to set limit privileges");
		goto done;
	    }
	}
#endif /* HAVE_PRIV_SET */

#ifdef HAVE_GETUSERATTR
	if (aix_prep_user(details->pw->pw_name, ptyname ? ptyname : user_details.tty) != 0) {
	    /* error message displayed by aix_prep_user */
	    goto done;
	}
#endif
#ifdef HAVE_LOGIN_CAP_H
	if (details->login_class) {
	    int flags;
	    login_cap_t *lc;

	    /*
	     * We only use setusercontext() to set the nice value and rlimits
	     * unless this is a login shell (sudo -i).
	     */
	    lc = login_getclass((char *)details->login_class);
	    if (!lc) {
		sudo_warnx(U_("unknown login class %s"), details->login_class);
		errno = ENOENT;
		goto done;
	    }
	    if (ISSET(sudo_mode, MODE_LOGIN_SHELL)) {
		/* Set everything except user, group and login name. */
		flags = LOGIN_SETALL;
		CLR(flags, LOGIN_SETGROUP|LOGIN_SETLOGIN|LOGIN_SETUSER|LOGIN_SETENV|LOGIN_SETPATH);
		CLR(details->flags, CD_SET_UMASK); /* LOGIN_UMASK instead */
	    } else {
		flags = LOGIN_SETRESOURCES|LOGIN_SETPRIORITY;
	    }
	    if (setusercontext(lc, details->pw, details->pw->pw_uid, flags)) {
		sudo_warn(U_("unable to set user context"));
		if (details->pw->pw_uid != ROOT_UID)
		    goto done;
	    }
	}
#endif /* HAVE_LOGIN_CAP_H */
    }

    if (ISSET(details->flags, CD_SET_GROUPS)) {
	/* set_user_groups() prints error message on failure. */
	if (!set_user_groups(details))
	    goto done;
    }

    if (ISSET(details->flags, CD_SET_PRIORITY)) {
	if (setpriority(PRIO_PROCESS, 0, details->priority) != 0) {
	    sudo_warn(U_("unable to set process priority"));
	    goto done;
	}
    }
    if (ISSET(details->flags, CD_SET_UMASK))
	(void) umask(details->umask);
    if (details->chroot) {
	if (chroot(details->chroot) != 0 || chdir("/") != 0) {
	    sudo_warn(U_("unable to change root to %s"), details->chroot);
	    goto done;
	}
    }

    /* 
     * Unlimit the number of processes since Linux's setuid() will
     * return EAGAIN if RLIMIT_NPROC would be exceeded by the uid switch.
     */
    unlimit_nproc();

#if defined(HAVE_SETRESUID)
    if (setresuid(details->uid, details->euid, details->euid) != 0) {
	sudo_warn(U_("unable to change to runas uid (%u, %u)"),
	    (unsigned int)details->uid, (unsigned int)details->euid);
	goto done;
    }
#elif defined(HAVE_SETREUID)
    if (setreuid(details->uid, details->euid) != 0) {
	sudo_warn(U_("unable to change to runas uid (%u, %u)"),
	    (unsigned int)details->uid, (unsigned int)details->euid);
	goto done;
    }
#else
    /* Cannot support real user ID that is different from effective user ID. */
    if (setuid(details->euid) != 0) {
	sudo_warn(U_("unable to change to runas uid (%u, %u)"),
	    (unsigned int)details->euid, (unsigned int)details->euid);
	goto done;
    }
#endif /* !HAVE_SETRESUID && !HAVE_SETREUID */

    /* Restore previous value of RLIMIT_NPROC. */
    restore_nproc();

    /*
     * Only change cwd if we have chroot()ed or the policy modules
     * specifies a different cwd.  Must be done after uid change.
     */
    if (details->cwd != NULL) {
	if (details->chroot || user_details.cwd == NULL ||
	    strcmp(details->cwd, user_details.cwd) != 0) {
	    /* Note: cwd is relative to the new root, if any. */
	    if (chdir(details->cwd) != 0) {
		sudo_warn(U_("unable to change directory to %s"), details->cwd);
		goto done;
	    }
	}
    }

    rval = true;

done:
    debug_return_bool(rval);
}
```

## 外部関数情報:

**sample_func**:
  目的: sample
  概要: len(sys_prompt): 960, len(user_prompt): 4306

**sample_func**:
  目的: sample
  概要: len(sys_prompt): 960, len(user_prompt): 3247

**sample_func**:
  目的: sample
  概要: len(sys_prompt): 960, len(user_prompt): 4408

**sample_func**:
  目的: sample
  概要: len(sys_prompt): 960, len(user_prompt): 3645

**sample_func**:
  目的: sample
  概要: len(sys_prompt): 960, len(user_prompt): 3009
