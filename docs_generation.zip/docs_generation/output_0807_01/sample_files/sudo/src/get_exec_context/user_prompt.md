あなたはC言語のエキスパートプログラマーです。
与えられたC言語の関数コードを分析し、その関数の詳細なドキュメントをXML形式で生成してください。
与えられたコードはFOXシステムの一部です。
FOX (FOreign eXchange system) は三井住友銀行が開発した為替ディーリングシステムです。FOXは2000年に、フロントシステム機能をメインフレームからUNIXシステムへ移行する際に開発された独自アプリケーションです。このシステムは取引発注から約定入力、執行、決済、照合に至る一連の取引処理をシステム化することで、STP（Straight Through Processing）を実現しています。
以下の手順に従って、思考プロセスを明確に示しながら作業を進めてください：

1. コードの初期分析:
  a. 関数名を特定し、記録します。
  b. パラメータと戻り値の型を確認します。
  c. コード内のコメントや命名規則から関数の目的を推測します。
1. 関数の動作分析:
  a. コードを一行ずつ読み、各部分の役割を理解します。
  b. 条件分岐、ループ、エラー処理などの制御構造を特定します。
  c. 外部リソース（データベース、ファイル）へのアクセスを確認します。
1. データベースアクセスの分析 (該当する場合):
  a. SQL文や関連するコードを特定します。
  b. クエリの目的と条件を分析します。
  c. 擬似SQLを構築し、変数や条件分岐を含めます。
1. 処理フローの構築:
  a. 関数の主要なステップを特定し、論理的な順序で並べます。
  b. 各ステップを簡潔な日本語で説明します。
  c. 条件分岐やループがある場合、それらを適切に表現します。
1. ドキュメントの生成:
  a. 分析結果に基づいて、各XML要素の内容を決定します。
  b. 不明確な点があれば、<不明>と明記します。
  c. 整形されたXMLを生成します。
1. 最終確認:
  a. 生成されたドキュメントを元のコードと照らし合わせて確認します。
  b. 矛盾や不適切な情報がないか確認します。
  c. 必要に応じて修正を行います。

以下の構造に従ってXML形式でドキュメントを生成してください：

```xml
<function>
  <name></name>
  <purpose></purpose>
  <summary></summary>
  <arguments>
    <arg>
      <name></name>
      <type></type>
      <description></description>
    </arg>
    <!-- 複数のパラメータがある場合は、この構造を繰り返してください -->
  </arguments>
  <return-value>
    <type></type>
    <description></description>
  </return-value>
  <remarks></remarks>
  <process-flow>
    <step></step>
    <!-- 複数のステップがある場合は、この構造を繰り返してください -->
  </process-flow>
  <database-queries>
    <query>
      <description></description>
      <pseudo-sql></pseudo-sql>
    </query>
    <!-- 複数のクエリがある場合は、この構造を繰り返してください -->
  </database-queries>
</function>
```

## 各要素の詳細:

- `<name>`: 関数の正確な名前を記入してください。
- `<purpose>`: この関数が提供する主要な価値や解決する問題を簡潔に説明してください。
- `<summary>`: 関数の基本的な動作と、その動作がプロジェクトの全体的な目的にどう寄与するか。技術的な詳細は最小限にし、関数の役割や影響に焦点を当てます。
- `<arguments>`: 全てのパラメータを列挙し、それぞれの名前、型、説明を提供してください。
- `<return-value>`: 戻り値の型と説明を記入してください。
- `<remarks>`: 関数の動作に関する追加の重要な情報や注意点を記載してください。ただし、過度に詳細な実装の警告は避け、利用上の重要なポイントに絞ります。
- `<process-flow>`: 関数の処理の流れを日本語で連番で説明してください。各ステップを<step>タグで囲んでください。
- `<database-queries>`: データベースアクセス処理がある場合、それぞれのクエリについて以下を記載してください：
  - `<description>`: クエリの目的や条件を日本語で説明します。
  - `<pseudo-sql>`: 実際のSQLに近い形で、条件分岐を含めた擬似SQLを記述します。

## 注意事項:

- 情報が不明確または不足している場合は、推測せずに `<不明>` と記入してください。
- コード内のコメントや命名規則から推測できる情報がある場合は、それを活用してください。ただしコメントに関しては古い誤ったものが残っているので注意して下さい。
- ハルシネーション（不正確な情報の生成）を避けるために、直接コードから読み取れる情報に基づいていなければなりません。
- 上位ドキュメントの作成に役立つ重要な情報を含むようにし、過度に詳細な技術的内容は避けてください。
- 生成したドキュメントが完全で正確であることを確認するため、入力されたコードを再度確認してください。
- XMLの構造が正しいことを確認し、整形されたXMLを出力してください。

## C言語コード:

```c
security_context_t
get_exec_context(security_context_t old_context, const char *role, const char *type)
{
    security_context_t new_context = NULL;
    context_t context = NULL;
    char *typebuf = NULL;
    debug_decl(get_exec_context, SUDO_DEBUG_SELINUX)
    
    /* We must have a role, the type is optional (we can use the default). */
    if (!role) {
	sudo_warnx(U_("you must specify a role for type %s"), type);
	errno = EINVAL;
	goto bad;
    }
    if (!type) {
	if (get_default_type(role, &typebuf)) {
	    sudo_warnx(U_("unable to get default type for role %s"), role);
	    errno = EINVAL;
	    goto bad;
	}
	type = typebuf;
    }
    
    /* 
     * Expand old_context into a context_t so that we extract and modify 
     * its components easily. 
     */
    context = context_new(old_context);
    
    /*
     * Replace the role and type in "context" with the role and
     * type we will be running the command as.
     */
    if (context_role_set(context, role)) {
	sudo_warn(U_("failed to set new role %s"), role);
	goto bad;
    }
    if (context_type_set(context, type)) {
	sudo_warn(U_("failed to set new type %s"), type);
	goto bad;
    }
      
    /*
     * Convert "context" back into a string and verify it.
     */
    if ((new_context = strdup(context_str(context))) == NULL) {
	sudo_warnx(U_("%s: %s"), __func__, U_("unable to allocate memory"));
	goto bad;
    }
    if (security_check_context(new_context) < 0) {
	sudo_warnx(U_("%s is not a valid context"), new_context);
	errno = EINVAL;
	goto bad;
    }

#ifdef DEBUG
    sudo_warnx("Your new context is %s", new_context);
#endif

    context_free(context);
    debug_return_ptr(new_context);

bad:
    free(typebuf);
    context_free(context);
    freecon(new_context);
    debug_return_ptr(NULL);
}
```

## 外部関数情報:

外部関数の情報はありません。
