import sys
import csv
import json
import shutil
from pathlib import Path


def write_csv_file(data: list[dict], csv_path: Path, fieldnames: list[str]):
    """
    データをCSVファイルに書き込む。

    Args:
        data: 書き込む辞書のリスト
        csv_path: 出力CSVファイルのパス
        fieldnames: CSVフィールド名のリスト
    """
    with open(csv_path, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data)


def collect_target_files(targets: list[str], base_path: Path = None) -> list[dict]:
    """
    対象リストから全ての対象ファイルを収集する。

    Args:
        targets: 対象ファイルリストからのパスのリスト
        base_path: ベースディレクトリのパス。Noneの場合は現在のディレクトリを使用。

    Returns:
        list[dict]: 対象ファイル情報のリスト
    """
    if base_path is None:
        base_path = Path.cwd()

    target_files = []

    for target in targets:
        # ターゲットパスがベースディレクトリを既に含んでいる場合の処理
        if str(base_path) != "." and target.startswith(str(base_path) + "/"):
            # ベースディレクトリ部分を削除
            target_relative = target[len(str(base_path)) + 1 :]
            target_path = base_path / target_relative
        else:
            target_path = base_path / target

        if target_path.is_file():
            # 単一ファイル
            if target_path.suffix == ".c":
                target_files.append({"file_path": target})  # 元のパスをそのまま使用
        elif target_path.is_dir():
            # ディレクトリ - 全ての.cファイルを再帰的に収集
            for c_file in target_path.rglob("*.c"):
                # 相対パスを計算
                if str(base_path) != ".":
                    relative_path = str(base_path / c_file.relative_to(base_path))
                else:
                    relative_path = str(c_file.relative_to(base_path))
                target_files.append({"file_path": relative_path})
        # 存在しないファイル/ディレクトリは無視（リストに追加しない）

    return target_files


def load_analysis_result(json_path: Path) -> dict:
    """
    解析結果JSONファイルを読み込んで解析結果を取得する。

    Args:
        json_path: 解析結果JSONファイルのパス

    Returns:
        dict: ファイルパスをキーとした関数情報の辞書

    Raises:
        FileNotFoundError: JSONファイルが存在しない場合
        json.JSONDecodeError: JSONファイルの解析に失敗した場合
    """
    if not json_path.exists():
        raise FileNotFoundError(f"解析結果ファイルが見つかりません: {json_path}")

    try:
        with open(json_path, "r", encoding="utf-8") as f:
            analysis_data = json.load(f)
    except json.JSONDecodeError as e:
        raise json.JSONDecodeError(
            f"JSONファイルの解析に失敗しました: {json_path}", e.doc, e.pos
        )

    # ファイルパスをキーとして関数情報を整理
    file_functions = {}
    for item in analysis_data:
        file_path = item["file_path"]
        if file_path not in file_functions:
            file_functions[file_path] = []

        file_functions[file_path].append(
            {
                "func_id": item["id"],
                "func_type": item["type"],
                "func_name": item["name"],
                "file_path": file_path,
            }
        )

    return file_functions


def collect_all_functions(
    file_list: list[dict[str, str]], analysis_data: dict = None
) -> list[dict[str, str]]:
    """
    解析済みデータから全ての関数情報を収集する。

    Args:
        file_list: 対象ファイル情報のリスト
        analysis_data: analysis_result_sample_files.jsonから読み込んだデータ

    Returns:
        list[dict]: 発見した全関数のリスト
    """
    all_functions = []

    if analysis_data:
        # JSONデータから関数情報を取得
        for file_info in file_list:
            file_path = file_info["file_path"]
            if file_path in analysis_data:
                functions = analysis_data[file_path]
                # type=funcのみフィルタリング
                func_only = [f for f in functions if f.get("func_type") == "func"]
                all_functions.extend(func_only)

    return all_functions


def load_settings(settings_path: Path) -> dict:
    """
    設定ファイルを読み込む。

    Args:
        settings_path: 設定ファイルのパス

    Returns:
        dict: 設定内容

    Raises:
        FileNotFoundError: 設定ファイルが存在しない場合
        json.JSONDecodeError: JSONファイルの解析に失敗した場合
    """
    if not settings_path.exists():
        raise FileNotFoundError(f"設定ファイルが見つかりません: {settings_path}")

    try:
        with open(settings_path, "r", encoding="utf-8") as f:
            settings = json.load(f)
    except json.JSONDecodeError as e:
        raise json.JSONDecodeError(
            f"設定ファイルの解析に失敗しました: {settings_path}", e.doc, e.pos
        )

    # 必須フィールドの確認
    required_fields = [
        "c_source_dir",
        "analysis_result_file",
        "target_paths_file",
        "output_dir",
    ]
    for field in required_fields:
        if field not in settings:
            raise ValueError(f"設定ファイルに必須フィールド '{field}' がありません")

    return settings


def main():
    """メインエントリーポイント。"""
    print("C Language Documentation Generation System")
    print("=" * 50)

    # コマンドライン引数の処理
    if len(sys.argv) > 2:
        print("使用法: python3 main.py [settings.json]")
        print("例: python3 main.py")
        print("例: python3 main.py ./config/settings.json")
        sys.exit(1)

    # 設定ファイルのパスを決定
    if len(sys.argv) == 2:
        settings_path = Path(sys.argv[1])
    else:
        settings_path = Path("./settings.json")

    # 設定ファイルを読み込む
    try:
        settings = load_settings(settings_path)
    except (FileNotFoundError, json.JSONDecodeError, ValueError) as e:
        print(f"エラー: {e}")
        sys.exit(1)

    # 設定値を変数に割り当て
    base_dir = Path(settings["c_source_dir"])
    analysis_file = Path(settings["analysis_result_file"])
    targets_file = Path(settings["target_paths_file"])
    output_base_dir = Path(settings["output_dir"])

    # 引数の検証
    if not base_dir.exists():
        print(f"エラー: ベースディレクトリが存在しません: {base_dir}")
        sys.exit(1)

    if not analysis_file.exists():
        print(f"エラー: 解析ファイルが存在しません: {analysis_file}")
        sys.exit(1)

    if not targets_file.exists():
        print(f"エラー: 対象ファイルリストが存在しません: {targets_file}")
        sys.exit(1)

    print(f"ベースディレクトリ: {base_dir}")
    print(f"解析ファイル: {analysis_file}")
    print(f"対象ファイルリスト: {targets_file}")
    print()

    # 出力ディレクトリ作成
    # settings.jsonのoutput_dirを使用
    output_dir = output_base_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"出力ディレクトリを作成しました: {output_dir}")

    # target_paths.txtの読み込みとコピー
    print(f"{targets_file.name}を処理中...")
    lines = targets_file.read_text(encoding="utf-8").splitlines()
    targets = [line.strip() for line in lines if line.strip()]
    shutil.copy2(targets_file, output_dir / targets_file.name)
    print(f"{len(targets)} 個のターゲットを発見")

    # analysis_result.jsonをコピー
    print(f"{analysis_file.name}をコピー中...")
    shutil.copy2(analysis_file, output_dir / analysis_file.name)

    # settings.jsonをコピー
    print(f"{settings_path.name}をコピー中...")
    shutil.copy2(settings_path, output_dir / settings_path.name)

    # 対象ファイルの収集
    print("対象ファイルを収集中...")
    target_files = collect_target_files(targets, base_dir)

    # Write target_files.csv
    target_files_csv = output_dir / "target_files.csv"
    write_csv_file(target_files, target_files_csv, fieldnames=["file_path"])
    print(f"{target_files_csv} を生成 ({len(target_files)} ファイル)")

    # 解析済みデータを読み込み
    print("解析済みデータを読み込み中...")
    analysis_data = load_analysis_result(analysis_file)
    print(f"解析済みデータを読み込みました ({len(analysis_data)} ファイル)")

    # 全対象ファイルから関数を抽出
    print("関数を抽出中...")
    all_functions = collect_all_functions(target_files, analysis_data)

    # Write target_functions.csv
    target_functions_csv = output_dir / "target_functions.csv"
    if all_functions:
        write_csv_file(
            all_functions,
            target_functions_csv,
            fieldnames=["file_path", "func_type", "func_id", "func_name"],
        )
    print(f"{target_functions_csv} を生成 ({len(all_functions)} 関数)")


if __name__ == "__main__":
    main()


# python3 fix_analysis_result ./analysis_result.json
# 元の json を bak とし fixed を analysis_result.json にファイル名変更
# main, determine_generation_order, generate_docs の順で実行
