"""OpenAI Chat Completions Proxy Server"""

import json
from http.server import HTTPServer, BaseHTTPRequestHandler
from openai import OpenAI


def load_env(filepath: str = ".env") -> dict[str, str]:
    """Load environment variables from .env file"""
    env = {}
    try:
        with open(filepath, "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, value = line.split("=", 1)
                    env[key.strip()] = value.strip()
    except FileNotFoundError:
        pass
    return env


env = load_env()
client = OpenAI(api_key=env.get("OPENAI_API_KEY"))


class ProxyHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path == "/chat/completions":
            self.handle_chat_completions()
        else:
            self.send_error(404, "Not Found")

    def handle_chat_completions(self):
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length)

        try:
            data = json.loads(body)
            model = data.get("model")
            messages = data.get("messages")

            if not model or not messages:
                self.send_error(400, "model and messages are required")
                return

            completion = client.chat.completions.create(
                model=model,
                messages=messages,
            )

            response = completion.to_json()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(response.encode("utf-8"))

        except json.JSONDecodeError:
            self.send_error(400, "Invalid JSON")
        except Exception as e:
            self.send_error(500, str(e))


def main():
    port = 8080
    server = HTTPServer(("", port), ProxyHandler)
    print(f"Server running on port {port}")
    server.serve_forever()


if __name__ == "__main__":
    main()
